package com.devdocs.chat.controller;

import com.devdocs.chat.dto.GenerateRequest;
import com.devdocs.chat.dto.GenerateResponse;
import com.devdocs.chat.service.GenerateService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/generate")
@RequiredArgsConstructor
public class GenerateController {

    private final GenerateService generateService;

    @PostMapping("/release-notes")
    public GenerateResponse releaseNotes(@Valid @RequestBody GenerateRequest request) {
        return generateService.generateReleaseNotes(request);
    }

    @PostMapping("/user-stories")
    public GenerateResponse userStories(@Valid @RequestBody GenerateRequest request) {
        return generateService.generateUserStories(request);
    }

    @PostMapping("/onboarding-summary")
    public GenerateResponse onboardingSummary(@Valid @RequestBody GenerateRequest request) {
        return generateService.generateOnboardingSummary(request);
    }
}
