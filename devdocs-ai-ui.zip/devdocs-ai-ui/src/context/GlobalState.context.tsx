/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useMemo, useState } from 'react';

type GlobalState = {
  isSidebarOpen: boolean;
  setSidebarOpen: (value: boolean) => void;
  user: { name: string | null };
  setUser: (user: { name: string | null }) => void;
};

const initialState: GlobalState = {
  isSidebarOpen: false,
  setSidebarOpen: () => undefined,
  user: { name: null },
  setUser: () => undefined,
};

const GlobalStateContext = createContext<GlobalState>(initialState);

export const GlobalStateProvider: React.FC<React.PropsWithChildren> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [user, setUser] = useState<{ name: string | null }>({ name: 'Guest' });

  const value = useMemo(
    () => ({ isSidebarOpen, setSidebarOpen: setIsSidebarOpen, user, setUser }),
    [isSidebarOpen, user]
  );

  return <GlobalStateContext.Provider value={value}>{children}</GlobalStateContext.Provider>;
};

export const useGlobalState = (): GlobalState => useContext(GlobalStateContext);
