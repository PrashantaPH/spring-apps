package com.devdocs.docs.service;

import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Slf4j
@Service
@RequiredArgsConstructor
public class VectorMaintenanceClient {

    private final WebClient.Builder webClientBuilder;

    @Value("${ingestion.base-url}")
    private String ingestionBaseUrl;

    @Value("${chat.base-url:http://localhost:8084}")
    private String chatBaseUrl;

    @Value("${service.auth.token}")
    private String serviceToken;

    public void updateIngestionVectors(Long documentId, String mode) {
        if (documentId == null) {
            return;
        }
        try {
            webClientBuilder.baseUrl(ingestionBaseUrl)
                .build()
                .post()
                .uri("/api/v1/ingestions/documents/{documentId}/vectors", documentId)
                .header("X-Service-Token", serviceToken)
                .bodyValue(Map.of("mode", mode))
                .retrieve()
                .toBodilessEntity()
                .block();
        } catch (Exception ex) {
            log.warn("Failed to update ingestion vectors for document {}", documentId, ex);
        }
    }

    public void updateChatVectors(Long documentId, String mode) {
        if (documentId == null) {
            return;
        }
        try {
            webClientBuilder.baseUrl(chatBaseUrl)
                .build()
                .post()
                .uri("/api/v1/chats/indices/documents/{documentId}/vectors", documentId)
                .header("X-Service-Token", serviceToken)
                .bodyValue(Map.of("mode", mode))
                .retrieve()
                .toBodilessEntity()
                .block();
        } catch (Exception ex) {
            log.warn("Failed to update chat vectors for document {}", documentId, ex);
        }
    }
}
