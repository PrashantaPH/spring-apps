package com.devdocs.chat.dto;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class CitationDto {
    Long docId;
    String title;
    String url;
}
