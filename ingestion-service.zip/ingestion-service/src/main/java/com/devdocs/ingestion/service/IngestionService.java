package com.devdocs.ingestion.service;

import com.devdocs.common.ai.EmbeddingClient;
import com.devdocs.common.ai.dto.EmbeddingResponse;
import com.devdocs.common.vector.VectorIndexService;
import com.devdocs.ingestion.dto.IngestionCallbackPayload;
import com.devdocs.ingestion.dto.IngestionRequest;
import com.devdocs.ingestion.dto.IngestionRunDto;
import com.devdocs.ingestion.entity.DocumentChunk;
import com.devdocs.ingestion.entity.IngestionRun;
import com.devdocs.ingestion.repository.DocumentChunkRepository;
import com.devdocs.ingestion.web.ContentTooLargeException;
import com.devdocs.ingestion.repository.IngestionRunRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import static com.devdocs.common.web.ErrorCode.INGESTION_ERROR;

@Slf4j
@Service
@RequiredArgsConstructor
public class IngestionService {

    private final Chunker chunker;
    private final EmbeddingClient embeddingClient;
    private final DocumentChunkRepository chunkRepository;
    private final IngestionRunRepository ingestionRunRepository;
    private final VectorIndexService vectorIndexService;
    private final WebClient.Builder webClientBuilder;
    private final ObjectMapper objectMapper;

    @Value("${ingestion.chunk-size}")
    private int chunkSize;

    @Value("${ingestion.max-content-chars:2000000}")
    private int maxContentChars;

    @Value("${docs.base-url}")
    private String docsBaseUrl;

    @Value("${service.auth.token}")
    private String serviceToken;

    @jakarta.transaction.Transactional
    public IngestionRunDto ingest(IngestionRequest request) {
        long startTime = System.nanoTime();
        String content = request.getContent();
        if (content != null && content.length() > maxContentChars) {
            throw new ContentTooLargeException("Document content is too large. Please upload a smaller file.");
        }
        int maxChars = request.getChunking() != null && request.getChunking().getMaxChars() != null
            ? request.getChunking().getMaxChars()
            : chunkSize;
        int overlap = request.getChunking() != null && request.getChunking().getOverlap() != null
            ? request.getChunking().getOverlap()
            : 0;

        List<String> chunks = chunker.chunk(content, maxChars, overlap);
        IngestionRun run = new IngestionRun();
        run.setDocumentId(request.getDocumentId());
        run.setVersionId(request.getDocumentVersionId());
        run.setStatus("PROCESSING");
        run.setCreatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        run.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        IngestionRun savedRun = ingestionRunRepository.save(run);

        int chunksProcessed = 0;
        int embeddingsSaved = 0;
        AtomicInteger retryCount = new AtomicInteger(0);
        String finalStatus = "COMPLETED";
        String errorCode = null;
        String errorMessage = null;

        boolean isReindex = request.getReindex() != null && request.getReindex();
        boolean refreshVectors = request.getRefreshVectors() != null && request.getRefreshVectors();

        if (isReindex) {
            chunkRepository.updateActiveByDocumentId(request.getDocumentId(), false);
            vectorIndexService.setActiveByDocumentId(request.getDocumentId(), false);
            if (refreshVectors) {
                vectorIndexService.removeDocumentVectors(request.getDocumentId());
            }
        }

        if (chunks.isEmpty()) {
            finalStatus = "FAILED";
            errorCode = "NO_CHUNKS";
            errorMessage = "No chunks generated for ingestion.";
        }

        for (int index = 0; index < chunks.size() && "COMPLETED".equals(finalStatus); index++) {
            String chunk = chunks.get(index);
            UUID finalChunkId = null;
            try {
                EmbeddingResponse embedding = withRetry(() -> embeddingClient.embed(chunk), "embedding", request.getDocumentId(), savedRun.getId(), index, retryCount);
                finalChunkId = UUID.randomUUID();

                UUID chunkId = finalChunkId;
                withRetry(() -> {
                    vectorIndexService.addVector(chunkId, embedding.getVector(), request.getDocumentId(), chunk, true,
                            request.getDocumentVersionId());
                    return true;
                }, "index", request.getDocumentId(), savedRun.getId(), index, retryCount);

                DocumentChunk dc = new DocumentChunk();
                dc.setChunkId(finalChunkId);
                dc.setDocumentId(request.getDocumentId());
                OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
                dc.setContent(chunk);
                dc.setEmbedding(serializeVector(embedding.getVector()));
                dc.setCreatedAt(now);
                dc.setUpdatedAt(now);
                dc.setActive(true);
                dc.setVersionId(request.getDocumentVersionId());
                chunkRepository.save(dc);

                chunksProcessed++;
                embeddingsSaved++;
            } catch (Exception ex) {
                finalStatus = chunksProcessed > 0 ? "PARTIAL" : "FAILED";
                errorCode = INGESTION_ERROR.name();
                errorMessage = ex.getMessage();
                log.error("Ingestion failed. documentId={}, runId={}, chunkIndex={}", request.getDocumentId(), savedRun.getId(), index, ex);
                if (finalChunkId != null) {
                    vectorIndexService.removeChunkVector(finalChunkId); // Manual Rollback
                }
                break;
            }
        }

        long durationMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startTime);
        savedRun.setStatus(finalStatus);
        savedRun.setChunkCount(chunksProcessed);
        savedRun.setEmbeddingCount(embeddingsSaved);
        savedRun.setDurationMs(durationMs);
        savedRun.setErrorCode(errorCode);
        savedRun.setErrorMessage(errorMessage);
        savedRun.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        ingestionRunRepository.save(savedRun);

        sendCallback(request.getDocumentId(), savedRun, durationMs, errorCode, errorMessage, retryCount);

        log.info("Ingestion completed. documentId={}, runId={}, status={}, chunks={}, embeddings={}, durationMs={}, retries={}",
            request.getDocumentId(), savedRun.getId(), savedRun.getStatus(), chunksProcessed, embeddingsSaved, durationMs, retryCount.get());

        return IngestionRunDto.builder()
            .id(savedRun.getId())
            .documentId(savedRun.getDocumentId())
            .status(savedRun.getStatus())
            .chunkCount(savedRun.getChunkCount())
            .createdAt(savedRun.getCreatedAt())
            .build();
    }

    private void sendCallback(Long documentId, IngestionRun run, long durationMs, String errorCode, String errorMessage,
                              AtomicInteger retryCount) {
        IngestionCallbackPayload payload = new IngestionCallbackPayload(
            documentId,
            run.getId(),
            run.getVersionId(),
            run.getStatus(),
            run.getChunkCount(),
            run.getEmbeddingCount(),
            durationMs,
            errorCode,
            errorMessage,
            OffsetDateTime.now(ZoneOffset.UTC)
        );

        try {
            withRetry(() -> {
                webClientBuilder.baseUrl(docsBaseUrl)
                    .build()
                    .post()
                    .uri("/api/v1/ingestions/callbacks/result")
                    .header("X-Service-Token", serviceToken)
                    .bodyValue(payload)
                    .retrieve()
                    .toBodilessEntity()
                    .block();
                return true;
            }, "callback", documentId, run.getId(), null, retryCount);
        } catch (Exception ex) {
            log.error("Failed to deliver ingestion callback after retries. documentId={}, runId={}",
                documentId, run.getId(), ex);
        }
    }

    private <T> T withRetry(Retryable<T> action, String stage, Long documentId, Long runId, Integer chunkIndex,
                            AtomicInteger retryCount) {
        int maxAttempts = 3;
        long backoffMs = 300;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                return action.run();
            } catch (Exception ex) {
                log.warn("Retryable failure. stage={}, attempt={}, documentId={}, runId={}, chunkIndex={}",
                    stage, attempt, documentId, runId, chunkIndex, ex);
                if (attempt == maxAttempts) {
                    throw ex;
                }
                retryCount.incrementAndGet();
                try {
                    Thread.sleep(backoffMs);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw new IllegalStateException("Retry interrupted", ie);
                }
                backoffMs = Math.min(backoffMs * 2, 2000);
            }
        }
        throw new IllegalStateException("Retry failed");
    }

    @FunctionalInterface
    private interface Retryable<T> {
        T run();
    }

    private String serializeVector(List<Double> vector) {
        if (vector == null || vector.isEmpty()) {
            return "[]";
        }
        try {
            return objectMapper.writeValueAsString(vector);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialize vector", e);
            return "[]";
        }
    }
}
