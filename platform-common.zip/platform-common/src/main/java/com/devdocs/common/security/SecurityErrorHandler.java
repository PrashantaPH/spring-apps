package com.devdocs.common.security;

import com.devdocs.common.web.ApiError;
import com.devdocs.common.web.ErrorCode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class SecurityErrorHandler implements AuthenticationEntryPoint, AccessDeniedHandler {

    private final ObjectMapper objectMapper;

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException)
        throws IOException, ServletException {
        if (authException instanceof TokenExpiredAuthenticationException) {
            writeError(response, HttpStatus.UNAUTHORIZED, ErrorCode.TOKEN_EXPIRED,
                "Your session has expired. Please log in again.");
            return;
        }
        writeError(response, HttpStatus.UNAUTHORIZED, ErrorCode.UNAUTHORIZED,
            "You are not authorized to perform this action. Please reauthenticate or contact support.");
    }

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException)
        throws IOException, ServletException {
        writeError(response, HttpStatus.FORBIDDEN, ErrorCode.FORBIDDEN,
            "You are not authorized to perform this action. Please reauthenticate or contact support.");
    }

    private void writeError(HttpServletResponse response, HttpStatus status, ErrorCode code, String message)
        throws IOException {
        ApiError body = ApiError.builder()
            .statusCode(status.value())
            .errorCode(code.name())
            .message(message)
            .timestamp(OffsetDateTime.now(ZoneOffset.UTC))
            .build();
        response.setStatus(status.value());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        objectMapper.writeValue(response.getOutputStream(), body);
    }
}
