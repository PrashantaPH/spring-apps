import mongoose from "mongoose";

const eventSchema = new mongoose.Schema({
 
    eventId: {
        type: String,
        required: true,
        unique: true,
    },
    eventName: {
        type: String,
        required: true,
    },
    eventDate: {
        type: Date,
        required:true,
    },
    location: {
        type: String,
        required: false,
    },
    eventType: {
        type: String,
        required: true,
    },
    qrCode: {
        type: String,
        required: false,
    },  
})

export default mongoose.model("events", eventSchema);

