package com.devdocs.chat.dto;

import java.time.OffsetDateTime;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ChatMessageRevisionDto {
    Integer version;
    String content;
    OffsetDateTime editedAt;
    Long editedBy;
}
