package com.devdocs.docs.web;

@Deprecated(forRemoval = true)
public class DocServiceExceptionHandler {
}
