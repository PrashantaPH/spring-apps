package com.devdocs.common.vector;

import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import io.github.jbellis.jvector.graph.GraphIndexBuilder;
import io.github.jbellis.jvector.graph.GraphSearcher;
import io.github.jbellis.jvector.graph.MapRandomAccessVectorValues;
import io.github.jbellis.jvector.graph.RandomAccessVectorValues;
import io.github.jbellis.jvector.graph.SearchResult;
import io.github.jbellis.jvector.util.Bits;
import io.github.jbellis.jvector.vector.VectorSimilarityFunction;
import io.github.jbellis.jvector.vector.VectorizationProvider;
import io.github.jbellis.jvector.vector.types.VectorFloat;
import io.github.jbellis.jvector.vector.types.VectorTypeSupport;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Service to manage in-memory vector index using JVector library.
 * Provides functionality to add vectors and perform similarity search.
 */
@Slf4j
@Service
public class VectorIndexService {

    private static final int DEFAULT_MAX_DEGREE = 16;
    private static final int DEFAULT_BEAM_WIDTH = 100;
    private static final float DEFAULT_NEIGHBOR_OVERFLOW = 1.2f;
    private static final float DEFAULT_ALPHA = 1.2f;
    private static final boolean DEFAULT_ADD_HIERARCHY = true;

    private final VectorTypeSupport vectorTypeSupport = VectorizationProvider.getInstance().getVectorTypeSupport();

    // Map from internal node id to vector
    private final Map<Integer, VectorFloat<?>> vectorStore = new ConcurrentHashMap<>();

    // Map from internal node id to metadata (document ID and content)
    private final Map<Integer, VectorMetadata> metadataStore = new ConcurrentHashMap<>();

    // Map from chunk ID to internal node id
    private final Map<UUID, Integer> nodeIdByChunk = new ConcurrentHashMap<>();
    
    // Vector index for similarity search
    private volatile int vectorCount = 0;
    
    // Dimension of vectors (default 768 for most embedding models)
    private int dimension = 768;

    private final AtomicInteger nextNodeId = new AtomicInteger(0);

    private volatile RandomAccessVectorValues vectorValues;
    private volatile GraphIndexBuilder graphBuilder;

    @PostConstruct
    public void init() {
        this.vectorValues = new MapRandomAccessVectorValues(vectorStore, dimension);
        this.graphBuilder = buildGraphBuilder(vectorValues);
        log.info("Initializing VectorIndexService with dimension: {}", dimension);
    }

    /**
     * Set the dimension for vectors (must be called before adding any vectors if different from default)
     */
    public void setDimension(int dimension) {
        if (!vectorStore.isEmpty()) {
            throw new IllegalStateException("Cannot change dimension after vectors have been added");
        }
        this.dimension = dimension;
        this.vectorValues = new MapRandomAccessVectorValues(vectorStore, dimension);
        this.graphBuilder = buildGraphBuilder(vectorValues);
    }

    /**
     * Add or update a vector in the index
     */
    public void addVector(UUID chunkId, List<Double> vector, Long documentId, String content) {
        addVector(chunkId, vector, documentId, content, true, null);
    }

    public void addVector(UUID chunkId, List<Double> vector, Long documentId, String content, boolean active, Long versionId) {
        if (vector == null || vector.isEmpty()) {
            log.warn("Skipping null or empty vector for chunk {}", chunkId);
            return;
        }

        float[] vectorArray = new float[vector.size()];
        for (int i = 0; i < vector.size(); i++) {
            vectorArray[i] = vector.get(i).floatValue();
        }

        if (vectorArray.length != dimension) {
            log.warn("Vector dimension mismatch. expected={}, actual={}, chunkId={}",
                dimension, vectorArray.length, chunkId);
        }

        synchronized (this) {
            if (graphBuilder == null) {
                vectorValues = new MapRandomAccessVectorValues(vectorStore, dimension);
                graphBuilder = buildGraphBuilder(vectorValues);
            }

            VectorFloat<?> vectorFloat = vectorTypeSupport.createFloatVector(vectorArray);
            int nodeId = nextNodeId.getAndIncrement();
            vectorStore.put(nodeId, vectorFloat);
            metadataStore.put(nodeId, new VectorMetadata(chunkId, documentId, content, active, versionId));
            nodeIdByChunk.put(chunkId, nodeId);
            graphBuilder.addGraphNode(nodeId, vectorFloat);
            vectorCount++;
        }

        log.debug("Added vector for chunk {} (document {}). Total vectors: {}", chunkId, documentId, vectorCount);
    }

    /**
     * Search for the K nearest vectors to the query vector
     */
    public List<VectorSearchResult> searchSimilar(List<Double> queryVector, Long documentId, int k) {
        if (queryVector == null || queryVector.isEmpty()) {
            return Collections.emptyList();
        }

        if (vectorStore.isEmpty()) {
            log.warn("Vector store is empty, returning no results");
            return Collections.emptyList();
        }

        float[] query = new float[queryVector.size()];
        for (int i = 0; i < queryVector.size(); i++) {
            query[i] = queryVector.get(i).floatValue();
        }

        VectorFloat<?> queryVectorFloat = vectorTypeSupport.createFloatVector(query);
        Bits filter = documentId == null ? Bits.ALL : (int nodeId) -> {
            VectorMetadata metadata = metadataStore.get(nodeId);
            return metadata != null && metadata.isActive() && documentId.equals(metadata.getDocumentId());
        };

        GraphIndexBuilder builderSnapshot = graphBuilder;
        if (builderSnapshot == null) {
            return Collections.emptyList();
        }

        SearchResult result = GraphSearcher.search(
            queryVectorFloat,
            k,
            vectorValues,
            VectorSimilarityFunction.COSINE,
            builderSnapshot.getGraph(),
            filter
        );

        List<VectorSearchResult> results = new ArrayList<>();
        for (SearchResult.NodeScore nodeScore : result.getNodes()) {
            VectorMetadata metadata = metadataStore.get(nodeScore.node);
            if (metadata != null) {
                results.add(new VectorSearchResult(
                    metadata.getChunkId(),
                    metadata.getDocumentId(),
                    metadata.getContent(),
                    nodeScore.score
                ));
            }
        }

        return results;
    }

    /**
     * Remove all vectors for a specific document
     */
    public void removeDocumentVectors(Long documentId) {
        List<Integer> toRemove = metadataStore.entrySet().stream()
            .filter(e -> e.getValue().getDocumentId().equals(documentId))
            .map(Map.Entry::getKey)
            .collect(Collectors.toList());

        if (toRemove.isEmpty()) {
            return;
        }

        synchronized (this) {
            for (Integer nodeId : toRemove) {
                VectorMetadata metadata = metadataStore.remove(nodeId);
                if (metadata != null) {
                    nodeIdByChunk.remove(metadata.getChunkId());
                }
                vectorStore.remove(nodeId);
                if (graphBuilder != null) {
                    graphBuilder.markNodeDeleted(nodeId);
                }
                vectorCount--;
            }

            if (graphBuilder != null) {
                graphBuilder.removeDeletedNodes();
            }
        }

        log.info("Removed {} vectors for document {}", toRemove.size(), documentId);
    }

    /**
     * Remove vector for a specific chunk id.
     */
    public void removeChunkVector(UUID chunkId) {
        if (chunkId == null) {
            return;
        }
        Integer nodeId = nodeIdByChunk.remove(chunkId);
        if (nodeId == null) {
            return;
        }
        synchronized (this) {
            VectorMetadata metadata = metadataStore.remove(nodeId);
            if (metadata != null && graphBuilder != null) {
                graphBuilder.markNodeDeleted(nodeId);
            }
            vectorStore.remove(nodeId);
            if (graphBuilder != null) {
                graphBuilder.removeDeletedNodes();
            }
            vectorCount--;
        }
        log.info("Removed vector for chunk {}", chunkId);
    }

    /**
     * Soft toggle active flag for all vectors belonging to a document.
     */
    public void setActiveByDocumentId(Long documentId, boolean active) {
        if (documentId == null) {
            return;
        }
        metadataStore.values().stream()
            .filter(metadata -> documentId.equals(metadata.getDocumentId()))
            .forEach(metadata -> metadata.setActive(active));
        log.info("Set active={} for vectors of document {}", active, documentId);
    }

    /**
     * Soft toggle active flag for a specific chunk.
     */
    public void setActiveByChunkId(UUID chunkId, boolean active) {
        Integer nodeId = nodeIdByChunk.get(chunkId);
        if (nodeId == null) {
            return;
        }
        VectorMetadata metadata = metadataStore.get(nodeId);
        if (metadata != null) {
            metadata.setActive(active);
        }
    }

    /**
     * Get the number of vectors in the index
     */
    public int size() {
        return vectorStore.size();
    }

    /**
     * Clear all vectors from the index
     */
    public void clear() {
        synchronized (this) {
            vectorStore.clear();
            metadataStore.clear();
            nodeIdByChunk.clear();
            vectorCount = 0;
            nextNodeId.set(0);
            vectorValues = new MapRandomAccessVectorValues(vectorStore, dimension);
            graphBuilder = buildGraphBuilder(vectorValues);
        }
        log.info("Cleared vector index");
    }

    private GraphIndexBuilder buildGraphBuilder(RandomAccessVectorValues values) {
        return new GraphIndexBuilder(
            values,
            VectorSimilarityFunction.COSINE,
            DEFAULT_MAX_DEGREE,
            DEFAULT_BEAM_WIDTH,
            DEFAULT_NEIGHBOR_OVERFLOW,
            DEFAULT_ALPHA,
            DEFAULT_ADD_HIERARCHY
        );
    }

    /**
     * Metadata associated with a vector
     */
    public static class VectorMetadata {
        private final UUID chunkId;
        private final Long documentId;
        private final String content;
        private volatile boolean active;
        private final Long versionId;
        public VectorMetadata(UUID chunkId, Long documentId, String content, boolean active, Long versionId) {
            this.chunkId = chunkId;
            this.documentId = documentId;
            this.content = content;
            this.active = active;
            this.versionId = versionId;
        }

        public UUID getChunkId() {
            return chunkId;
        }

        public Long getDocumentId() {
            return documentId;
        }

        public String getContent() {
            return content;
        }

        public boolean isActive() {
            return active;
        }

        public void setActive(boolean active) {
            this.active = active;
        }

        public Long getVersionId() {
            return versionId;
        }
    }

    /**
     * Result from a vector similarity search
     */
    public static class VectorSearchResult {
        private final UUID chunkId;
        private final Long documentId;
        private final String content;
        private final float score;

        public VectorSearchResult(UUID chunkId, Long documentId, String content, float score) {
            this.chunkId = chunkId;
            this.documentId = documentId;
            this.content = content;
            this.score = score;
        }

        public UUID getChunkId() {
            return chunkId;
        }

        public Long getDocumentId() {
            return documentId;
        }

        public String getContent() {
            return content;
        }

        public float getScore() {
            return score;
        }
    }
}
