import httpClient from './httpClient.api';

export interface Acl {
  isPublic?: boolean;
  allowedUserIds?: number[];
}

export interface Document {
  id: number;
  title: string;
  description?: string;
  sourceUri?: string;
  status: string;
  version: number;
  contentVersion: number;
  tags?: string[];
  acl?: Acl;
  deletedAt?: string | null;
  deletedBy?: number | null;
  createdAt: string;
  updatedAt?: string | null;
}

export interface UploadDocumentRequest {
  file: File;
  title: string;
  description?: string;
  sourceUri?: string;
}

export interface DocumentUpdateResponse {
  updated: boolean;
  document: Document;
}

export interface ApiError {
  message: string;
  statusCode: number;
  errorCode?: string;
  timestamp?: string;
}

class DocumentService {
  /**
   * Upload a PDF, Markdown, or Text document
   * @param params - Upload parameters including file and metadata
   * @returns Promise with the created document
   */
  async uploadDocument(params: UploadDocumentRequest): Promise<Document> {
    const formData = new FormData();
    formData.append('file', params.file);
    formData.append('title', params.title);
    
    if (params.description) {
      formData.append('description', params.description);
    }
    
    if (params.sourceUri) {
      formData.append('sourceUri', params.sourceUri);
    }

    const response = await httpClient.post<Document>('/v1/docs/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });

    // Extract ETag from headers if needed
    const etag = response.headers['etag'];
    if (etag) {
      // You can store or use the ETag if needed for optimistic locking
      console.debug('Document ETag:', etag);
    }

    return response.data;
  }

  /**
   * Upload a document with progress tracking
   * @param params - Upload parameters including file and metadata
   * @param onProgress - Callback for upload progress (0-100)
   * @returns Promise with the created document
   */
  async uploadDocumentWithProgress(
    params: UploadDocumentRequest,
    onProgress?: (progress: number) => void
  ): Promise<Document> {
    const formData = new FormData();
    formData.append('file', params.file);
    formData.append('title', params.title);
    
    if (params.description) {
      formData.append('description', params.description);
    }
    
    if (params.sourceUri) {
      formData.append('sourceUri', params.sourceUri);
    }

    const response = await httpClient.post<Document>('/v1/docs/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: (progressEvent) => {
        if (onProgress && progressEvent.total) {
          const percentCompleted = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          onProgress(percentCompleted);
        }
      },
    });

    return response.data;
  }

  /**
   * Validate file before upload
   * @param file - File to validate
   * @returns Object with validation result and error message if any
   */
  validateUploadFile(file: File): { isValid: boolean; error?: string } {
    // Check file size (e.g., max 100MB)
    const maxSize = 100 * 1024 * 1024; // 100MB
    if (file.size > maxSize) {
      return {
        isValid: false,
        error: `File size exceeds maximum allowed size of ${maxSize / 1024 / 1024}MB`,
      };
    }

    // Check file type
    const allowedTypes = [
      'application/pdf',
      'text/markdown',
      'text/plain',
      'application/markdown',
      'text/x-markdown',
    ];
    
    // Also check file extension as fallback
    const fileExtension = file.name.split('.').pop()?.toLowerCase();
    const allowedExtensions = ['pdf', 'md', 'markdown', 'txt'];
    
    const isValidType = allowedTypes.includes(file.type) || 
                        (fileExtension && allowedExtensions.includes(fileExtension));
    
    if (!isValidType) {
      return {
        isValid: false,
        error: 'Invalid file type. Only PDF, Markdown, and Text files are allowed.',
      };
    }

    return { isValid: true };
  }

  /**
   * Get file type display name
   * @param file - File to get type for
   * @returns Human-readable file type
   */
  getFileTypeDisplayName(file: File): string {
    const extension = file.name.split('.').pop()?.toLowerCase();
    
    switch (extension) {
      case 'pdf':
        return 'PDF Document';
      case 'md':
      case 'markdown':
        return 'Markdown Document';
      case 'txt':
        return 'Text Document';
      default:
        return 'Document';
    }
  }
}

export default new DocumentService();