import { StrictMode, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import { ThemeProvider, CssBaseline } from '@mui/material';
import App from './App';
import { GlobalStateProvider } from './context/GlobalState.context';
import { AuthProvider } from './context/Auth.context';
import { getTheme } from './theme/theme';
import './index.css';

const RootApp = () => {
  const [mode, setMode] = useState<'light' | 'dark'>('light');
  const theme = useMemo(() => getTheme(mode), [mode]);

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <GlobalStateProvider>
        <BrowserRouter>
          <AuthProvider>
            <App mode={mode} setMode={setMode} />
          </AuthProvider>
        </BrowserRouter>
      </GlobalStateProvider>
    </ThemeProvider>
  );
};

const root = createRoot(document.getElementById('root')!);

root.render(
  <StrictMode>
    <RootApp />
  </StrictMode>
);