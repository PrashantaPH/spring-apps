// routes/documentRoutes.js
import express from "express";
import { uploadDocuments, upload, faceGroupingByEvent  } from "../controllers/documentController.js";

const router = express.Router();

router.post("/upload-documents", upload.array("files"), uploadDocuments);
router.get("/facegrouping-by-event/:eventId", faceGroupingByEvent);

export default router;
