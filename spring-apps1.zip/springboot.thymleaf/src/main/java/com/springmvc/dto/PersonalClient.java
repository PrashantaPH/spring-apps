package com.springmvc.dto;

import java.util.Date;

public class PersonalClient {

	private String firstNames;
	private String lastName;
	private Date birthDate;
	private String genderCode;
	private int maritalStatusID;
	private String nINumber;
	private int spouseID;
	private String title;

	public String getFirstNames() {
		return firstNames;
	}

	public void setFirstNames(String firstNames) {
		this.firstNames = firstNames;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	public String getGenderCode() {
		return genderCode;
	}

	public void setGenderCode(String genderCode) {
		this.genderCode = genderCode;
	}

	public int getMaritalStatusID() {
		return maritalStatusID;
	}

	public void setMaritalStatusID(int maritalStatusID) {
		this.maritalStatusID = maritalStatusID;
	}

	public String getnINumber() {
		return nINumber;
	}

	public void setnINumber(String nINumber) {
		this.nINumber = nINumber;
	}

	public int getSpouseID() {
		return spouseID;
	}

	public void setSpouseID(int spouseID) {
		this.spouseID = spouseID;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

}
