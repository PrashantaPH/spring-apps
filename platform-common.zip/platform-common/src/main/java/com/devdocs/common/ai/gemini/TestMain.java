package com.devdocs.common.ai.gemini;

import com.google.genai.Client;
import com.google.genai.types.EmbedContentResponse;
import com.google.genai.types.GenerateContentResponse;

public class TestMain {

    private static final String API_KEY = "AIzaSyD32s3OCblYR7pr0BHep4bzaPm45CM0ca4";

    public String analyzeMessage() {
        String finalPrompt = "Hi";
        Client client = Client.builder()
                .apiKey(API_KEY)
                .build();

        GenerateContentResponse response = client.models.generateContent(
                "gemini-2.5-flash",
                finalPrompt,
                null
        );
        System.out.println(response.text());
        return response.text();
    }

    public static void checkSupportedModel() {
        var client = Client.builder()
                .apiKey(API_KEY)
                .build();

        System.out.println("Models that support embedContent:");
        client.models.list(null).page().forEach(m -> {
            var actions = m.supportedActions();
            if (actions != null && actions.get().contains("generateContent")) {
                System.out.println("  - " + m.name() + " | actions=" + actions);
            }
        });
    }

    public static void main(String[] args) {
        checkSupportedModel();

        String finalPrompt = "Hi";

        Client client = Client.builder()
                .apiKey(API_KEY) // Replace with your actual key
                .build();
        GenerateContentResponse response = client.models.generateContent(
                "models/gemini-2.5-flash",
                finalPrompt,
                null
        );
        System.out.println("gemini-2.5-flash - "+response.text());

        EmbedContentResponse embedContentResponse = client.models.embedContent(
                "models/gemini-embedding-001",
                finalPrompt,
                null
        );
        System.out.println("text-embedding-001 "+embedContentResponse);
         embedContentResponse.embeddings().get().forEach(embedding -> {
             System.out.println("text-embedding-001 "+embedding.values());
         });
    }
}
