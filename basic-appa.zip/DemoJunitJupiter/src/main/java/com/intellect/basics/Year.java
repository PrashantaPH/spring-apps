package com.intellect.basics;

import java.util.Arrays;

public class Year {

	public static void main(String[] args) {

		int days[] = { -1, -10, 10, 5, 30, 15, 20, -10, 30, 10, 29, 20 };

		String result = solution(days);

		System.out.println("Result : " + result);
	}

	public static String solution(int... days) {

		int lenght = days.length;
		int count = lenght / 4;
		int i = 0, j = 0, index = 0;
		String name = "";
		int maxAmpl;

		int[] winter = new int[count];
		int[] spring = new int[count];
		int[] summer = new int[count];
		int[] autumn = new int[count];
		int[] diff = new int[4];

		for (j = 0, i = 0; j < count; j++, i++) {

			winter[i] = days[j];
		}

		for (j = count, i = 0; j < count * 2; j++, i++) {

			spring[i] = days[j];
		}

		for (j = count * 2, i = 0; j < count * 3; j++, i++) {

			summer[i] = days[j];
		}
		
		for (j = count * 3, i = 0; j < count * 4; j++, i++) {

			autumn[i] = days[j];
		}

		Arrays.sort(winter);
		Arrays.sort(spring);
		Arrays.sort(summer);
		Arrays.sort(autumn);

		diff[0] = winter[count - 1] - winter[0];
		diff[1] = spring[count - 1] - spring[0];
		diff[2] = summer[count - 1] - summer[0];
		diff[3] = autumn[count - 1] - autumn[0];

		maxAmpl = diff[0];

		for (int k = 1; k < 4; k++) {
			if (diff[k] > maxAmpl) {
				maxAmpl = diff[k];
				index = k;
			}
		}

		switch (index) {
		case 0:
			name = "WINTER";
			break;
		case 1:
			name = "SPRING";
			break;
		case 2:
			name = "SUMMER";
			break;
		case 3:
			name = "AUTUMN";
			break;
		}
		return name;
	}
}
