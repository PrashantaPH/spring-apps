package com.devdocs.chat.dto;

import java.time.OffsetDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ChatMessageHistoryDto {
    Long id;
    String role;
    String content;
    Integer msgVersion;
    OffsetDateTime createdAt;
    OffsetDateTime updatedAt;
    OffsetDateTime editedAt;
    Long editedBy;
    List<ChatMessageRevisionDto> revisions;
}
