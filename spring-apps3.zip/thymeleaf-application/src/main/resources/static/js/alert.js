function demo(){
	alert("successfully call the js file");
}

$("#alertsuccess").click(){
	debugger
	alert("Success");
}