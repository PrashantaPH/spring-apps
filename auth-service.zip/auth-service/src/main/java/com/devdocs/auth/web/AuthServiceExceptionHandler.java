package com.devdocs.auth.web;

import com.devdocs.common.web.ApiError;
import com.devdocs.common.web.ErrorCode;
import jakarta.validation.ConstraintViolationException;
import java.sql.SQLNonTransientConnectionException;
import java.sql.SQLTransientConnectionException;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import lombok.extern.slf4j.Slf4j;
import org.hibernate.exception.JDBCConnectionException;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

@Slf4j
@RestControllerAdvice
public class AuthServiceExceptionHandler {

    @ExceptionHandler({MethodArgumentNotValidException.class, ConstraintViolationException.class, BindException.class,
        MethodArgumentTypeMismatchException.class, MissingServletRequestParameterException.class,
        IllegalArgumentException.class})
    public ResponseEntity<ApiError> handleValidation(Exception ex) {
        return buildError(HttpStatus.BAD_REQUEST, ErrorCode.VALIDATION_ERROR,
            "Input validation failed. Please check the required fields and try again.", ex);
    }

    @ExceptionHandler(NoHandlerFoundException.class)
    public ResponseEntity<ApiError> handleNotFound(NoHandlerFoundException ex) {
        return buildError(HttpStatus.NOT_FOUND, ErrorCode.NOT_FOUND,
            "The requested resource was not found. Please verify the ID or try again.", ex);
    }

    @ExceptionHandler({DataAccessException.class, JDBCConnectionException.class, SQLTransientConnectionException.class,
        SQLNonTransientConnectionException.class})
    public ResponseEntity<ApiError> handleDatabaseConnectivity(Exception ex) {
        return buildError(HttpStatus.SERVICE_UNAVAILABLE, ErrorCode.DATABASE_CONNECTIVITY_ERROR,
            "The system is experiencing database connectivity issues. Please try again shortly.", ex);
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ApiError> handleMethodNotAllowed(HttpRequestMethodNotSupportedException ex) {
        return buildError(HttpStatus.METHOD_NOT_ALLOWED, ErrorCode.METHOD_NOT_ALLOWED,
            "This endpoint does not support the requested HTTP method. Please check the API documentation.", ex);
    }

    private ResponseEntity<ApiError> buildError(HttpStatus status, ErrorCode code, String message, Exception ex) {
        log.error("Handling error: {} {}", code, status.value(), ex);
        ApiError body = ApiError.builder()
            .statusCode(status.value())
            .errorCode(code.name())
            .message(message)
            .timestamp(OffsetDateTime.now(ZoneOffset.UTC))
            .build();
        return ResponseEntity.status(status).body(body);
    }
}
