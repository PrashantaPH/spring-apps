package com.intellect.DemoJunitJupiter;

public interface A {

	void m();
}
