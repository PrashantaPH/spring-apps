package com.devdocs.common.ai.gemini;

import com.devdocs.common.ai.LlmClient;
import com.devdocs.common.ai.dto.ChatMessageDto;
import com.devdocs.common.ai.dto.LlmRequest;
import com.devdocs.common.ai.dto.LlmResponse;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.devdocs.common.web.exception.RateLimitExceededException;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Slf4j
@Service
@Profile("local")
@RequiredArgsConstructor
public class GeminiLlmClient implements LlmClient {

    private final WebClient.Builder builder;

    @Value("${ai.provider.base-url}")
    private String baseUrl;

    @Value("${ai.provider.chat-model}")
    private String defaultModel;

    @Value("${ai.provider.api-key}")
    private String apiKey;

    @Override
    public LlmResponse chat(LlmRequest request) {
        long start = System.currentTimeMillis();
        String model = request.getModel() != null ? request.getModel() : defaultModel;
        var body = Map.of(
                "contents", toGeminiMessages(request.getMessages()),
                "generationConfig", Map.of("temperature", request.getTemperature() == null ? 0.2 : request.getTemperature())
        );

        GeminiResponse response = builder.baseUrl(baseUrl)
            .build()
            .post()
            .uri(uriBuilder -> uriBuilder.path("/v1beta/models/{model}:generateContent")
                .queryParam("key", apiKey)
                .build(model))
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .bodyValue(body)
            .retrieve()
            .onStatus(status -> status.value() == 429,
                responseObj -> responseObj.bodyToMono(String.class)
                    .defaultIfEmpty("Too many requests")
                    .map(message -> new RateLimitExceededException("Gemini rate limit exceeded: " + message)))
            .bodyToMono(GeminiResponse.class)
            .block(Duration.ofSeconds(30));

        String text = response != null && !response.candidates().isEmpty()
            ? response.candidates().getFirst().content().getFirstText()
            : "No response";
        return LlmResponse.builder()
            .answer(text)
            .latencyMillis(System.currentTimeMillis() - start)
            .build();
    }

    private List<Map<String, Object>> toGeminiMessages(List<ChatMessageDto> messages) {
        return messages.stream()
            .map(msg -> {
                // Gemini expects "user" or "model" roles
                String geminiRole = switch (msg.getRole().toLowerCase()) {
                    case "assistant", "system" -> "model";
                    default -> "user";
                };
                return Map.of(
                    "role", geminiRole,
                    "parts", List.of(Map.of("text", msg.getContent()))
                );
            })
            .toList();
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    private record GeminiResponse(List<Candidate> candidates) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    private record Candidate(Content content) {
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    private record Content(List<Part> parts) {
        String getFirstText() {
            return parts == null || parts.isEmpty() ? "" : parts.getFirst().text();
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    private record Part(String text) {
    }
}
