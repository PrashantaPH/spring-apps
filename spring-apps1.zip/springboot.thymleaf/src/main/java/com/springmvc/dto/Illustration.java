package com.springmvc.dto;

public class Illustration {
	
	private int id;
	public void setSchemeTypeID(int i) {
		this.id=i;
	}
	
	public int getSchemaTypeID() {
		return id;
	}
}
