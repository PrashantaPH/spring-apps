# Changelog

## Unreleased
- Added shared exceptions in `com.devdocs.common.exception` and global handling in `GlobalExceptionHandler`.
- Added shared `VectorMaintenanceRequest` DTO in `com.devdocs.common.dto`.
- Added reusable `ServiceTokenAuthenticationFilterBase` for service-to-service auth.
