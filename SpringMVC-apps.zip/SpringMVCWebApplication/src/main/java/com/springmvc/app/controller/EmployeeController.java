package com.springmvc.app.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.springmvc.app.dto.Employee;

@Controller
public class EmployeeController {
	
	ArrayList<Employee> arrayList = new ArrayList<>();
	
	@GetMapping("/web")
	public String display(Model model) {
		model.addAttribute("listOfEmp", arrayList);
		return "home";
	}
	
	@GetMapping("/showEmployeeForm")
	public String createPage(Model model) {
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "createEmployee";
	}
	
	@PostMapping("/createEmployee")
	public String createEmployee(@ModelAttribute("employee") Employee employee) {
		arrayList.add(employee);
		return "redirect:/web";
	}
}
