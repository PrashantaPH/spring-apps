package com.devdocs.docs.dto;

import jakarta.validation.constraints.NotNull;
import java.time.OffsetDateTime;

public record IngestionCallbackRequest(
    @NotNull Long documentId,
    Long runId,
    Long versionId,
    @NotNull String status,
    Integer chunks,
    Integer embeddings,
    Long durationMs,
    String errorCode,
    String errorMessage,
    @NotNull OffsetDateTime occurredAt
) {
}
