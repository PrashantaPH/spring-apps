package com.devdocs.common.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import static com.devdocs.common.security.SecurityConstants.*;

@Component
@RequiredArgsConstructor
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtTokenService tokenService;
    private final SecurityErrorHandler securityErrorHandler;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
        throws ServletException, IOException {
        String authHeader = request.getHeader(AUTHORIZATION);
        if (authHeader != null && authHeader.startsWith(BEARER_PREFIX)) {
            try {
                String token = authHeader.substring(BEARER_PREFIX.length());
                Claims claims = tokenService.parseToken(token);
                Authentication authentication = tokenService.buildAuthentication(claims);
                SecurityContextHolder.getContext().setAuthentication(authentication);
            } catch (ExpiredJwtException ex) {
                SecurityContextHolder.clearContext();
                if (!response.isCommitted()) {
                    securityErrorHandler.commence(request, response, new TokenExpiredAuthenticationException("Token expired", ex));
                }
                return;
            } catch (Exception ex) {
                SecurityContextHolder.clearContext();
                if (!response.isCommitted()) {
                    securityErrorHandler.commence(request, response, new BadCredentialsException("Invalid token", ex));
                }
                return;
            }
        }
        filterChain.doFilter(request, response);
    }
}
