package com.devdocs.docs.controller;

import com.devdocs.docs.dto.BatchDeleteRequest;
import com.devdocs.docs.dto.BatchDeleteResponse;
import com.devdocs.docs.dto.CreateDocRequest;
import com.devdocs.docs.dto.DocumentDto;
import com.devdocs.docs.dto.DocumentReplaceRequest;
import com.devdocs.docs.dto.DocumentUpdateResponse;
import com.devdocs.docs.dto.PatchDocRequest;
import com.devdocs.docs.dto.ReindexRequest;
import com.devdocs.docs.dto.ReindexResponse;
import com.devdocs.docs.service.DocService;
import com.devdocs.docs.service.DocumentContentExtractor;
import jakarta.validation.Valid;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import static com.devdocs.common.security.SecurityConstants.ROLE_ADMIN;


@RestController
@RequestMapping("/api/v1/docs")
@RequiredArgsConstructor
public class DocController {

    private final DocService docService;
    private final DocumentContentExtractor documentContentExtractor;

    @GetMapping
    public List<DocumentDto> listDocs(Authentication authentication,
                                      @RequestParam(name = "includeDeleted", defaultValue = "false") boolean includeDeleted) {
        Long ownerId = ownerId(authentication);
        return docService.listDocuments(ownerId, includeDeleted);
    }

    @PostMapping
    public ResponseEntity<DocumentDto> createDoc(Authentication authentication,
                                                 @Valid @RequestBody CreateDocRequest request) {
        Long ownerId = ownerId(authentication);
        DocumentDto dto = docService.createDocument(ownerId, request);
        return withEtag(ResponseEntity.status(HttpStatus.CREATED), dto, dto.getVersion());
    }

    @PostMapping(value = "/upload", consumes = "multipart/form-data")
    public ResponseEntity<DocumentDto> uploadDoc(Authentication authentication,
                                                 @RequestPart("file") MultipartFile file,
                                                 @RequestPart("title") String title,
                                                 @RequestPart(value = "description", required = false) String description,
                                                 @RequestPart(value = "sourceUri", required = false) String sourceUri) {
        Long ownerId = ownerId(authentication);
        String content = documentContentExtractor.extract(file);
        DocumentDto dto = docService.createDocument(ownerId, title, content, description, sourceUri);
        return withEtag(ResponseEntity.status(HttpStatus.CREATED), dto, dto.getVersion());
    }

    @PutMapping(value = "/{documentId}", consumes = "multipart/form-data")
    public ResponseEntity<DocumentUpdateResponse> replaceDocument(Authentication authentication,
                                                                  @PathVariable Long documentId,
                                                                  @RequestHeader(value = "If-Match", required = false) String ifMatch,
                                                                  @RequestPart("file") MultipartFile file,
                                                                  @RequestPart(value = "title", required = false) String title,
                                                                  @RequestPart(value = "description", required = false) String description,
                                                                  @RequestPart(value = "sourceUri", required = false) String sourceUri,
                                                                  @RequestParam(name = "reindex", defaultValue = "true") boolean reindex) {
        Long ownerId = ownerId(authentication);
        String content = documentContentExtractor.extract(file);
        String checksum = docServiceChecksum(content);
        DocumentReplaceRequest request = DocumentReplaceRequest.builder()
            .title(title)
            .description(description)
            .sourceUri(sourceUri)
            .content(content)
            .checksum(checksum)
            .reindex(reindex)
            .build();
        DocumentUpdateResponse response = docService.replaceDocument(ownerId, documentId, request, ifMatch);
        Long version = response.getDocument() == null ? null : response.getDocument().getVersion();
        return withEtag(ResponseEntity.ok(), response, version);
    }

    @PatchMapping(value = "/{documentId}", consumes = "application/json")
    public ResponseEntity<DocumentDto> patchDocument(Authentication authentication,
                                                     @PathVariable Long documentId,
                                                     @RequestHeader(value = "If-Match", required = false) String ifMatch,
                                                     @Valid @RequestBody PatchDocRequest request) {
        Long ownerId = ownerId(authentication);
        DocumentDto dto = docService.patchDocument(ownerId, documentId, request, ifMatch);
        return withEtag(ResponseEntity.ok(), dto, dto.getVersion());
    }

    @PostMapping(value = "/{documentId}/reindex", consumes = "application/json")
    public ResponseEntity<ReindexResponse> reindexDocument(Authentication authentication,
                                                           @PathVariable Long documentId,
                                                           @Valid @RequestBody ReindexRequest request) {
        Long ownerId = ownerId(authentication);
        ReindexResponse response = docService.reindexDocument(ownerId, documentId, request);
        Long version = response.getDocument() == null ? null : response.getDocument().getVersion();
        return withEtag(ResponseEntity.accepted(), response, version);
    }

    @DeleteMapping(value = "/{documentId}")
    public ResponseEntity<?> deleteDocument(Authentication authentication,
                                            @PathVariable Long documentId,
                                            @RequestParam(name = "mode", defaultValue = "soft") String mode,
                                            @RequestParam(name = "deleteVectors", defaultValue = "true") boolean deleteVectors,
                                            @RequestParam(name = "purgeBinary", defaultValue = "false") boolean purgeBinary) {
        Long ownerId = ownerId(authentication);
        boolean isAdmin = authentication.getAuthorities().stream().anyMatch(a -> ROLE_ADMIN.equals(a.getAuthority()));
        return ResponseEntity.ok(docService.deleteDocument(ownerId, documentId, mode, deleteVectors, purgeBinary, isAdmin));
    }

    @DeleteMapping(consumes = "application/json")
    public ResponseEntity<BatchDeleteResponse> deleteDocuments(Authentication authentication,
                                                               @Valid @RequestBody BatchDeleteRequest request) {
        Long ownerId = ownerId(authentication);
        boolean isAdmin = authentication.getAuthorities().stream().anyMatch(a -> ROLE_ADMIN.equals(a.getAuthority()));
        return ResponseEntity.ok(docService.deleteDocuments(ownerId, request, isAdmin));
    }

    private Long ownerId(Authentication authentication) {
        return Math.abs(authentication.getName().hashCode()) + 0L;
    }

    private String docServiceChecksum(String content) {
        return docServiceChecksumInternal(content);
    }

    private String docServiceChecksumInternal(String content) {
        try {
            java.security.MessageDigest digest = java.security.MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(content == null ? new byte[0] : content.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception ex) {
            throw new IllegalStateException("Unable to compute checksum", ex);
        }
    }

    private <T> ResponseEntity<T> withEtag(ResponseEntity.BodyBuilder builder, T body, Long version) {
        if (version != null) {
            builder.header("ETag", "W/\"" + version + "\"");
        }
        return builder.body(body);
    }
}
