package com.springmvc.document.pdf;

import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.stereotype.Service;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import com.itextpdf.html2pdf.resolver.font.DefaultFontProvider;
import com.itextpdf.io.source.ByteArrayOutputStream;
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfTable;
import com.lowagie.text.pdf.PdfWriter;

//import jakarta.servlet.http.HttpServletResponse;

@Service
public class DocumentGenarator {

	public String htmlToPDF(String processedHtml) {

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

		try {

			com.itextpdf.kernel.pdf.PdfWriter pdfWriter = new com.itextpdf.kernel.pdf.PdfWriter(byteArrayOutputStream);

			DefaultFontProvider defaultFontProvider = new DefaultFontProvider(false, true, false);

			ConverterProperties converterProperties = new ConverterProperties();

			converterProperties.setFontProvider(defaultFontProvider);

			HtmlConverter.convertToPdf(processedHtml, pdfWriter, converterProperties);

			FileOutputStream outputStream = new FileOutputStream("/Prashanta/documents/pdf/registration.pdf");

			byteArrayOutputStream.writeTo(outputStream);
			byteArrayOutputStream.close();
			byteArrayOutputStream.flush();

			outputStream.close();

			return null;

		} catch (Exception e) {
			throw new RuntimeException(processedHtml);
		} finally {
			try {
				if (byteArrayOutputStream != null) {
					byteArrayOutputStream.close();
					byteArrayOutputStream.flush();
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	/*
	 * public PdfPTable export(HttpServletResponse servletResponse) throws
	 * DocumentException, IOException { PdfPTable pdfTable = null;
	 * 
	 * Document document = new Document(PageSize.A4);
	 * PdfWriter.getInstance(document, servletResponse.getOutputStream());
	 * 
	 * document.open(); Font font = FontFactory.getFont(FontFactory.HELVETICA_BOLD);
	 * font.setSize(18);
	 * 
	 * Paragraph paragraph = new Paragraph("Product Information", font);
	 * paragraph.setAlignment(Paragraph.ALIGN_CENTER);
	 * 
	 * document.add(paragraph);
	 * 
	 * Font font2 = FontFactory.getFont(FontFactory.HELVETICA); font2.setStyle(12);
	 * 
	 * Paragraph paragraph2 = new Paragraph("", font2);
	 * paragraph2.setAlignment(Paragraph.ALIGN_LEFT);
	 * 
	 * document.add(paragraph2);
	 * 
	 * Font font3 = FontFactory.getFont(FontFactory.HELVETICA); font3.setStyle(12);
	 * 
	 * Paragraph paragraph3 = new Paragraph("", font3);
	 * paragraph3.setAlignment(Paragraph.ALIGN_LEFT);
	 * 
	 * document.add(paragraph3);
	 * 
	 * pdfTable = new PdfPTable(3); pdfTable.addCell("Header1");
	 * pdfTable.addCell("Header2"); pdfTable.addCell("Header3");
	 * 
	 * pdfTable.addCell("Column 1"); pdfTable.addCell("Column 2");
	 * pdfTable.addCell("Column 3");
	 * 
	 * pdfTable.addCell("Column 1"); pdfTable.addCell("Column 2");
	 * pdfTable.addCell("Column 3");
	 * 
	 * document.add(pdfTable);
	 * 
	 * document.close();
	 * 
	 * return pdfTable; }
	 */

}
