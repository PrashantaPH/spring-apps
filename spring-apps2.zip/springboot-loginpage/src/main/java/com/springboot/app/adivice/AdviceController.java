package com.springboot.app.adivice;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class AdviceController {

	@ExceptionHandler()
	public String exception() {
		return null;
	}
}
