import AppRoutes from './routes/AppRoutes';
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

interface AppProps {
  mode: 'light' | 'dark';
  setMode: (mode: 'light' | 'dark') => void;
}

const App: React.FC<AppProps> = ({ mode, setMode }) => (
  <>
    <AppRoutes mode={mode} setMode={setMode} />

    {/* ✅ Toast Global Container */}
    <ToastContainer
      position="bottom-right"
      autoClose={3000}
      hideProgressBar={false}
      newestOnTop
      closeOnClick
      pauseOnHover
      draggable
      theme={mode} // 🔥 matches dark/light mode
    />
  </>
);

export default App;