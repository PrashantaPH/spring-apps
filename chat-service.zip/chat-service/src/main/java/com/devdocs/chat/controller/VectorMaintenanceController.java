package com.devdocs.chat.controller;

import com.devdocs.common.dto.VectorMaintenanceRequest;
import com.devdocs.chat.service.VectorMaintenanceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/chats/indices/documents")
@RequiredArgsConstructor
public class VectorMaintenanceController {

    private final VectorMaintenanceService vectorMaintenanceService;

    @PostMapping("/{documentId}/vectors")
    public ResponseEntity<Void> updateVectors(@PathVariable Long documentId,
                                              @Valid @RequestBody VectorMaintenanceRequest request) {
        vectorMaintenanceService.updateDocumentVectors(documentId, request.getMode());
        return ResponseEntity.accepted().build();
    }
}
