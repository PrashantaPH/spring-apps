package com.devdocs.chat.dto;

import java.util.Map;

public record GenerateRequest(
    String input,
    Long docId,
    Boolean useRag,
    Map<String, Object> structured
) {
}
