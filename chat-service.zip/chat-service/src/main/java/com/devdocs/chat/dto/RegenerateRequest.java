package com.devdocs.chat.dto;

import lombok.Data;

@Data
public class RegenerateRequest {
    private Long docId;
    private Boolean useRag;
}
