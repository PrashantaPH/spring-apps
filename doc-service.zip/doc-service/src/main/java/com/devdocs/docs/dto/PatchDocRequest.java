package com.devdocs.docs.dto;

import java.util.List;
import lombok.Data;

@Data
public class PatchDocRequest {
    private String title;
    private String description;
    private String sourceUri;
    private List<String> tags;
    private AclDto acl;
}
