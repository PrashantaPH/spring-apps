package com.devdocs.chat.security;

import com.devdocs.common.security.SecurityErrorHandler;
import com.devdocs.common.security.ServiceTokenAuthenticationFilterBase;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ServiceTokenAuthenticationFilter extends ServiceTokenAuthenticationFilterBase {

    private static final String VECTOR_PATH_PREFIX = "/api/v1/chats/indices";

    public ServiceTokenAuthenticationFilter(SecurityErrorHandler securityErrorHandler,
        @Value("${service.auth.token}") String serviceToken) {
        super(securityErrorHandler, serviceToken, VECTOR_PATH_PREFIX, false);
    }
}
