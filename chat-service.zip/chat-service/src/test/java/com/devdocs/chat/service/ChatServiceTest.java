package com.devdocs.chat.service;

import com.devdocs.chat.dto.EditMessageRequest;
import com.devdocs.chat.entity.ChatMessage;
import com.devdocs.chat.entity.ChatSession;
import com.devdocs.chat.repository.ChatMessageRepository;
import com.devdocs.chat.repository.ChatMessageRevisionRepository;
import com.devdocs.chat.repository.ChatSessionRepository;
import com.devdocs.common.ai.EmbeddingClient;
import com.devdocs.common.ai.LlmClient;
import com.devdocs.common.vector.VectorIndexService;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

@SpringBootTest
class ChatServiceTest {

    @Autowired
    private ChatService chatService;

    @Autowired
    private ChatSessionRepository chatSessionRepository;

    @Autowired
    private ChatMessageRepository chatMessageRepository;

    @Autowired
    private ChatMessageRevisionRepository chatMessageRevisionRepository;

    @MockBean
    private EmbeddingClient embeddingClient;

    @MockBean
    private LlmClient llmClient;

    @MockBean
    private VectorIndexService vectorIndexService;

    @Test
    void editMessage_createsRevisionAndIncrementsVersion() {
        Long userId = 200L;
        ChatSession session = new ChatSession();
        session.setUserId(userId);
        session.setCreatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        session.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        session = chatSessionRepository.save(session);

        ChatMessage message = new ChatMessage();
        message.setSession(session);
        message.setRole("user");
        message.setContent("Original");
        message.setMsgVersion(1);
        message.setCreatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        message.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        message = chatMessageRepository.save(message);

        EditMessageRequest edit = new EditMessageRequest();
        edit.setContent("Updated");
        ChatMessage updated = chatService.editMessage(userId, session.getId(), message.getId(), edit);

        Assertions.assertEquals(2, updated.getMsgVersion());
        Assertions.assertEquals(1, chatMessageRevisionRepository.findByMessageIdOrderByVersionDesc(message.getId()).size());
    }
}
