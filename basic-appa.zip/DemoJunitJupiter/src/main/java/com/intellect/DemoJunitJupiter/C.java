package com.intellect.DemoJunitJupiter;

public class C extends B implements A{

	@Override
	public void m() {
		System.out.println("m method");
	}
	public static void main(String[] args) {
		//A a = new C();
		//((B) a).m1();
		
		//B b = new C();
		//b.m1();
		
		C c = new C();
		c.m();
		c.m1();
		
		A a = (A) new B();
		
		a.m();
		
		
	}
}
