package com.devdocs.ingestion.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class IngestionRequest {
    @NotNull
    private Long documentId;

    @NotBlank
    private String content;

    private Long documentVersionId;
    private Boolean reindex;
    private Boolean refreshVectors;
    private Boolean upsert;
    private String embeddingModel;
    private ChunkingOptions chunking;

    @Data
    public static class ChunkingOptions {
        private String strategy;
        private Integer maxChars;
        private Integer overlap;
    }
}
