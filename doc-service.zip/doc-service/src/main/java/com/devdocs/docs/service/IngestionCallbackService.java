package com.devdocs.docs.service;

import com.devdocs.docs.dto.IngestionCallbackRequest;
import com.devdocs.docs.entity.Document;
import com.devdocs.docs.entity.IngestionJob;
import com.devdocs.docs.repository.DocumentRepository;
import com.devdocs.docs.repository.IngestionJobRepository;
import jakarta.transaction.Transactional;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class IngestionCallbackService {

    private static final String STATUS_COMPLETED = "COMPLETED";
    private static final String STATUS_FAILED = "FAILED";
    private static final String STATUS_PARTIAL = "PARTIAL";

    private final DocumentRepository documentRepository;
    private final IngestionJobRepository ingestionJobRepository;

    @Transactional
    public void handleCallback(IngestionCallbackRequest request) {
        Document document = documentRepository.findByIdForUpdate(request.documentId())
            .orElse(null);
        if (document == null) {
            log.warn("Ingestion callback received for missing document. documentId={}, runId={}",
                request.documentId(), request.runId());
            return;
        }

        IngestionJob job = findJobForUpdate(request, document.getId());
        if (job == null) {
            log.warn("Ingestion callback received without job. documentId={}, runId={}",
                request.documentId(), request.runId());
            return;
        }

        if (isTerminal(document.getStatus()) || isTerminal(job.getStatus())) {
            log.info("Ignoring duplicate ingestion callback. documentId={}, runId={}, status={}",
                request.documentId(), request.runId(), request.status());
            return;
        }

        String newStatus = normalizeStatus(request.status());
        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);

        document.setStatus(newStatus);
        document.setChunkCount(request.chunks());
        document.setEmbeddingCount(request.embeddings());
        document.setDurationMs(request.durationMs());
        document.setErrorCode(request.errorCode());
        document.setErrorMessage(request.errorMessage());
        document.setUpdatedAt(now);

        job.setStatus(newStatus);
        if (request.runId() != null) {
            job.setRunId(request.runId());
        }
        if (request.versionId() != null) {
            job.setVersionId(request.versionId());
        }
        job.setChunkCount(request.chunks());
        job.setEmbeddingCount(request.embeddings());
        job.setDurationMs(request.durationMs());
        job.setErrorCode(request.errorCode());
        job.setErrorMessage(request.errorMessage());
        job.setOccurredAt(request.occurredAt());
        job.setUpdatedAt(now);

        ingestionJobRepository.save(job);
        documentRepository.save(document);
    }

    private IngestionJob findJobForUpdate(IngestionCallbackRequest request, Long documentId) {
        if (request.runId() != null) {
            Optional<IngestionJob> byRun = ingestionJobRepository.findByRunIdForUpdate(request.runId());
            if (byRun.isPresent()) {
                return byRun.get();
            }
        }
        return ingestionJobRepository
            .findLatestByDocumentIdForUpdate(documentId, PageRequest.of(0, 1))
            .stream()
            .findFirst()
            .orElse(null);
    }

    private boolean isTerminal(String status) {
        return STATUS_COMPLETED.equals(status) || STATUS_FAILED.equals(status) || STATUS_PARTIAL.equals(status);
    }

    private String normalizeStatus(String status) {
        if (status == null) return STATUS_FAILED;
        if (STATUS_COMPLETED.equalsIgnoreCase(status)) return STATUS_COMPLETED;
        if (STATUS_FAILED.equalsIgnoreCase(status)) return STATUS_FAILED;
        if (STATUS_PARTIAL.equalsIgnoreCase(status)) return STATUS_PARTIAL;
        return STATUS_FAILED;
    }
}
