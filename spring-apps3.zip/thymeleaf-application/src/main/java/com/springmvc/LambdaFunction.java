package com.springmvc;

public class LambdaFunction{

}
