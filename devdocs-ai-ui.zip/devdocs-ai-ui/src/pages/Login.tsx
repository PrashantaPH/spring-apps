import React, { useState } from "react";
import {
    Box,
    Button,
    TextField,
    Typography,
    IconButton,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMoon, faSun } from "@fortawesome/free-solid-svg-icons";
import { toast } from "react-toastify"; // ✅ ADD
import { useAuth } from "../context/Auth.context";


interface Props {
    mode: "light" | "dark";
    setMode: (mode: "light" | "dark") => void;
}

const Login: React.FC<Props> = ({ mode, setMode }) => {
    const navigate = useNavigate();
    const isDark = mode === "dark";

    const [form, setForm] = useState({
        email: "",
        password: "",
    });

    const [loading, setLoading] = useState(false);

    const handleChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
        setForm({ ...form, [field]: e.target.value });
    };

    const { login: authLogin } = useAuth();

    const handleLogin = async () => {
        try {
            setLoading(true);

            await authLogin(form);

            toast.success("Login successful 🚀");

            // navigate is handled in AuthProvider.login (or can still be used here if needed)
            // navigate("/dashboard");
        } catch (err: any) {
            toast.error(err?.message || "Login failed ❌");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Box
            sx={{
                minHeight: "100vh",
                bgcolor: "background.default",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                position: "relative",
            }}
        >
            {/* Toggle */}
            <IconButton
                onClick={() => setMode(isDark ? "light" : "dark")}
                size="small"
                sx={{ position: "absolute", top: 20, right: 20, color: "primary.main" }}
            >
                <FontAwesomeIcon icon={isDark ? faSun : faMoon} />
            </IconButton>

            <Box sx={{ width: "100%", maxWidth: 405, px: 3, textAlign: "center" }}>

                <Typography sx={{ fontSize: "2.25rem", fontWeight: 900, mb: 1, color: "primary.main" }}>
                    Intelligence Console
                </Typography>

                <Typography variant="body2" sx={{ mb: 3 }}>
                    Powered by <Box component="span" sx={{ color: "primary.main", fontWeight: "bold" }}>DEVDOCS</Box>
                </Typography>

                <Typography variant="h5" sx={{ mb: 2 }}>
                    Sign in
                </Typography>

                <TextField
                    fullWidth
                    label="Email"
                    placeholder="name@work-email.com"
                    size="small"
                    value={form.email}
                    onChange={handleChange("email")}
                    sx={{ mb: 2 }}
                />

                <TextField
                    fullWidth
                    label="Password"
                    type="password"
                    placeholder="enter your password"
                    size="small"
                    value={form.password}
                    onChange={handleChange("password")}
                    sx={{ mb: 2 }}
                />

                <Button
                    fullWidth
                    onClick={handleLogin}
                    disabled={loading}
                    sx={{
                        textTransform: "none",
                        borderRadius: "8px",
                        backgroundColor: "primary.main",
                        color: "primary.contrastText",
                        py: 1,
                    }}
                >
                    {loading ? "Signing in..." : "Sign in With Email"}
                </Button>

                <Typography variant="body2" sx={{ mt: 4 }}>
                    New to DEVDOCS?{" "}
                    <Box
                        component="span"
                        onClick={() => navigate('/register')}
                        sx={{ cursor: "pointer", color: "primary.main" }}
                    >
                        Create an account →
                    </Box>
                </Typography>
            </Box>
        </Box>
    );
};

export default Login;