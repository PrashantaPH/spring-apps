package com.intellect.basics;

public class Basic {

	public static void main(String[] args) {
		
		boolean bol = true;
		String res = Boolean.toString(bol);
		System.out.println(res);
		
		int i = 1;
		
		if(i==1) {
			System.out.println(i);
		}
	}
}
