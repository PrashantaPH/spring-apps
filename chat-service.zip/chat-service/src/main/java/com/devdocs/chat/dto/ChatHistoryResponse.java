package com.devdocs.chat.dto;

import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ChatHistoryResponse {
    Long chatId;
    String title;
    String systemPrompt;
    Long docId;
    List<ChatMessageHistoryDto> messages;
}
