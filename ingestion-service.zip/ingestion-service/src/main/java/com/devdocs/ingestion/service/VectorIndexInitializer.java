package com.devdocs.ingestion.service;

import com.devdocs.common.vector.VectorIndexService;
import com.devdocs.ingestion.entity.DocumentChunk;
import com.devdocs.ingestion.repository.DocumentChunkRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Service to initialize the vector index from existing database records on startup.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class VectorIndexInitializer {

    private final DocumentChunkRepository chunkRepository;
    private final VectorIndexService vectorIndexService;
    private final ObjectMapper objectMapper = new ObjectMapper();

    @PostConstruct
    public void initializeVectorIndex() {
        log.info("Initializing vector index from database...");
        
        try {
            List<DocumentChunk> chunks = chunkRepository.findAll();
            int loaded = 0;
            
            for (DocumentChunk chunk : chunks) {
                try {
                    if (chunk.isActive() && chunk.getEmbedding() != null && !chunk.getEmbedding().isEmpty()) {
                        List<Double> vector = deserializeVector(chunk.getEmbedding());
                        vectorIndexService.addVector(
                            chunk.getChunkId(),
                            vector,
                            chunk.getDocumentId(),
                            chunk.getContent(),
                            true,
                            chunk.getVersionId()
                        );
                        loaded++;
                    }
                } catch (Exception e) {
                    log.warn("Failed to load vector for chunk {}: {}", chunk.getChunkId(), e.getMessage());
                }
            }
            
            log.info("Vector index initialized with {} vectors from {} total chunks", loaded, chunks.size());
        } catch (Exception e) {
            log.error("Failed to initialize vector index", e);
        }
    }

    private List<Double> deserializeVector(String vectorJson) {
        try {
            return objectMapper.readValue(vectorJson, new TypeReference<List<Double>>() {});
        } catch (Exception e) {
            log.error("Failed to deserialize vector: {}", vectorJson, e);
            return List.of();
        }
    }
}
