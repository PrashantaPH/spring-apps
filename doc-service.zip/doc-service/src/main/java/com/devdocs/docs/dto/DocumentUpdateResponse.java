package com.devdocs.docs.dto;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class DocumentUpdateResponse {
    boolean updated;
    DocumentDto document;
}
