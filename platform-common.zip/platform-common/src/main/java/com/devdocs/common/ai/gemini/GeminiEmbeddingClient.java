package com.devdocs.common.ai.gemini;

import com.devdocs.common.ai.EmbeddingClient;
import com.devdocs.common.ai.dto.EmbeddingResponse;
import java.time.Duration;
import java.util.List;
import java.util.Map;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

@Slf4j
@Service
@Profile("local")
@RequiredArgsConstructor
public class GeminiEmbeddingClient implements EmbeddingClient {

    private final WebClient.Builder builder;

    @Value("${ai.provider.base-url}")
    private String baseUrl;

    @Value("${ai.provider.embedding-model}")
    private String embeddingModel;

    @Value("${ai.provider.api-key}")
    private String apiKey;

    @Value("${ai.provider.embedding-dimension:768}")
    private int dimension;

    @Override
    public EmbeddingResponse embed(String text) {
        Map<String, Object> body = Map.of(
                "model", embeddingModel,
                "content", Map.of(
                        "parts", List.of(Map.of("text", text))
                ),
                "outputDimensionality", dimension
        );
        GeminiEmbeddingResponse response = builder.baseUrl(baseUrl)
            .build()
            .post()
            .uri(uriBuilder -> uriBuilder.path("/v1beta/models/{model}:embedContent")
                .queryParam("key", apiKey)
                .build(embeddingModel))
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .bodyValue(body)
            .retrieve()
            .bodyToMono(GeminiEmbeddingResponse.class)
            .block(Duration.ofSeconds(15));

        List<Double> values = response != null ? response.embedding().values : List.of();
        return EmbeddingResponse.builder()
            .vector(values)
            .dimension(dimension)
            .build();
    }

    private record GeminiEmbeddingResponse(Embedding embedding) {
    }

    private record Embedding(List<Double> values) {
    }
}
