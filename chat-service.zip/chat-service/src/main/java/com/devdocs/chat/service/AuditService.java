package com.devdocs.chat.service;

import com.devdocs.chat.entity.AuditEvent;
import com.devdocs.chat.repository.AuditEventRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditEventRepository auditEventRepository;
    private final ObjectMapper objectMapper;

    public void record(Long actorId, String action, String resourceType, String resourceId, Map<String, Object> details) {
        AuditEvent event = new AuditEvent();
        event.setActorId(actorId);
        event.setAction(action);
        event.setResourceType(resourceType);
        event.setResourceId(resourceId);
        event.setCreatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        if (details != null && !details.isEmpty()) {
            try {
                event.setDetails(objectMapper.writeValueAsString(details));
            } catch (JsonProcessingException e) {
                log.warn("Failed to serialize audit details for {} {}", resourceType, resourceId, e);
                event.setDetails("{\"error\":\"failed_to_serialize\"}");
            }
        }
        auditEventRepository.save(event);
    }
}
