package com.devdocs.docs.dto;

import java.time.OffsetDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class DocumentDto {
    Long id;
    String title;
    String status;
    String description;
    String sourceUri;
    Long version;
    Integer contentVersion;
    List<String> tags;
    AclDto acl;
    OffsetDateTime deletedAt;
    Long deletedBy;
    OffsetDateTime createdAt;
    OffsetDateTime updatedAt;
}
