package com.springmvc.app.controller;

import java.util.Arrays;
import java.util.List;

public class Demo {
	
	public static void main(String[] args) {
		
		List<String> arrayList = Arrays.asList("Settler","Settler","Settler");
		
		for(int i = 0; i < arrayList.size(); i++ ) {
			String res = arrayList.get(i);
			if(res.startsWith("Settler")) {
				System.out.println(res);
				arrayList.remove(i);
			}
		}
		System.out.println(arrayList);
	}

}
