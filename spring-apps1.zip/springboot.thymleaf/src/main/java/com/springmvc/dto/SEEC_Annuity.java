package com.springmvc.dto;

public class SEEC_Annuity {

	public int getType() {
		
		return 0;
	}

}
