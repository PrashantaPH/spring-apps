package com.springbatch.app.repo;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springbatch.app.entity.Customer;


public interface CustomerRepo extends JpaRepository<Customer, Serializable> {
	
}
