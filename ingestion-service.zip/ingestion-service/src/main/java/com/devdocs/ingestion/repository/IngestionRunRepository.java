package com.devdocs.ingestion.repository;

import com.devdocs.ingestion.entity.IngestionRun;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IngestionRunRepository extends JpaRepository<IngestionRun, Long> {
}
