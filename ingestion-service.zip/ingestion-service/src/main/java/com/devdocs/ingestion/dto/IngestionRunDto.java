package com.devdocs.ingestion.dto;

import java.time.OffsetDateTime;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class IngestionRunDto {
    Long id;
    Long documentId;
    String status;
    Integer chunkCount;
    OffsetDateTime createdAt;
}
