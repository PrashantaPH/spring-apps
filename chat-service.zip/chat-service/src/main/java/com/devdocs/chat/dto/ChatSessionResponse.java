package com.devdocs.chat.dto;

import java.time.OffsetDateTime;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ChatSessionResponse {
    Long id;
    String title;
    String systemPrompt;
    Long docId;
    OffsetDateTime createdAt;
    OffsetDateTime updatedAt;
}
