import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Avatar,
  Box,
  Button,
  Divider,
  IconButton,
  InputAdornment,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Paper,
  TextField,
  Typography,
  useTheme,
} from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import DeleteIcon from '@mui/icons-material/Delete';

type Message = {
  id: string;
  sender: 'user' | 'bot';
  text?: string;
  createdAt: string;
  fileName?: string;
  file?: File | null;
};

const initialChats = [
  { id: 'c-1', title: 'General' },
  { id: 'c-2', title: 'Project Docs' },
  { id: 'c-3', title: 'Research' },
];

export default function Chat() {
  const theme = useTheme();
  const [chats] = useState(initialChats);
  const [activeChat, setActiveChat] = useState(initialChats[0].id);
  const [messages, setMessages] = useState<Message[]>(() => [
    {
      id: 'm-1',
      sender: 'bot',
      text: 'Hi! I can help with your docs. Ask me anything or upload a file.',
      createdAt: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const bodyRef = useRef<HTMLDivElement | null>(null);

  // Scroll to bottom on message change
  useEffect(() => {
    bodyRef.current?.scrollTo({ top: bodyRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSelectChat = (id: string) => {
    setActiveChat(id);
    // For now, we keep a single message list. In a real app, you'd load per-chat history.
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] ?? null;
    setFile(f);
  };

  const sendUserMessage = (text?: string, attach?: File | null) => {
    const payload: Message = {
      id: `m-${Date.now()}`,
      sender: 'user',
      text: text ?? '',
      fileName: attach?.name,
      file: attach ?? null,
      createdAt: new Date().toISOString(),
    };
    setMessages((m) => [...m, payload]);
    setInput('');
    setFile(null);

    // Simulate bot typing + response (replace with API call)
    setIsTyping(true);
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          id: `m-bot-${Date.now()}`,
          sender: 'bot',
          text:
            attach
              ? `Thanks — I received "${attach?.name}". I can index and answer questions from it.`
              : `I received: "${payload.text}". How would you like me to proceed?`,
          createdAt: new Date().toISOString(),
        },
      ]);
      setIsTyping(false);
    }, 900 + Math.random() * 900);
  };

  const handleSend = () => {
    if (!input.trim() && !file) return;
    sendUserMessage(input.trim(), file);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleDeleteMessage = (id: string) => {
    setMessages((m) => m.filter((x) => x.id !== id));
  };

  const formattedMessages = useMemo(() => messages, [messages]);

  return (
    <Box display="flex" gap={2} height="calc(100vh - 120px)">
      {/* Chat List */}
      <Paper
        sx={{
          width: 260,
          display: 'flex',
          flexDirection: 'column',
          bgcolor: theme.palette.background.paper,
        }}
        elevation={1}
      >
        <Box p={2}>
          <Typography variant="h6">Chats</Typography>
        </Box>
        <Divider />
        <List sx={{ overflowY: 'auto', flex: 1 }}>
          {chats.map((c) => (
            <ListItem
              key={c.id}
              button
              selected={activeChat === c.id}
              onClick={() => handleSelectChat(c.id)}
            >
              <ListItemAvatar>
                <Avatar>{c.title.charAt(0)}</Avatar>
              </ListItemAvatar>
              <ListItemText
                primary={c.title}
                secondary="Tap to open conversation"
                primaryTypographyProps={{ noWrap: true }}
              />
            </ListItem>
          ))}
        </List>
        <Divider />
        <Box p={1} display="flex" justifyContent="space-between" alignItems="center">
          <Typography variant="caption" color="text.secondary">
            New Chat
          </Typography>
          <Button size="small" onClick={() => setMessages([])}>
            Clear
          </Button>
        </Box>
      </Paper>

      {/* Chat Panel */}
      <Box flex={1} display="flex" flexDirection="column">
        {/* Header */}
        <Paper
          elevation={0}
          sx={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            px: 2,
            py: 1,
            bgcolor: theme.palette.background.paper,
            borderBottom: `1px solid ${theme.palette.divider}`,
          }}
        >
          <Box display="flex" alignItems="center" gap={2}>
            <Avatar sx={{ bgcolor: theme.palette.primary.main }}>B</Avatar>
            <Box>
              <Typography variant="subtitle1">DevDocs Bot</Typography>
              <Typography variant="caption" color="text.secondary">
                Ask about uploaded documents or API
              </Typography>
            </Box>
          </Box>

          <Box display="flex" alignItems="center" gap={1}>
            <Button
              size="small"
              variant="outlined"
              startIcon={<UploadFileIcon />}
              onClick={() => document.getElementById('chat-file-input')?.click()}
            >
              Upload
            </Button>
            <input
              id="chat-file-input"
              type="file"
              accept=".pdf,.txt,.md"
              style={{ display: 'none' }}
              onChange={handleFileChange}
            />
          </Box>
        </Paper>

        {/* Messages Body */}
        <Box
          ref={bodyRef}
          sx={{
            flex: 1,
            overflowY: 'auto',
            px: 2,
            py: 3,
            background:
              theme.palette.mode === 'dark'
                ? 'linear-gradient(180deg, rgba(255,255,255,0.02), transparent)'
                : 'transparent',
          }}
        >
          {formattedMessages.map((m) => (
            <Box
              key={m.id}
              display="flex"
              justifyContent={m.sender === 'user' ? 'flex-end' : 'flex-start'}
              mb={1.5}
            >
              <Paper
                elevation={0}
                sx={{
                  maxWidth: '72%',
                  px: 2,
                  py: 1,
                  backgroundColor:
                    m.sender === 'user' ? theme.palette.primary.main : theme.palette.background.paper,
                  color: m.sender === 'user' ? '#fff' : theme.palette.text.primary,
                }}
              >
                <Box display="flex" gap={1} alignItems="center">
                  <Box flex={1}>
                    {m.text && (
                      <Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>
                        {m.text}
                      </Typography>
                    )}
                    {m.fileName && (
                      <Box mt={1}>
                        <Button
                          size="small"
                          variant="outlined"
                          href={m.file ? URL.createObjectURL(m.file) : undefined}
                          target="_blank"
                        >
                          {m.fileName}
                        </Button>
                      </Box>
                    )}
                    <Typography variant="caption" color="text.secondary" mt={0.5} display="block">
                      {new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </Typography>
                  </Box>

                  <Box>
                    <IconButton size="small" onClick={() => handleDeleteMessage(m.id)}>
                      <DeleteIcon fontSize="small" />
                    </IconButton>
                  </Box>
                </Box>
              </Paper>
            </Box>
          ))}

          {/* Typing indicator */}
          {isTyping && (
            <Box display="flex" justifyContent="flex-start" mb={1.5}>
              <Paper
                elevation={0}
                sx={{
                  px: 2,
                  py: 1,
                  background: theme.palette.background.paper,
                }}
              >
                <Box display="flex" alignItems="center" gap={1}>
                  <Box
                    sx={{
                      display: 'flex',
                      gap: 0.6,
                      alignItems: 'flex-end',
                      '& > span': {
                        display: 'block',
                        width: 6,
                        height: 6,
                        borderRadius: '50%',
                        bgcolor: theme.palette.text.primary,
                        animation: 'typing 1s infinite',
                      },
                      '@keyframes typing': {
                        '0%': { transform: 'translateY(0)', opacity: 0.4 },
                        '50%': { transform: 'translateY(-4px)', opacity: 1 },
                        '100%': { transform: 'translateY(0)', opacity: 0.4 },
                      },
                    }}
                  >
                    <span style={{ animationDelay: '0ms' }} />
                    <span style={{ animationDelay: '160ms' }} />
                    <span style={{ animationDelay: '320ms' }} />
                  </Box>
                  <Typography variant="body2" color="text.secondary">
                    Bot is typing...
                  </Typography>
                </Box>
              </Paper>
            </Box>
          )}
        </Box>

        {/* Footer / Composer */}
        <Box
          sx={{
            px: 2,
            py: 1.5,
            borderTop: `1px solid ${theme.palette.divider}`,
            background: theme.palette.background.paper,
          }}
        >
          <Box display="flex" gap={1} alignItems="flex-end">
            <TextField
              fullWidth
              minRows={1}
              maxRows={6}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a message or ask about uploaded docs... (Shift+Enter for newline)"
              multiline
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <input
                      id="composer-file"
                      type="file"
                      accept=".pdf,.txt,.md"
                      style={{ display: 'none' }}
                      onChange={(e) => {
                        const f = e.target.files?.[0] ?? null;
                        setFile(f);
                      }}
                    />
                    <label htmlFor="composer-file">
                      <IconButton size="small" component="span">
                        <UploadFileIcon />
                      </IconButton>
                    </label>
                  </InputAdornment>
                ),
              }}
            />

            <Button
              variant="contained"
              endIcon={<SendIcon />}
              onClick={handleSend}
              sx={{ whiteSpace: 'nowrap' }}
            >
              Send
            </Button>
          </Box>

          {file && (
            <Box display="flex" alignItems="center" gap={1} mt={1}>
              <Typography variant="body2">Selected: {file.name}</Typography>
              <Button size="small" onClick={() => setFile(null)}>
                Remove
              </Button>
            </Box>
          )}
        </Box>
      </Box>
    </Box>
  );
}