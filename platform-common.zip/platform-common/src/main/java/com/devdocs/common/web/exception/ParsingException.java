package com.devdocs.common.web.exception;

public class ParsingException extends RuntimeException {
    public ParsingException() {
        super("Parsing error");
    }

    public ParsingException(String message) {
        super(message);
    }

    public ParsingException(String message, Throwable cause) {
        super(message, cause);
    }
}
