/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { login as loginApi, getCurrentUser, refreshTokens } from '../api/authService.api';
import type { LoginRequest, LoginResponse, User } from '../interface/auth.interface';

type AuthContextType = {
  user: User | null;
  isAuthenticated: boolean;
  isAuthLoading: boolean;
  authError: string | null;
  login: (payload: LoginRequest) => Promise<void>;
  logout: () => void;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const ACCESS_TOKEN_KEY = 'devdocs_ai_access_token';
const REFRESH_TOKEN_KEY = 'devdocs_ai_refresh_token';

const setTokens = (accessToken: string | null, refreshToken: string | null) => {
  if (accessToken) localStorage.setItem(ACCESS_TOKEN_KEY, accessToken);
  else localStorage.removeItem(ACCESS_TOKEN_KEY);

  if (refreshToken) localStorage.setItem(REFRESH_TOKEN_KEY, refreshToken);
  else localStorage.removeItem(REFRESH_TOKEN_KEY);
};

export const AuthProvider: React.FC<React.PropsWithChildren> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const navigate = useNavigate();

  const isAuthenticated = Boolean(user);

  const loadUser = async (): Promise<void> => {
    const accessToken = localStorage.getItem(ACCESS_TOKEN_KEY);
    if (!accessToken) return;

    try {
      setIsAuthLoading(true);
      const currentUser = await getCurrentUser();
      setUser(currentUser);
      setAuthError(null);
    } catch {
      try {
        const refreshToken = localStorage.getItem(REFRESH_TOKEN_KEY);
        if (refreshToken) {
          const refreshPayload = await refreshTokens({ refreshToken });
          setTokens(refreshPayload.accessToken, refreshPayload.refreshToken);
          const currentUser = await getCurrentUser();
          setUser(currentUser);
          return;
        }
      } catch {
        setTokens(null, null);
      }
      setUser(null);
    } finally {
      setIsAuthLoading(false);
    }
  };

  useEffect(() => {
    loadUser();
  }, []);

  const login = async (payload: LoginRequest): Promise<void> => {
    setIsAuthLoading(true);
    try {
      const data: LoginResponse = await loginApi(payload);
      setTokens(data.accessToken, data.refreshToken);
      setUser(data.user);
      setAuthError(null);
      navigate('/dashboard');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Login failed';
      setAuthError(message);
      throw error;
    } finally {
      setIsAuthLoading(false);
    }
  };

  const logout = (): void => {
    setTokens(null, null);
    setUser(null);
    navigate('/login');
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, isAuthLoading, authError, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
