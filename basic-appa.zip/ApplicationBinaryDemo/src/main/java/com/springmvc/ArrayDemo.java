package com.springmvc;

public class ArrayDemo {

	public static void main(String[] args) {
		
		int[] arr1 = {1,2,3};
		
		int[] arr2 = {4,5};
		
		int[] temp = new int[arr1.length + arr2.length];
		
		for(int i=0; i<arr1.length; i++) {
			temp[i] = arr1[i];
		}
		
		for(int i=0; i<arr2.length; i++) {
			temp[arr1.length+i] = arr2[i];
		}
		
		for(int i : temp) {
			System.out.println(i);
		}
	}
}
