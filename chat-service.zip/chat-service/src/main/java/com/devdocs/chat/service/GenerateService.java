package com.devdocs.chat.service;

import com.devdocs.chat.dto.CitationDto;
import com.devdocs.chat.dto.GenerateRequest;
import com.devdocs.chat.dto.GenerateResponse;
import com.devdocs.common.ai.EmbeddingClient;
import com.devdocs.common.ai.LlmClient;
import com.devdocs.common.ai.dto.ChatMessageDto;
import com.devdocs.common.ai.dto.EmbeddingResponse;
import com.devdocs.common.ai.dto.LlmRequest;
import com.devdocs.common.ai.dto.LlmResponse;
import com.devdocs.common.vector.VectorIndexService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class GenerateService {

    private final EmbeddingClient embeddingClient;
    private final LlmClient llmClient;
    private final VectorIndexService vectorIndexService;
    private final ObjectMapper objectMapper;

    @Value("${chat.max-context-chunks}")
    private int maxChunks;

    public GenerateResponse generateReleaseNotes(GenerateRequest request) {
        String system = "You are a release manager. Generate concise release notes with headings: Summary, Changes, Fixes, Risks.";
        return generateWithPrompt(system, request);
    }

    public GenerateResponse generateUserStories(GenerateRequest request) {
        String system = "You are a product manager. Generate user stories with acceptance criteria in bullet lists.";
        return generateWithPrompt(system, request);
    }

    public GenerateResponse generateOnboardingSummary(GenerateRequest request) {
        String system = "You are a staff engineer. Generate a concise onboarding summary with key systems, setup steps, and links.";
        return generateWithPrompt(system, request);
    }

    private GenerateResponse generateWithPrompt(String systemPrompt, GenerateRequest request) {
        String input = buildInput(request);
        List<String> contextChunks = request.useRag() != null && request.useRag()
            ? fetchNearestChunks(request.docId(), input)
            : List.of();

        List<ChatMessageDto> messages = new ArrayList<>();
        messages.add(ChatMessageDto.builder()
            .role("system")
            .content(systemPrompt)
            .build());

        for (String chunk : contextChunks) {
            messages.add(ChatMessageDto.builder()
                .role("system")
                .content("Context: " + chunk)
                .build());
        }

        messages.add(ChatMessageDto.builder()
            .role("user")
            .content(input)
            .build());

        LlmResponse response = llmClient.chat(LlmRequest.builder().messages(messages).build());

        return GenerateResponse.builder()
            .output(response.getAnswer())
            .citations(buildCitations(request.docId(), contextChunks))
            .build();
    }

    private String buildInput(GenerateRequest request) {
        if (request.structured() != null && !request.structured().isEmpty()) {
            try {
                String json = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(request.structured());
                return request.input() == null ? json : request.input() + "\n\nStructured input:\n" + json;
            } catch (JsonProcessingException e) {
                return request.input() == null ? "" : request.input();
            }
        }
        return request.input() == null ? "" : request.input();
    }

    private List<String> fetchNearestChunks(Long docId, String input) {
        EmbeddingResponse embedding = embeddingClient.embed(input == null ? "" : input);
        return vectorIndexService.searchSimilar(embedding.getVector(), docId, maxChunks)
            .stream()
            .map(VectorIndexService.VectorSearchResult::getContent)
            .toList();
    }

    private List<CitationDto> buildCitations(Long docId, List<String> contextChunks) {
        if (contextChunks.isEmpty() || docId == null) {
            return List.of();
        }
        return List.of(CitationDto.builder()
            .docId(docId)
            .title("Document " + docId)
            .url("https://docs.devdocs.ai/docs/" + docId)
            .build());
    }
}
