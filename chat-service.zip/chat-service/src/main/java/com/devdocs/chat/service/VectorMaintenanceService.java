package com.devdocs.chat.service;

import com.devdocs.chat.repository.DocumentChunkRepository;
import com.devdocs.common.vector.VectorIndexService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class VectorMaintenanceService {

    private final DocumentChunkRepository documentChunkRepository;
    private final VectorIndexService vectorIndexService;

    @Transactional
    public void updateDocumentVectors(Long documentId, String mode) {
        if (documentId == null) {
            return;
        }
        if ("hard".equalsIgnoreCase(mode)) {
            documentChunkRepository.deleteByDocumentId(documentId);
            vectorIndexService.removeDocumentVectors(documentId);
            log.info("Hard deleted chat vectors for document {}", documentId);
            return;
        }

        documentChunkRepository.updateActiveByDocumentId(documentId, false);
        vectorIndexService.setActiveByDocumentId(documentId, false);
        log.info("Soft deactivated chat vectors for document {}", documentId);
    }
}
