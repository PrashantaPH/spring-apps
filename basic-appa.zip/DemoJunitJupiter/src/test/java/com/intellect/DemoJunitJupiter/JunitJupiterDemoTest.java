/**
 * 
 */
package com.intellect.DemoJunitJupiter;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

/**
 * @author P65787
 *
 */
//@TestInstance(Lifecycle.PER_CLASS)
class JunitJupiterDemoTest {

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		JunitJupiterDemo jupiterDemo = new JunitJupiterDemo();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeEach
	void setUp() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	//@DisplayName("0")
	//@EnabledOnOs(value = OS.WINDOWS)
	//@RepeatedTest(value = 3)
	void testSum() {
		JunitJupiterDemo demo = new JunitJupiterDemo();
		
		//assertThrows(NumberFormatException.class,()-> demo.sum(1111111111, 3));
		assertEquals(4, demo.sum(2, 2));
		//fail("Not yet implemented");
	}

}
