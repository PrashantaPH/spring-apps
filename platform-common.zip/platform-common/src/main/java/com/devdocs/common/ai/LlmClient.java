package com.devdocs.common.ai;

import com.devdocs.common.ai.dto.LlmRequest;
import com.devdocs.common.ai.dto.LlmResponse;

public interface LlmClient {
    LlmResponse chat(LlmRequest request);
}
