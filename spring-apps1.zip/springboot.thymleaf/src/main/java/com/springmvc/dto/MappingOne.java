package com.springmvc.dto;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class MappingOne {

	public static void main(String[] args) {
		Illustration illustration = new Illustration();
		SEEC_Annuity seecAnnuityObj = new SEEC_Annuity();
		
		if(seecAnnuityObj != null && seecAnnuityObj.getType() == 0)
			illustration.setSchemeTypeID(1);
		if(seecAnnuityObj != null && seecAnnuityObj.getType() == 1)
			illustration.setSchemeTypeID(2);
		if(seecAnnuityObj != null && seecAnnuityObj.getType() == 2)
			illustration.setSchemeTypeID(11);
		if(seecAnnuityObj != null && seecAnnuityObj.getType() == 3)
			illustration.setSchemeTypeID(3);
		if(seecAnnuityObj != null && seecAnnuityObj.getType() == 4)
			illustration.setSchemeTypeID(5);
		if(seecAnnuityObj != null && seecAnnuityObj.getType() == 5)
			illustration.setSchemeTypeID(4);
		
		System.out.println(illustration.getSchemaTypeID());
		
		Map<Integer, Integer> schemeTypeMapping = new HashMap<>();
		int schemeTypeIdArr1[] = {1,6};
		Arrays.stream(schemeTypeIdArr1).forEach(index -> schemeTypeMapping.put(0, index));
		//schemeTypeMapping.put(0, 1);
		schemeTypeMapping.put(1, 2);
		schemeTypeMapping.put(2, 11);
		schemeTypeMapping.put(3, 3);
		schemeTypeMapping.put(4, 5);
		schemeTypeMapping.put(5, 4);
		
		if(seecAnnuityObj != null) {
			int schemeType = seecAnnuityObj.getType();
			if(schemeTypeMapping.containsKey(schemeType)) {
				int illustrationSchemeTypeID = schemeTypeMapping.get(schemeType);
				illustration.setSchemeTypeID(illustrationSchemeTypeID);
			}
		}
		
		System.out.println(illustration.getSchemaTypeID());
	}
}
