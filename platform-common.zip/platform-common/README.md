# platform-common

Shared library for DevDocs services. All reusable DTOs, exceptions, filters, and utilities must live here under the `com.devdocs.common` package tree.

## Usage examples

### Shared exceptions

```java
import com.devdocs.common.exception.NotFoundException;

throw new NotFoundException("Document not found.");
```

### Shared service-token filter

```java
@Component
public class ServiceTokenAuthenticationFilter extends ServiceTokenAuthenticationFilterBase {
    public ServiceTokenAuthenticationFilter(SecurityErrorHandler securityErrorHandler,
        @Value("${service.auth.token}") String serviceToken) {
        super(securityErrorHandler, serviceToken, "/api/v1/ingestions", false);
    }
}
```

### Shared DTOs

```java
import com.devdocs.common.dto.VectorMaintenanceRequest;

public ResponseEntity<Void> update(@Valid @RequestBody VectorMaintenanceRequest request) {
    // use request.getMode()
}
```
