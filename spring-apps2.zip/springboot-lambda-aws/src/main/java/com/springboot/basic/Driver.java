package com.springboot.basic;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Driver {

	public static void main(String[] args) {
		
		String message = "Prashanta";
		
		String message1 = test(message);
		
		StringBuffer stringBuilder = new StringBuffer();
		
		stringBuilder.append("{\"event\":").append("\""+message1+"\"").append("}");
		
		System.out.println(stringBuilder);
	}
	
	public static String test(String message1) {
		
		JSONParser parser = new JSONParser();
		JSONObject jsonObj = new JSONObject();
		
		JSONObject newObject = null;
		
		try {
			newObject = (JSONObject)parser.parse(message1);
			
			if(newObject.get("Name") != null) {
				jsonObj.put("Name", newObject.get("Name"));
			}
			
		}catch (Exception e) {
			e.getMessage();
		}
		return jsonObj.toJSONString();
	}
}
