import httpClient from './httpClient.api';
import type { LoginRequest, SignupRequest, RefreshRequest, LoginResponse, User } from '../interface/auth.interface';

export type AuthStatus = {
  accessToken: string;
  refreshToken: string;
  user: User;
};

export const signup = async (payload: SignupRequest): Promise<User> => {
  const { data } = await httpClient.post<User>('/v1/auth/signup', payload);
  return data;
};

export const login = async (payload: LoginRequest): Promise<LoginResponse> => {
  const { data } = await httpClient.post<LoginResponse>('/v1/auth/login', payload);
  return data;
};

export const refreshTokens = async (payload: RefreshRequest): Promise<LoginResponse> => {
  const { data } = await httpClient.post<LoginResponse>('/v1/auth/refresh', payload);
  return data;
};

export const getCurrentUser = async (): Promise<User> => {
  const { data } = await httpClient.get<User>('/v1/auth/me');
  return data;
};
