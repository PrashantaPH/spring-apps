package com.devdocs.docs.service;

import com.devdocs.docs.dto.AclDto;
import com.devdocs.docs.dto.BatchDeleteRequest;
import com.devdocs.docs.dto.BatchDeleteResponse;
import com.devdocs.docs.dto.CreateDocRequest;
import com.devdocs.docs.dto.DeleteResult;
import com.devdocs.docs.dto.DocumentDto;
import com.devdocs.docs.dto.DocumentReplaceRequest;
import com.devdocs.docs.dto.DocumentUpdateResponse;
import com.devdocs.docs.dto.PatchDocRequest;
import com.devdocs.docs.dto.ReindexRequest;
import com.devdocs.docs.dto.ReindexResponse;
import com.devdocs.docs.entity.Document;
import com.devdocs.docs.entity.DocumentVersion;
import com.devdocs.docs.entity.IngestionJob;
import com.devdocs.docs.event.IngestionRequestedEvent;
import com.devdocs.docs.repository.DocumentRepository;
import com.devdocs.docs.repository.DocumentVersionRepository;
import com.devdocs.docs.repository.IngestionJobRepository;
import com.devdocs.common.exception.ConflictException;
import com.devdocs.common.exception.ForbiddenException;
import com.devdocs.common.exception.NotFoundException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class DocService {

    private static final String STATUS_DELETED = "DELETED";

    private final DocumentRepository documentRepository;
    private final DocumentVersionRepository documentVersionRepository;
    private final IngestionJobRepository ingestionJobRepository;
    private final ApplicationEventPublisher eventPublisher;
    private final AuditService auditService;
    private final VectorMaintenanceClient vectorMaintenanceClient;
    private final ObjectMapper objectMapper;

    public List<DocumentDto> listDocuments(Long ownerId, boolean includeDeleted) {
        List<Document> docs = includeDeleted
            ? documentRepository.findByOwnerId(ownerId)
            : documentRepository.findByOwnerIdAndStatusNot(ownerId, STATUS_DELETED);

        Collections.reverse(docs); // reverse the list in-place to show most recent first
        return docs.stream().map(this::toDto).collect(Collectors.toList());
    }

    @Transactional
    public DocumentDto createDocument(Long ownerId, CreateDocRequest request) {
        return createDocument(ownerId, request.getTitle(), request.getContent(), request.getDescription(), request.getSourceUri());
    }

    @Transactional
    public DocumentDto createDocument(Long ownerId, String title, String content, String description, String sourceUri) {
        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
        String sanitizedTitle = sanitizeForWin1252(title);
        String sanitizedDescription = sanitizeForWin1252(description);
        String sanitizedSourceUri = sanitizeForWin1252(sourceUri);
        String sanitizedContent = sanitizeForWin1252(content);
        String checksum = checksum(sanitizedContent);

        Document document = new Document();
        document.setTitle(sanitizedTitle);
        document.setDescription(sanitizedDescription);
        document.setSourceUri(sanitizedSourceUri);
        document.setContent(sanitizedContent);
        document.setOwnerId(ownerId);
        document.setStatus("PROCESSING");
        document.setCreatedAt(now);
        document.setUpdatedAt(now);
        Document saved = documentRepository.save(document);

        DocumentVersion version = new DocumentVersion();
        version.setDocument(saved);
        version.setVersionNum(1);
        version.setChecksum(checksum);
        version.setContent(sanitizedContent);
        version.setCurrent(true);
        version.setCreatedAt(now);
        version.setCreatedBy(ownerId);
        DocumentVersion savedVersion = documentVersionRepository.save(version);

        IngestionJob job = new IngestionJob();
        job.setDocument(saved);
        job.setStatus("QUEUED");
        job.setVersionId(savedVersion.getId());
        job.setCreatedAt(now);
        job.setUpdatedAt(now);
        ingestionJobRepository.save(job);

        eventPublisher.publishEvent(new IngestionRequestedEvent(saved.getId(), savedVersion.getId(), saved.getContent(), null));
        auditService.record(ownerId, "DOC_CREATE", "DOCUMENT", String.valueOf(saved.getId()),
            Map.of("versionId", savedVersion.getId()));
        return toDto(saved);
    }

    @Transactional
    public DocumentUpdateResponse replaceDocument(Long ownerId, Long documentId, DocumentReplaceRequest request, String ifMatch) {
        Document document = findForUpdate(documentId);
        enforceAccess(ownerId, document);
        ensureNotDeleted(document);
        checkIfMatch(document, ifMatch);

        boolean metadataChanged = false;
        if (request.getTitle() != null && !request.getTitle().equals(document.getTitle())) {
            document.setTitle(request.getTitle());
            metadataChanged = true;
        }
        if (request.getDescription() != null && !request.getDescription().equals(document.getDescription())) {
            document.setDescription(request.getDescription());
            metadataChanged = true;
        }
        if (request.getSourceUri() != null && !request.getSourceUri().equals(document.getSourceUri())) {
            document.setSourceUri(request.getSourceUri());
            metadataChanged = true;
        }

        DocumentVersion current = ensureCurrentVersion(document, ownerId);

        boolean contentChanged = !current.getChecksum().equals(request.getChecksum());
        if (!contentChanged && !metadataChanged) {
            return DocumentUpdateResponse.builder()
                .updated(false)
                .document(toDto(document))
                .build();
        }

        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
        document.setUpdatedAt(now);
        if (contentChanged) {
            current.setCurrent(false);
            documentVersionRepository.save(current);

            DocumentVersion next = new DocumentVersion();
            next.setDocument(document);
            next.setVersionNum(current.getVersionNum() + 1);
            next.setChecksum(request.getChecksum());
            next.setContent(request.getContent());
            next.setCurrent(true);
            next.setCreatedAt(now);
            next.setCreatedBy(ownerId);
            DocumentVersion savedVersion = documentVersionRepository.save(next);

            document.setContent(request.getContent());
            document.setStatus("PROCESSING");
            documentRepository.save(document);

            IngestionJob job = new IngestionJob();
            job.setDocument(document);
            job.setStatus("QUEUED");
            job.setVersionId(savedVersion.getId());
            job.setCreatedAt(now);
            job.setUpdatedAt(now);
            ingestionJobRepository.save(job);

            if (request.isReindex()) {
                ReindexRequest reindexRequest = new ReindexRequest();
                reindexRequest.setRefreshVectors(true);
                reindexRequest.setUpsert(true);
                eventPublisher.publishEvent(new IngestionRequestedEvent(document.getId(), savedVersion.getId(), request.getContent(), reindexRequest));
            }
            auditService.record(ownerId, "DOC_REPLACE", "DOCUMENT", String.valueOf(document.getId()),
                Map.of("versionId", savedVersion.getId(), "reindex", request.isReindex()));
        } else {
            documentRepository.save(document);
            auditService.record(ownerId, "DOC_METADATA_UPDATE", "DOCUMENT", String.valueOf(document.getId()), Map.of());
        }

        return DocumentUpdateResponse.builder()
            .updated(true)
            .document(toDto(document))
            .build();
    }

    @Transactional
    public DocumentDto patchDocument(Long ownerId, Long documentId, PatchDocRequest request, String ifMatch) {
        Document document = findForUpdate(documentId);
        enforceAccess(ownerId, document);
        ensureNotDeleted(document);
        checkIfMatch(document, ifMatch);

        if (request.getTitle() != null) {
            document.setTitle(request.getTitle());
        }
        if (request.getDescription() != null) {
            document.setDescription(request.getDescription());
        }
        if (request.getSourceUri() != null) {
            document.setSourceUri(request.getSourceUri());
        }
        if (request.getTags() != null) {
            document.setTagsJson(writeJson(request.getTags()));
        }
        if (request.getAcl() != null) {
            document.setAclJson(writeJson(request.getAcl()));
        }
        document.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        documentRepository.save(document);

        auditService.record(ownerId, "DOC_PATCH", "DOCUMENT", String.valueOf(documentId), Map.of());
        return toDto(document);
    }

    @Transactional
    public ReindexResponse reindexDocument(Long ownerId, Long documentId, ReindexRequest request) {
        Document document = findForUpdate(documentId);
        enforceAccess(ownerId, document);
        ensureNotDeleted(document);
        DocumentVersion current = ensureCurrentVersion(document, ownerId);

        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
        document.setStatus("PROCESSING");
        document.setUpdatedAt(now);
        documentRepository.save(document);

        IngestionJob job = new IngestionJob();
        job.setDocument(document);
        job.setStatus("QUEUED");
        job.setVersionId(current.getId());
        job.setCreatedAt(now);
        job.setUpdatedAt(now);
        ingestionJobRepository.save(job);

        eventPublisher.publishEvent(new IngestionRequestedEvent(document.getId(), current.getId(), current.getContent(), request));
        auditService.record(ownerId, "DOC_REINDEX", "DOCUMENT", String.valueOf(documentId), Map.of("versionId", current.getId()));

        return ReindexResponse.builder()
            .reindexRequested(true)
            .document(toDto(document))
            .build();
    }

    @Transactional
    public DeleteResult deleteDocument(Long ownerId, Long documentId, String mode, boolean deleteVectors, boolean purgeBinary, boolean isAdmin) {
        Document document = documentRepository.findByIdForUpdate(documentId)
            .orElse(null);
        if (document == null) {
            return DeleteResult.builder()
                .documentId(documentId)
                .deleted(false)
                .status("NOT_FOUND")
                .message("Document not found")
                .build();
        }

        enforceAccess(ownerId, document);

        if ("hard".equalsIgnoreCase(mode)) {
            if (!isAdmin && !ownerId.equals(document.getOwnerId())) {
                throw new ForbiddenException("Hard delete requires ownership or admin role.");
            }
            ingestionJobRepository.deleteByDocumentId(documentId);
            documentVersionRepository.deleteByDocumentId(documentId);
            documentRepository.delete(document);
            if (deleteVectors) {
                vectorMaintenanceClient.updateIngestionVectors(documentId, "hard");
                vectorMaintenanceClient.updateChatVectors(documentId, "hard");
            }
            auditService.record(ownerId, "DOC_DELETE_HARD", "DOCUMENT", String.valueOf(documentId),
                Map.of("deleteVectors", deleteVectors, "purgeBinary", purgeBinary));
            return DeleteResult.builder()
                .documentId(documentId)
                .deleted(true)
                .status("DELETED")
                .message("Document permanently deleted")
                .build();
        }

        if (STATUS_DELETED.equalsIgnoreCase(document.getStatus())) {
            return DeleteResult.builder()
                .documentId(documentId)
                .deleted(true)
                .status("ALREADY_DELETED")
                .message("Document already deleted")
                .build();
        }

        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
        document.setStatus(STATUS_DELETED);
        document.setDeletedAt(now);
        document.setDeletedBy(ownerId);
        document.setUpdatedAt(now);
        documentRepository.save(document);
        if (deleteVectors) {
            vectorMaintenanceClient.updateIngestionVectors(documentId, "soft");
            vectorMaintenanceClient.updateChatVectors(documentId, "soft");
        }
        auditService.record(ownerId, "DOC_DELETE_SOFT", "DOCUMENT", String.valueOf(documentId),
            Map.of("deleteVectors", deleteVectors, "purgeBinary", purgeBinary));

        return DeleteResult.builder()
            .documentId(documentId)
            .deleted(true)
            .status("DELETED")
            .message("Document soft deleted")
            .build();
    }

    @Transactional
    public BatchDeleteResponse deleteDocuments(Long ownerId, BatchDeleteRequest request, boolean isAdmin) {
        List<DeleteResult> results = new ArrayList<>();
        boolean deleteVectors = request.getDeleteVectors() != null && request.getDeleteVectors();
        boolean purgeBinary = request.getPurgeBinary() != null && request.getPurgeBinary();
        for (Long documentId : request.getDocumentIds()) {
            try {
                results.add(deleteDocument(ownerId, documentId, request.getMode(), deleteVectors, purgeBinary, isAdmin));
            } catch (Exception ex) {
                log.warn("Failed to delete document {}", documentId, ex);
                results.add(DeleteResult.builder()
                    .documentId(documentId)
                    .deleted(false)
                    .status("FAILED")
                    .message(ex.getMessage())
                    .build());
            }
        }
        return BatchDeleteResponse.builder().results(results).build();
    }

    private Document findForUpdate(Long documentId) {
        return documentRepository.findByIdForUpdate(documentId)
            .orElseThrow(() -> new NotFoundException("Document not found."));
    }

    private DocumentVersion ensureCurrentVersion(Document document, Long ownerId) {
        Optional<DocumentVersion> current = documentVersionRepository.findCurrentByDocumentId(document.getId());
        if (current.isPresent()) {
            return current.get();
        }
        if (document.getContent() == null || document.getContent().isBlank()) {
            throw new NotFoundException("Current document content not available.");
        }
        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
        DocumentVersion version = new DocumentVersion();
        version.setDocument(document);
        version.setVersionNum(1);
        version.setChecksum(checksum(document.getContent()));
        version.setContent(document.getContent());
        version.setCurrent(true);
        version.setCreatedAt(now);
        version.setCreatedBy(ownerId);
        return documentVersionRepository.save(version);
    }

    private void enforceAccess(Long ownerId, Document document) {
        if (ownerId.equals(document.getOwnerId())) {
            return;
        }
        AclDto acl = readAcl(document.getAclJson());
        if (acl != null && Boolean.TRUE.equals(acl.getIsPublic())) {
            return;
        }
        if (acl != null && acl.getAllowedUserIds() != null && acl.getAllowedUserIds().contains(ownerId)) {
            return;
        }
        throw new ForbiddenException("Access denied to document.");
    }

    private void ensureNotDeleted(Document document) {
        if (STATUS_DELETED.equalsIgnoreCase(document.getStatus())) {
            throw new ConflictException("Document is deleted and cannot be modified.");
        }
    }

    private void checkIfMatch(Document document, String ifMatch) {
        if (ifMatch == null || ifMatch.isBlank()) {
            return;
        }
        String trimmed = ifMatch.replace("W/", "").replace("\"", "");
        Long expected = document.getVersion();
        if (expected != null && !expected.toString().equals(trimmed)) {
            throw new ConflictException("Document version conflict. Please refresh and retry.");
        }
    }

    private DocumentDto toDto(Document document) {
        DocumentVersion current = documentVersionRepository.findCurrentByDocumentId(document.getId()).orElse(null);
        return DocumentDto.builder()
            .id(document.getId())
            .title(document.getTitle())
            .description(document.getDescription())
            .sourceUri(document.getSourceUri())
            .status(document.getStatus())
            .version(document.getVersion())
            .contentVersion(current == null ? null : current.getVersionNum())
            .tags(readTags(document.getTagsJson()))
            .acl(readAcl(document.getAclJson()))
            .deletedAt(document.getDeletedAt())
            .deletedBy(document.getDeletedBy())
            .createdAt(document.getCreatedAt())
            .updatedAt(document.getUpdatedAt())
            .build();
    }

    private String checksum(String content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(content == null ? new byte[0] : content.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception ex) {
            throw new IllegalStateException("Failed to compute checksum", ex);
        }
    }

    private String writeJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("Unable to serialize metadata.");
        }
    }

    private List<String> readTags(String tagsJson) {
        if (tagsJson == null || tagsJson.isBlank()) {
            return Collections.emptyList();
        }
        try {
            return objectMapper.readValue(tagsJson, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            log.warn("Failed to parse tags", e);
            return Collections.emptyList();
        }
    }

    private AclDto readAcl(String aclJson) {
        if (aclJson == null || aclJson.isBlank()) {
            return null;
        }
        try {
            return objectMapper.readValue(aclJson, AclDto.class);
        } catch (Exception e) {
            log.warn("Failed to parse ACL", e);
            return null;
        }
    }

    private String sanitizeForWin1252(String value) {
        if (value == null) {
            return null;
        }
        CharsetEncoder encoder = Charset.forName("Windows-1252").newEncoder()
            .onMalformedInput(CodingErrorAction.REPLACE)
            .onUnmappableCharacter(CodingErrorAction.REPLACE)
            .replaceWith(new byte[] { (byte) '?' });
        try {
            ByteBuffer buffer = encoder.encode(CharBuffer.wrap(value));
            return Charset.forName("Windows-1252").decode(buffer).toString();
        } catch (Exception ex) {
            return value.getBytes(StandardCharsets.UTF_8).length > 0 ? value.replaceAll("[^\\x00-\\x7F]", "?") : value;
        }
    }
}
