package com.basic;

import java.util.ArrayList;
import java.util.List;

//@SpringBootApplication
public class BasicApplication {

	public static void main(String[] args) {
		ArrayList<Party> arrayList = getPartyList();
		for (Party party : arrayList) {
			if(party.getName().equals("Parson"))
			{
				arrayList.remove(0);
			}
		}
		System.out.println(arrayList);
	}
	
	private ArrayList<Party> getFilterpartyList(){
		
		ArrayList<Party> arrayList = new ArrayList<>();
		
		for (Party party : getPartyList()) {
			if(party.getName().equals("Parson"))
			{
				arrayList.add(party);
			}
		}
		return arrayList;
	}

	private static ArrayList<Party> getPartyList(){
		Party party = new Party();
		party.setId("PARTY1234");
		party.setName("Organisation");
		
		Party party1 = new Party();
		party1.setId("PARTY1234");
		party1.setName("Parson");
		
		ArrayList<Party> arrayList = new ArrayList<>();
		arrayList.add(party);
		arrayList.add(party1);
		
		return arrayList;
	}
}
