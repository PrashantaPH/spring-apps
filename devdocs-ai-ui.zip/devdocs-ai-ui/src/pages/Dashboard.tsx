import { Box, Card, CardContent, Container, Typography, Alert } from '@mui/material';
import { formatNumber } from '../utils/format';

const Dashboard = () => {

  return (
    <Container maxWidth="lg" sx={{ mt: 3 }}>
      <Typography variant="h4" gutterBottom>
        Dashboard
      </Typography>
    </Container>
  );
};

export default Dashboard;
