package com.devdocs.docs.controller;

import com.devdocs.docs.dto.IngestionCallbackRequest;
import com.devdocs.docs.service.IngestionCallbackService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/ingestions/callbacks")
@RequiredArgsConstructor
public class IngestionCallbackController {

    private final IngestionCallbackService ingestionCallbackService;

    @PostMapping("/result")
    public ResponseEntity<Void> handleResult(@Valid @RequestBody IngestionCallbackRequest request) {
        ingestionCallbackService.handleCallback(request);
        return ResponseEntity.ok().build();
    }
}
