package com.practice;

import java.util.ArrayList;

public class Driver {

	public static void main(String[] args) {
		ArrayList<String> arrayList = new ArrayList<String>();
		
//		arrayList.add("A");
//		arrayList.add("B");
//		arrayList.add("D");
//		arrayList.add("C");
//		arrayList.add("B");
//		
//		System.out.println(arrayList.indexOf("B"));
//		System.out.println(arrayList.lastIndexOf("B"));
		
//		Parent parent = (test) -> (test);
//		test("Test", parent);
		
	}
	public static void test(String str, Parent parent) {
		String res = parent.parentMethod(str);
		System.out.println(res);
	}
}
