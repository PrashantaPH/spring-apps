package com.springmvc;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FilterAndMapping {

	public static void main(String[] args) {
		
		List<String> list = new ArrayList<>(Arrays.asList("PIB","PIIB"));
		
		
		String[] productArr = {"PIB"};
		
		String prd = Arrays.stream(productArr)
				.filter(product -> product!= null)
				.filter(product -> product.equalsIgnoreCase("PIB"))
				.map(product -> product)
				.findFirst()
				.orElse(null);
		
		if(list.contains(prd)) {
			System.out.println(prd);
		}
	}
}
