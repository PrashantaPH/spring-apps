package com.devdocs.common.web.exception;

public class EmbeddingException extends RuntimeException {
    public EmbeddingException() {
        super("Embedding generation failed");
    }

    public EmbeddingException(String message) {
        super(message);
    }

    public EmbeddingException(String message, Throwable cause) {
        super(message, cause);
    }
}
