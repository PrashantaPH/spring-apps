package com.devdocs.common.web;

import com.devdocs.common.exception.ConflictException;
import com.devdocs.common.exception.ForbiddenException;
import com.devdocs.common.exception.NotFoundException;
import com.devdocs.common.security.TokenExpiredAuthenticationException;
import com.devdocs.common.web.exception.DatabaseConnectivityException;
import com.devdocs.common.web.exception.EmbeddingException;
import com.devdocs.common.web.exception.InvalidCredentialsException;
import com.devdocs.common.web.exception.LlmCallException;
import com.devdocs.common.web.exception.NetworkTimeoutException;
import com.devdocs.common.web.exception.ParsingException;
import com.devdocs.common.web.exception.RateLimitExceededException;
import com.devdocs.common.web.exception.UserAlreadyExistsException;
import com.devdocs.common.web.exception.UserNotFoundException;
import com.fasterxml.jackson.core.JsonProcessingException;
import jakarta.validation.ConstraintViolationException;
import java.net.SocketTimeoutException;
import java.sql.SQLNonTransientConnectionException;
import java.sql.SQLTransientConnectionException;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.concurrent.TimeoutException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
//import org.springframework.dao.DataAccessException;
//import org.hibernate.exception.JDBCConnectionException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
//import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.validation.BindException;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<ApiError> handleUserExists(UserAlreadyExistsException ex) {
        return buildError(HttpStatus.CONFLICT, ErrorCode.USER_EXISTS,
            "This user already exists. Try logging in or use a different account.", ex);
    }

    @ExceptionHandler(UserNotFoundException.class)
    public ResponseEntity<ApiError> handleUserNotFound(UserNotFoundException ex) {
        return buildError(HttpStatus.NOT_FOUND, ErrorCode.USER_NOT_FOUND,
            "User not found. Please verify your details or register a new account.", ex);
    }

    @ExceptionHandler(InvalidCredentialsException.class)
    public ResponseEntity<ApiError> handleInvalidCredentials(InvalidCredentialsException ex) {
        return buildError(HttpStatus.UNAUTHORIZED, ErrorCode.UNAUTHORIZED,
            "You are not authorized to perform this action. Please reauthenticate or contact support.", ex);
    }

    @ExceptionHandler(TokenExpiredAuthenticationException.class)
    public ResponseEntity<ApiError> handleTokenExpired(TokenExpiredAuthenticationException ex) {
        return buildError(HttpStatus.UNAUTHORIZED, ErrorCode.TOKEN_EXPIRED,
            "Your session has expired. Please log in again.", ex);
    }

    @ExceptionHandler({AuthenticationException.class})
    public ResponseEntity<ApiError> handleAuthentication(AuthenticationException ex) {
        return buildError(HttpStatus.UNAUTHORIZED, ErrorCode.UNAUTHORIZED,
            "You are not authorized to perform this action. Please reauthenticate or contact support.", ex);
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiError> handleAccessDenied(AccessDeniedException ex) {
        return buildError(HttpStatus.FORBIDDEN, ErrorCode.FORBIDDEN,
            "You are not authorized to perform this action. Please reauthenticate or contact support.", ex);
    }

    @ExceptionHandler({MethodArgumentNotValidException.class, BindException.class,
        MethodArgumentTypeMismatchException.class, MissingServletRequestParameterException.class,
        ConstraintViolationException.class, IllegalArgumentException.class})
    public ResponseEntity<ApiError> handleValidation(Exception ex) {
        return buildError(HttpStatus.BAD_REQUEST, ErrorCode.VALIDATION_ERROR,
            "Input validation failed. Please check the required fields and try again.", ex);
    }

//    @ExceptionHandler(NoHandlerFoundException.class)
//    public ResponseEntity<ApiError> handleNoHandlerFound(NoHandlerFoundException ex) {
//        return buildError(HttpStatus.NOT_FOUND, ErrorCode.NOT_FOUND,
//            "The requested resource was not found. Please verify the ID or try again.", ex);
//    }

    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<ApiError> handleNotFound(NotFoundException ex) {
        return buildError(HttpStatus.NOT_FOUND, ErrorCode.NOT_FOUND, ex.getMessage(), ex);
    }

    @ExceptionHandler(ForbiddenException.class)
    public ResponseEntity<ApiError> handleForbidden(ForbiddenException ex) {
        return buildError(HttpStatus.FORBIDDEN, ErrorCode.FORBIDDEN, ex.getMessage(), ex);
    }

    @ExceptionHandler(ConflictException.class)
    public ResponseEntity<ApiError> handleConflict(ConflictException ex) {
        return buildError(HttpStatus.CONFLICT, ErrorCode.CONFLICT, ex.getMessage(), ex);
    }

    @ExceptionHandler({HttpMessageNotReadableException.class, JsonProcessingException.class, ParsingException.class})
    public ResponseEntity<ApiError> handleParsing(Exception ex) {
        return buildError(HttpStatus.BAD_REQUEST, ErrorCode.PARSING_ERROR,
            "There was an issue reading the data. Ensure proper formatting and retry.", ex);
    }

    @ExceptionHandler({HttpRequestMethodNotSupportedException.class})
    public ResponseEntity<ApiError> handleMethodNotAllowed(Exception ex) {
        return buildError(HttpStatus.METHOD_NOT_ALLOWED, ErrorCode.METHOD_NOT_ALLOWED,
            "This endpoint does not support the requested HTTP method. Please check the API documentation.", ex);
    }

//    @ExceptionHandler({DataAccessException.class, JDBCConnectionException.class,
//        SQLTransientConnectionException.class, SQLNonTransientConnectionException.class,
//        DatabaseConnectivityException.class})
//    public ResponseEntity<ApiError> handleDatabaseConnectivity(Exception ex) {
//        return buildError(HttpStatus.SERVICE_UNAVAILABLE, ErrorCode.DATABASE_CONNECTIVITY_ERROR,
//            "The system is experiencing database connectivity issues. Please try again shortly.", ex);
//    }

    @ExceptionHandler({ResourceAccessException.class, WebClientRequestException.class, SocketTimeoutException.class,
        TimeoutException.class, NetworkTimeoutException.class, RestClientException.class})
    public ResponseEntity<ApiError> handleNetworkTimeout(Exception ex) {
        return buildError(HttpStatus.GATEWAY_TIMEOUT, ErrorCode.NETWORK_TIMEOUT,
            "Network timeout occurred. Check your connection or try again.", ex);
    }

    @ExceptionHandler(LlmCallException.class)
    public ResponseEntity<ApiError> handleLlmCall(LlmCallException ex) {
        return buildError(HttpStatus.SERVICE_UNAVAILABLE, ErrorCode.LLM_CALL_ERROR,
            "There was an issue connecting to the language model. Please retry in a moment.", ex);
    }

    @ExceptionHandler(EmbeddingException.class)
    public ResponseEntity<ApiError> handleEmbedding(EmbeddingException ex) {
        return buildError(HttpStatus.INTERNAL_SERVER_ERROR, ErrorCode.EMBEDDING_ERROR,
            "An error occurred while creating embeddings. Please try again or reduce input size.", ex);
    }

    @ExceptionHandler(RateLimitExceededException.class)
    public ResponseEntity<ApiError> handleRateLimit(RateLimitExceededException ex) {
        return buildError(HttpStatus.TOO_MANY_REQUESTS, ErrorCode.RATE_LIMITED,
            "You have reached the request limit. Please wait before trying again.", ex);
    }

    @ExceptionHandler(ResponseStatusException.class)
    public ResponseEntity<ApiError> handleResponseStatus(ResponseStatusException ex) {
        int statusValue = ex.getStatusCode().value();
        HttpStatus status = HttpStatus.valueOf(statusValue);
        return switch (status) {
            case UNAUTHORIZED, FORBIDDEN -> buildError(status, ErrorCode.UNAUTHORIZED,
                "You are not authorized to perform this action. Please reauthenticate or contact support.", ex);
            case NOT_FOUND -> buildError(status, ErrorCode.NOT_FOUND,
                "The requested resource was not found. Please verify the ID or try again.", ex);
            case METHOD_NOT_ALLOWED -> buildError(status, ErrorCode.METHOD_NOT_ALLOWED,
                "This endpoint does not support the requested HTTP method. Please check the API documentation.", ex);
            case TOO_MANY_REQUESTS -> buildError(status, ErrorCode.RATE_LIMITED,
                "You have reached the request limit. Please wait before trying again.", ex);
            case INTERNAL_SERVER_ERROR -> buildError(status, ErrorCode.INTERNAL_SERVER_ERROR,
                "The server encountered an error. Please retry later.", ex);
            default -> buildError(status, ErrorCode.TECHNICAL_ERROR,
                "A technical error occurred. Please try again later or contact support.", ex);
        };
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiError> handleGeneric(Exception ex) {
        return buildError(HttpStatus.INTERNAL_SERVER_ERROR, ErrorCode.TECHNICAL_ERROR,
            "A technical error occurred. Please try again later or contact support.", ex);
    }

    private ResponseEntity<ApiError> buildError(HttpStatus status, ErrorCode code, String message, Exception ex) {
        log.error("Handling error: {} {}", code, status.value(), ex);
        ApiError body = ApiError.builder()
            .statusCode(status.value())
            .errorCode(code.name())
            .message(message)
            .timestamp(OffsetDateTime.now(ZoneOffset.UTC))
            .build();
        return ResponseEntity.status(status).body(body);
    }
}
