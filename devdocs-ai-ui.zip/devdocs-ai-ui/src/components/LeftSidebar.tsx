// components/layout/LeftSidebar.tsx
import { 
  Box, 
  List, 
  ListItemButton, 
  ListItemText, 
  ListItemIcon,
  Divider, 
  Avatar, 
  Typography, 
  Switch, 
  FormControlLabel,
  Collapse,
  Tooltip,
  Badge,
  Menu,
  MenuItem,
  IconButton,
  useMediaQuery,
  Drawer,
  alpha
} from '@mui/material';
import type { Theme } from '@mui/material/styles';
import { NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../context/Auth.context';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faTachometerAlt,
  faHome,
  faFileAlt,
  faUpload,
  faComments,
  faMagic,
  faCog,
  faChevronDown,
  faChevronUp,
  faSignOutAlt,
  faUser,
  faCloudUploadAlt,
  faHistory,
  faSun,
  faMoon,
  faChartLine,
  faFilePdf,
  faRobot,
  faScroll,
  faUsers,
  faBookOpen
} from '@fortawesome/free-solid-svg-icons';
import { useState } from 'react';

interface LeftSidebarProps {
  mode: 'light' | 'dark';
  setMode: (mode: 'light' | 'dark') => void;
  mobileOpen?: boolean;
  onMobileClose?: () => void;
}

interface NavItem {
  text: string;
  path: string;
  icon: any; // FontAwesome icon
  badge?: number;
  children?: NavItem[];
}

const LeftSidebar: React.FC<LeftSidebarProps> = ({ 
  mode, 
  setMode, 
  mobileOpen = false, 
  onMobileClose 
}) => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const isMobile = useMediaQuery((theme: Theme) => theme.breakpoints.down('md'));
  
  const [openSections, setOpenSections] = useState<Record<string, boolean>>({
    generate: false
  });
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  
  const email = user?.email ?? 'guest@local';
  const displayName = user?.name ?? email.split('@')[0];
  
  const handleSectionToggle = (section: string) => {
    setOpenSections(prev => ({ ...prev, [section]: !prev[section] }));
  };
  
  const handleProfileMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  
  const handleProfileMenuClose = () => {
    setAnchorEl(null);
  };
  
  const handleLogout = async () => {
    handleProfileMenuClose();
    await logout();
  };
  
  const navigationItems: NavItem[] = [
    {
      text: 'Dashboard',
      path: '/dashboard',
      icon: faTachometerAlt
    },
    {
      text: 'Home',
      path: '/dashboard/home',
      icon: faHome
    },
    {
      text: 'Documents',
      path: '/dashboard/documents',
      icon: faFileAlt,
      badge: 12
    },
    {
      text: 'Upload',
      path: '/dashboard/upload',
      icon: faUpload
    },
    {
      text: 'Chat',
      path: '/dashboard/chat',        
      icon: faComments,
      badge: 3
    },
    {
      text: 'Generate',
      path: '#',
      icon: faMagic,
      children: [
        {
          text: 'Release Notes',
          path: '/dashboard/generate/release-notes',
          icon: faScroll
        },
        {
          text: 'User Stories',
          path: '/dashboard/generate/user-stories',
          icon: faUsers
        },
        {
          text: 'Onboarding Summary',
          path: '/dashboard/generate/onboarding',
          icon: faBookOpen
        }
      ]
    },
    {
      text: 'Settings',
      path: '/dashboard/settings',
      icon: faCog
    }
  ];
  
  const renderNavItem = (item: NavItem, depth = 0) => {
    const isActive = location.pathname === item.path;
    const hasChildren = item.children && item.children.length > 0;
    const isOpen = openSections[item.text.toLowerCase()];
    
    if (hasChildren) {
      return (
        <Box key={item.text}>
          <ListItemButton
            onClick={() => handleSectionToggle(item.text.toLowerCase())}
            sx={{
              pl: depth === 0 ? 2 : 4,
              borderRadius: 1,
              mx: 1,
              mb: 0.5,
              bgcolor: isActive ? alpha('#1976d2', 0.08) : 'transparent',
              '&:hover': {
                bgcolor: alpha('#1976d2', 0.04)
              }
            }}
          >
            <ListItemIcon sx={{ minWidth: 40, color: isActive ? 'primary.main' : 'inherit' }}>
              <FontAwesomeIcon icon={item.icon} size="sm" />
            </ListItemIcon>
            <ListItemText 
              primary={item.text} 
              primaryTypographyProps={{
                fontWeight: isActive ? 600 : 400,
                color: isActive ? 'primary.main' : 'text.primary'
              }}
            />
            <FontAwesomeIcon 
              icon={isOpen ? faChevronUp : faChevronDown} 
              size="xs" 
              style={{ color: 'rgba(0,0,0,0.54)' }}
            />
          </ListItemButton>
          <Collapse in={isOpen} timeout="auto" unmountOnExit>
            <List component="div" disablePadding>
              {item.children.map(child => renderNavItem(child, depth + 1))}
            </List>
          </Collapse>
        </Box>
      );
    }
    
    return (
      <ListItemButton
        key={item.text}
        component={NavLink}
        to={item.path}
        onClick={() => isMobile && onMobileClose?.()}
        sx={{
          pl: depth === 0 ? 2 : 4,
          borderRadius: 1,
          mx: 1,
          mb: 0.5,
          '&.active': {
            bgcolor: alpha('#1976d2', 0.08),
            '& .MuiListItemIcon-root': {
              color: 'primary.main'
            },
            '& .MuiListItemText-primary': {
              fontWeight: 600,
              color: 'primary.main'
            }
          },
          '&:hover': {
            bgcolor: alpha('#1976d2', 0.04)
          }
        }}
      >
        <ListItemIcon sx={{ minWidth: 40, color: 'text.secondary' }}>
          <FontAwesomeIcon icon={item.icon} size="sm" />
        </ListItemIcon>
        <ListItemText 
          primary={item.text} 
          primaryTypographyProps={{
            fontSize: '0.9rem'
          }}
        />
        {item.badge && (
          <Badge 
            badgeContent={item.badge} 
            color="primary"
            sx={{ '& .MuiBadge-badge': { fontSize: '0.7rem', height: 18, minWidth: 18 } }}
          />
        )}
      </ListItemButton>
    );
  };
  
  const sidebarContent = (
    <Box sx={{ 
      display: 'flex', 
      flexDirection: 'column', 
      height: '100%',
      bgcolor: 'background.paper',
      borderRight: '1px solid',
      borderColor: 'divider'
    }}>
      {/* Logo Section */}
      <Box sx={{ px: 2.5, py: 3, borderBottom: '1px solid', borderColor: 'divider' }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 0.5 }}>
          <FontAwesomeIcon 
            icon={faChartLine} 
            size="lg" 
            style={{ 
              color: '#1976d2',
              background: 'linear-gradient(135deg, #1976d2 0%, #64b5f6 100%)',
              backgroundClip: 'text',
              WebkitBackgroundClip: 'text'
            }}
          />
          <Typography 
            variant="h6" 
            sx={{ 
              fontWeight: 700,
              background: 'linear-gradient(135deg, #1976d2 0%, #64b5f6 100%)',
              backgroundClip: 'text',
              WebkitBackgroundClip: 'text',
              color: 'transparent',
            }}
          >
            Intelligence Console
          </Typography>
        </Box>
        <Typography variant="caption" color="text.secondary" sx={{ fontSize: '0.7rem', ml: 4.5 }}>
          Powered by DevDocs AI
        </Typography>
      </Box>
      
      {/* Navigation */}
      <Box sx={{ flex: 1, overflowY: 'auto', py: 2 }}>
        <List sx={{ px: 1 }}>
          {navigationItems.map(item => renderNavItem(item))}
        </List>
      </Box>
      
      {/* Bottom Section */}
      <Box sx={{ borderTop: '1px solid', borderColor: 'divider' }}>
        {/* User Profile */}
        <Box sx={{ px: 2, py: 1.5 }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
            <Tooltip title={displayName}>
              <IconButton onClick={handleProfileMenuOpen} sx={{ p: 0 }}>
                <Avatar 
                  sx={{ 
                    bgcolor: 'primary.main',
                    width: 40,
                    height: 40,
                    cursor: 'pointer'
                  }}
                >
                  {displayName.charAt(0).toUpperCase()}
                </Avatar>
              </IconButton>
            </Tooltip>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Typography variant="body2" noWrap fontWeight={500}>
                {displayName}
              </Typography>
              <Typography variant="caption" color="text.secondary" noWrap>
                {email}
              </Typography>
            </Box>
          </Box>
          
          <Divider sx={{ my: 1.5 }} />
          
          {/* Theme Toggle */}
          <FormControlLabel
            control={
              <Switch
                checked={mode === 'dark'}
                onChange={() => setMode(mode === 'light' ? 'dark' : 'light')}
                color="primary"
                size="small"
                icon={<FontAwesomeIcon icon={faSun} size="sm" />}
                checkedIcon={<FontAwesomeIcon icon={faMoon} size="sm" />}
              />
            }
            label={
              <Typography variant="body2" color="text.secondary">
                {mode === 'dark' ? 'Dark Mode' : 'Light Mode'}
              </Typography>
            }
            sx={{ 
              m: 0,
              '& .MuiFormControlLabel-label': { ml: 1 }
            }}
          />
        </Box>
      </Box>
      
      {/* Profile Menu */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleProfileMenuClose}
        transformOrigin={{ horizontal: 'left', vertical: 'top' }}
        anchorOrigin={{ horizontal: 'left', vertical: 'top' }}
        PaperProps={{
          sx: {
            mt: -1,
            ml: 2,
            minWidth: 180,
            borderRadius: 2
          }
        }}
      >
        <MenuItem component={NavLink} to="/dashboard/profile" onClick={handleProfileMenuClose}>
          <ListItemIcon>
            <FontAwesomeIcon icon={faUser} size="sm" />
          </ListItemIcon>
          <ListItemText>My Profile</ListItemText>
        </MenuItem>
        <MenuItem onClick={handleLogout}>
          <ListItemIcon>
            <FontAwesomeIcon icon={faSignOutAlt} size="sm" />
          </ListItemIcon>
          <ListItemText>Logout</ListItemText>
        </MenuItem>
      </Menu>
    </Box>
  );
  
  if (isMobile) {
    return (
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={onMobileClose}
        ModalProps={{ keepMounted: true }}
        sx={{
          display: { xs: 'block', md: 'none' },
          '& .MuiDrawer-paper': { width: 280, boxSizing: 'border-box' }
        }}
      >
        {sidebarContent}
      </Drawer>
    );
  }
  
  return (
    <Drawer
      variant="permanent"
      sx={{
        width: 280,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: 280,
          boxSizing: 'border-box',
          borderRight: '1px solid',
          borderColor: 'divider'
        }
      }}
    >
      {sidebarContent}
    </Drawer>
  );
};

export default LeftSidebar;