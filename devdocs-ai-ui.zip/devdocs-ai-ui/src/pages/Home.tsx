import { Container, Paper, Typography } from '@mui/material';

const Home = () => (
  <Container maxWidth="lg" sx={{ mt: 3 }}>
    <Paper sx={{ p: 3 }} elevation={2}>
      <Typography variant="h4" gutterBottom>
        Home
      </Typography>
      <Typography variant="body1" paragraph>
        Welcome to the DevDocs AI React starter app. Use the sidebar to navigate.
      </Typography>
      <Typography variant="body2">
        This project is designed for a Spring Boot backend endpoint at{' '}
        <strong>/api/dashboard/summary</strong> with example state and API handling.
      </Typography>
    </Paper>
  </Container>
);

export default Home;
