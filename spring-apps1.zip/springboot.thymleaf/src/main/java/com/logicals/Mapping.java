package com.logicals;

import java.util.HashMap;
import java.util.Map;

public class Mapping {

	public static void main(String[] args) {

		Map<Boolean, String> map = new HashMap<>();
		// ApplicationInquiryUtil applicationInquiryUtil = new ApplicationInquiryUtil();
		// String applicationInquiryUtil=null;
		TXLifeRequest txLifeRequest = new TXLifeRequest();
		txLifeRequest.setTransSubType("OLI_APPLICATION_INQUIRY");
		txLifeRequest.setTransactionContext("APPODSSEARCH");
		String resultObject = null;
		map.put(txLifeRequest.getTransSubType() != null && txLifeRequest.getTransSubType().equalsIgnoreCase("OLI_APPLICATION_INQUIRY")
				&& txLifeRequest.getTransactionContext() != null && txLifeRequest.getTransactionContext().equalsIgnoreCase("APPODSSEARCH"),
				getUtFeederInfoCheckResponse(txLifeRequest.getTransactionContext()));

		if (map.containsKey(txLifeRequest.getTransactionContext()) && map.containsKey(txLifeRequest.getTransSubType()))
			resultObject = map.get(txLifeRequest);

		System.out.println(resultObject);
	}

	public static String getUtFeederInfoCheckResponse(String txLifeRequest) {
		return "Success";
	}

}
