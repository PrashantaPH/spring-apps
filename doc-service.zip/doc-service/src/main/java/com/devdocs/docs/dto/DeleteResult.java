package com.devdocs.docs.dto;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class DeleteResult {
    Long documentId;
    String status;
    String message;
    boolean deleted;
}
