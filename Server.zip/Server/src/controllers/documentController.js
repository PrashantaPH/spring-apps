// controllers/documentController.js
import Document from "../models/Document.js";
import path from "path";

// If you want to upload via buffer (Multer memory storage)
import multer from "multer";

const storage = multer.memoryStorage();
export const upload = multer({ storage });

export const uploadDocuments = async (req, res) => {
  try {
    const { eventId } = req.body;
    if (!eventId) {
      return res
        .status(400)
        .json({ success: false, message: "Event ID is required" });
    }

    if (!req.files || req.files.length === 0) {
      return res
        .status(400)
        .json({ success: false, message: "No files uploaded" });
    }

    const savedDocs = [];

    for (const file of req.files) {
      const fileType = file.mimetype.startsWith("image/") ? "image" : "video";

      const doc = new Document({
        imageId: Date.now().toString() + path.extname(file.originalname),
        eventId,
        fileName: file.originalname,
        fileType,
        fileData: file.buffer, // store file as binary
      });

      await doc.save();
      savedDocs.push({
        imageId: doc.imageId,
        fileName: doc.fileName,
        fileType: doc.fileType,
      });
    }

    res.status(201).json({
      success: true,
      message: "Documents uploaded successfully",
      documents: savedDocs,
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};


/**
 * NOTE:
 * - This version is NODE 22 SAFE
 * - No TensorFlow
 * - No face-api
 * - Mock / logical face grouping
 */

// controllers/documentController.js

export const faceGroupingByEvent = async (req, res) => {
  try {
    const { eventId } = req.params;
    if (!eventId) return res.status(400).json({ success: false, message: "Event ID is required" });

    const documents = await Document.find({ eventId });
    if (!documents.length) return res.status(404).json({ success: false, message: "No documents found for this event" });

    // Mock grouping
    const faces = {};

    documents.forEach((doc) => {
      const base64 = doc.fileData?.toString("base64");
      const faceCount = mockFaceCount(doc.fileName);

      for (let i = 1; i <= faceCount; i++) {
        const faceId = `face_${i}`; // simple mock face id
        if (!faces[faceId]) {
          faces[faceId] = {
            faceId,
            avatar: base64,
            images: []
          };
        }

        faces[faceId].images.push({
          imageId: doc.imageId,
          fileName: doc.fileName,
          fileData: base64,
        });
      }
    });

    res.json({
      success: true,
      eventId,
      faces: Object.values(faces),
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

function mockFaceCount(filename) {
  if (!filename) return 1;
  if (filename.toLowerCase().includes("group")) return 4;
  if (filename.toLowerCase().includes("family")) return 3;
  return 2;
}
