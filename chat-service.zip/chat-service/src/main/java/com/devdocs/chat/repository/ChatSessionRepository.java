package com.devdocs.chat.repository;

import com.devdocs.chat.entity.ChatSession;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChatSessionRepository extends JpaRepository<ChatSession, Long> {
    Optional<ChatSession> findTopByUserIdOrderByUpdatedAtDesc(Long userId);

    Optional<ChatSession> findTopByUserIdAndDocIdOrderByUpdatedAtDesc(Long userId, Long docId);

    Optional<ChatSession> findByIdAndUserId(Long id, Long userId);
}
