package com.convertion.controller;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class DummyApi {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@GetMapping
	private String test() throws JsonMappingException, JsonProcessingException {
		String url = "https://jsonplaceholder.typicode.com/posts";
		String str = restTemplate.getForObject(url, String.class);  
		
		ObjectMapper mapper = new ObjectMapper();
		List<Object> list = mapper.readValue(str, new TypeReference<List<Object>>() {});
		JSONArray jsonArray = new JSONArray(list);
		for(Object obj : jsonArray) {
			JSONObject jsonObject = (JSONObject) obj;
			System.out.println(jsonObject.get("id"));
		}
		return "Success";
	}
}
