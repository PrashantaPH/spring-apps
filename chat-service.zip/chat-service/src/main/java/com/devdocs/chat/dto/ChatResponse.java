package com.devdocs.chat.dto;

import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ChatResponse {
    String answer;
    List<CitationDto> citations;
}
