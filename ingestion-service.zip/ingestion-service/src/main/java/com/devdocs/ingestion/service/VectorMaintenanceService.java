package com.devdocs.ingestion.service;

import com.devdocs.ingestion.repository.DocumentChunkRepository;
import com.devdocs.common.vector.VectorIndexService;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class VectorMaintenanceService {

    private final DocumentChunkRepository chunkRepository;
    private final VectorIndexService vectorIndexService;

    @Transactional
    public void updateDocumentVectors(Long documentId, String mode) {
        if (documentId == null) {
            return;
        }
        if ("hard".equalsIgnoreCase(mode)) {
            chunkRepository.deleteByDocumentId(documentId);
            vectorIndexService.removeDocumentVectors(documentId);
            log.info("Hard deleted vectors for document {}", documentId);
            return;
        }

        chunkRepository.updateActiveByDocumentId(documentId, false);
        vectorIndexService.setActiveByDocumentId(documentId, false);
        log.info("Soft deactivated vectors for document {}", documentId);
    }
}
