package com.devdocs.common.web.exception;

public class DatabaseConnectivityException extends RuntimeException {
    public DatabaseConnectivityException() {
        super("Database connectivity error");
    }

    public DatabaseConnectivityException(String message) {
        super(message);
    }

    public DatabaseConnectivityException(String message, Throwable cause) {
        super(message, cause);
    }
}
