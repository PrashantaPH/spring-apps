package com.devdocs.common.web.exception;

public class NetworkTimeoutException extends RuntimeException {
    public NetworkTimeoutException() {
        super("Network timeout");
    }

    public NetworkTimeoutException(String message) {
        super(message);
    }

    public NetworkTimeoutException(String message, Throwable cause) {
        super(message, cause);
    }
}
