package com.devdocs.chat.controller;

import com.devdocs.chat.dto.ChatHistoryResponse;
import com.devdocs.chat.dto.ChatMessageResponse;
import com.devdocs.chat.dto.ChatSessionResponse;
import com.devdocs.chat.dto.EditMessageRequest;
import com.devdocs.chat.dto.RegenerateRequest;
import com.devdocs.chat.dto.UpdateChatRequest;
import com.devdocs.chat.entity.ChatMessage;
import com.devdocs.chat.entity.ChatSession;
import com.devdocs.chat.service.ChatService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/chats")
@RequiredArgsConstructor
public class ChatEditController {

    private final ChatService chatService;

    @PatchMapping("/{chatId}")
    public ResponseEntity<ChatSessionResponse> updateChat(Authentication authentication,
                                                          @PathVariable Long chatId,
                                                          @Valid @RequestBody UpdateChatRequest request) {
        Long userId = Math.abs(authentication.getName().hashCode()) + 0L;
        ChatSession session = chatService.updateChat(userId, chatId, request);
        return ResponseEntity.ok(toSessionResponse(session));
    }

    @PatchMapping("/{chatId}/messages/{messageId}")
    public ResponseEntity<ChatMessageResponse> editMessage(Authentication authentication,
                                                           @PathVariable Long chatId,
                                                           @PathVariable Long messageId,
                                                           @Valid @RequestBody EditMessageRequest request) {
        Long userId = Math.abs(authentication.getName().hashCode()) + 0L;
        ChatMessage message = chatService.editMessage(userId, chatId, messageId, request);
        return ResponseEntity.ok(toMessageResponse(message));
    }

    @PostMapping("/{chatId}/messages/{messageId}/regenerate")
    public ResponseEntity<?> regenerate(Authentication authentication,
                                        @PathVariable Long chatId,
                                        @PathVariable Long messageId,
                                        @Valid @RequestBody RegenerateRequest request) {
        Long userId = Math.abs(authentication.getName().hashCode()) + 0L;
        return ResponseEntity.ok(chatService.regenerate(userId, chatId, messageId, request));
    }

    @GetMapping("/{docId}/history")
    public ResponseEntity<ChatHistoryResponse> history(Authentication authentication,
                                                       @PathVariable Long docId,
                                                       @RequestParam(name = "includeEdits", defaultValue = "false") boolean includeEdits) {
        Long userId = Math.abs(authentication.getName().hashCode()) + 0L;
        return ResponseEntity.ok(chatService.getHistoryByDocId(userId, docId, includeEdits));
    }

    private ChatSessionResponse toSessionResponse(ChatSession session) {
        return ChatSessionResponse.builder()
            .id(session.getId())
            .title(session.getTitle())
            .systemPrompt(session.getSystemPrompt())
            .docId(session.getDocId())
            .createdAt(session.getCreatedAt())
            .updatedAt(session.getUpdatedAt())
            .build();
    }

    private ChatMessageResponse toMessageResponse(ChatMessage message) {
        return ChatMessageResponse.builder()
            .id(message.getId())
            .role(message.getRole())
            .content(message.getContent())
            .msgVersion(message.getMsgVersion())
            .createdAt(message.getCreatedAt())
            .updatedAt(message.getUpdatedAt())
            .editedAt(message.getEditedAt())
            .editedBy(message.getEditedBy())
            .build();
    }
}
