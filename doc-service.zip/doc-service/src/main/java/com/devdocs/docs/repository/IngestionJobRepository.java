package com.devdocs.docs.repository;

import com.devdocs.docs.entity.IngestionJob;
import jakarta.persistence.LockModeType;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface IngestionJobRepository extends JpaRepository<IngestionJob, Long> {
	@Lock(LockModeType.PESSIMISTIC_WRITE)
	@Query("select j from IngestionJob j where j.runId = :runId")
	Optional<IngestionJob> findByRunIdForUpdate(@Param("runId") Long runId);

	@Lock(LockModeType.PESSIMISTIC_WRITE)
	@Query("select j from IngestionJob j where j.document.id = :documentId order by j.id desc")
	List<IngestionJob> findLatestByDocumentIdForUpdate(@Param("documentId") Long documentId, Pageable pageable);

	@Modifying
	@Query("delete from IngestionJob j where j.document.id = :documentId")
	int deleteByDocumentId(@Param("documentId") Long documentId);
}
