package com.practice;

import java.util.Arrays;

public class StringTimes {

	public static void main(String[] args) {
//		System.out.println(stringTimes("Hi", 4));

//		System.out.println(frontTimes("", 2));

//		System.out.println(countXX("Hexxo thxxe"));

//		System.out.println(doubleX("xaxxx"));

//		System.out.println(stringBits("Heeololeo"));

//		System.out.println(stringSplosion("Code"));

//		System.out.println(arrayCount9(new int[] {1, 9, 9, 3, 9}));

		System.out.println(arrayFront9(new int[] { 1, 2, 3, 4, 9 }));
	}

	public static boolean arrayFront9(int[] nums) {
		int end = nums.length;
		if (end > 4) end = 4;
		for (int i = 0; i < end; i++) {
			if (nums[i] == 9) {
				return true;
			}
		}
		return false;
	}

	public static int arrayCount9(int[] nums) {
		return Arrays.stream(nums).filter(num -> num == 9).toArray().length;
	}

	public static String stringSplosion(String str) {
		String temp = "";
		for (int i = 0; i <= str.length(); i++) {
			temp += str.substring(0, i);
		}
		return temp;
	}

	public static String stringBits(String str) {
		String temp = "";
		for (int i = 0; i < str.length(); i++) {
			if (i % 2 == 0) {
				temp += str.charAt(i);
			}
		}
		return temp;
	}

	static boolean doubleX(String str) {
		int i = str.indexOf("x");
		if (i == -1)
			return false;
		String x = str.substring(i);
		return x.startsWith("xx");

	}

	public static int countXX(String str) {
		int count = 0;
		for (int i = 0; i < str.length() - 1; i++) {
			if (str.substring(i, i + 2).equals("xx"))
				count++;
		}
		return count;
	}

	public static String frontTimes(String str, int n) {
		int frontLen = 3;
		if (frontLen > str.length()) {
			frontLen = str.length();
		}
		String front = str.substring(0, frontLen);

		String result = "";
		for (int i = 0; i < n; i++) {
			result = result + front;
		}
		return result;
	}

	public static String stringTimes(String str, int n) {

		String result = "";
		for (int i = 0; i < n; i++) {
			result += str;
		}
		return result;
	}

}
