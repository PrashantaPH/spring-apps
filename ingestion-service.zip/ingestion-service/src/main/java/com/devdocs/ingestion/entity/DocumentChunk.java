package com.devdocs.ingestion.entity;

import jakarta.persistence.*;

import java.time.OffsetDateTime;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "document_chunks")
public class DocumentChunk {

    @Id
    @Column(name = "chunk_id", columnDefinition = "uuid")
    private UUID chunkId;

    @Column(name = "document_id", nullable = false)
    private Long documentId;

    @Column(name = "version_id")
    private Long versionId;

    @Column(columnDefinition = "text", nullable = false)
    private String content;

    @Column(name = "embedding", columnDefinition = "text")
    private String  embedding;

    @Column(name = "active", nullable = false)
    private boolean active = true;

    @Column(name = "created_at", nullable = false)
    private OffsetDateTime createdAt;

    @Column(name = "updated_at")
    private OffsetDateTime updatedAt;
}
