package com.devdocs.chat.repository;

import com.devdocs.chat.entity.ChatMessage;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
	List<ChatMessage> findBySessionIdOrderByCreatedAtAsc(Long sessionId);

	Optional<ChatMessage> findByIdAndSessionId(Long id, Long sessionId);
}
