import Event from "../models/Event.js";
import QRCode from "qrcode";

export const createEvent = async (req, res) => {
  try {
    const { eventName, eventDate, location, eventType } = req.body;
      // unique event id
    const eventId = Date.now().toString();

    // data to embed in QR
    const qrData = JSON.stringify({
      eventId,
      eventName,
      eventDate,
    });

    // generate QR code (base64)
    const qrCode = await QRCode.toDataURL(qrData);
    const event = new Event({ eventId: eventId, eventName, eventDate, location, eventType, qrCode });
    await event.save();
    res.status(201).json({
      success: true,
      message: "Event created successfully",
    });
  } catch (error) {
    error.status = 500;
    throw error;
  }
};

export const getEvents = async (req, res) => {
  try {
   const events = await Event.find();
   res.status(200).json({
    success: true,
    message: "Events fetched successfully",
    events,
   });
  } catch (error) {
    error.status = 500;
    throw error;
  } 
};

export const getEvent = async (req, res) => {
  try {
    const { eventId } = req.params;
    const event = await Event.findOne({ eventId: eventId });
    if (!event) {
      return res.status(404).json({
        success: false,
        message: "Event not found",
      });
    }
    res.status(200).json({
      success: true,
      message: "Event retrieved successfully",
      event,
    });
  } catch (error) {
    error.status = 500;
    throw error;
  }
};

