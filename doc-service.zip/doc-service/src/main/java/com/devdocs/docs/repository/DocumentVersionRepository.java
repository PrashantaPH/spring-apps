package com.devdocs.docs.repository;

import com.devdocs.docs.entity.DocumentVersion;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DocumentVersionRepository extends JpaRepository<DocumentVersion, Long> {
    @Query("select v from DocumentVersion v where v.document.id = :documentId and v.current = true")
    Optional<DocumentVersion> findCurrentByDocumentId(@Param("documentId") Long documentId);

    @Query("select v from DocumentVersion v where v.document.id = :documentId order by v.versionNum desc")
    List<DocumentVersion> findAllByDocumentIdOrderByVersionNumDesc(@Param("documentId") Long documentId);

    @Modifying
    @Query("delete from DocumentVersion v where v.document.id = :documentId")
    int deleteByDocumentId(@Param("documentId") Long documentId);
}
