package com.springmvc;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class Driver {

	public static void main(String[] args) {
		String xmlPath = "com/springmvc/demp.xml";
		String xml = loadTestData(xmlPath);
	}

	public static String loadTestData(String relativeFilePath) {
		String dataAsString = "";
		InputStream ruleFileStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(relativeFilePath);
		try {
			if (ruleFileStream != null) {
				int size = ruleFileStream.available();
				byte[] data = new byte[size];
				ruleFileStream.read(data);
				dataAsString = new String(data);
			}
//			String en = Base64.getEncoder().encodeToString(dataAsString.getBytes());
//			System.out.println(en);
		//OR
			byte[] byteArr = dataAsString.getBytes();
			byte[] encoderByeArr = Base64.getEncoder().encode(byteArr);
			String encodeStr = new String(encoderByeArr,StandardCharsets.UTF_8);
			System.out.println(encodeStr);
		//OR
//			ByteArrayInputStream arrayInputStream = new ByteArrayInputStream(encoderByeArr);
//			int byteReader = 0;
//			char charValue = 0 ;
//			while ((byteReader = arrayInputStream.read()) != -1) {
//				charValue = (char) byteReader;
//				System.out.print(charValue);
//			}
			System.out.println("\nCount : "+encoderByeArr.length);
			byte[] decoderByteArr = Base64.getDecoder().decode(encoderByeArr);
			String decodedStr = new String(decoderByteArr, StandardCharsets.UTF_8);
			System.out.println("Result : --->\n" + decodedStr);
			
			String pdfpath = "ExtractionData.xml";
			FileOutputStream fileOutputStream = new FileOutputStream(pdfpath);
			fileOutputStream.write(decoderByteArr);
			System.out.println("Success");
			
			fileOutputStream.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (ruleFileStream != null) {
				try {
					ruleFileStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return dataAsString;
	}

}
