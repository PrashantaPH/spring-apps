package com.devdocs.auth.service;

import com.devdocs.auth.dto.LoginRequest;
import com.devdocs.auth.dto.LoginResponse;
import com.devdocs.auth.dto.SignupRequest;
import com.devdocs.auth.dto.UserDto;
import com.devdocs.auth.entity.RefreshToken;
import com.devdocs.auth.entity.User;
import com.devdocs.auth.repository.RefreshTokenRepository;
import com.devdocs.auth.repository.UserRepository;
import com.devdocs.common.security.JwtTokenService;
import com.devdocs.common.security.TokenExpiredAuthenticationException;
import com.devdocs.common.web.exception.InvalidCredentialsException;
import com.devdocs.common.web.exception.UserAlreadyExistsException;
import com.devdocs.common.web.exception.UserNotFoundException;
import jakarta.transaction.Transactional;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import static com.devdocs.common.security.SecurityConstants.*;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final RefreshTokenRepository refreshTokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtTokenService jwtTokenService;

    @Value("${security.jwt.refresh-token-ttl-hours}")
    private long refreshTtlHours;

    @Transactional
    public UserDto signup(SignupRequest request) {
        userRepository.findByEmail(request.getEmail()).ifPresent(user -> {
            throw new UserAlreadyExistsException();
        });
        User user = new User();
        user.setEmail(request.getEmail());
        user.setName(request.getName());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.getRoles().add(ROLE_USER);
        user.setCreatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        user.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        User saved = userRepository.save(user);
        return toDto(saved);
    }

    @Transactional
    public LoginResponse login(LoginRequest request) {
        User user = userRepository.findByEmail(request.getEmail())
            .orElseThrow(InvalidCredentialsException::new);
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new InvalidCredentialsException();
        }
        String accessToken = jwtTokenService.createAccessToken(user.getEmail(), user.getRoles().stream().toList());
        RefreshToken refresh = upsertRefreshToken(user);
        return LoginResponse.builder()
            .accessToken(accessToken)
            .refreshToken(refresh.getToken())
            .user(toDto(user))
            .build();
    }

    public UserDto me(String email) {
        Assert.hasText(email, "email required");
        User user = userRepository.findByEmail(email)
            .orElseThrow(UserNotFoundException::new);
        return toDto(user);
    }

    @Transactional
    public LoginResponse refresh(String refreshToken) {
        Assert.hasText(refreshToken, "refresh token required");
        RefreshToken token = refreshTokenRepository.findByToken(refreshToken)
            .orElseThrow(InvalidCredentialsException::new);
        OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
        if (token.getExpiresAt() == null || token.getExpiresAt().isBefore(now)) {
            refreshTokenRepository.delete(token);
            throw new TokenExpiredAuthenticationException("Refresh token expired");
        }

        User user = token.getUser();
        String accessToken = jwtTokenService.createAccessToken(user.getEmail(), user.getRoles().stream().toList());
        RefreshToken rotated = upsertRefreshToken(user);
        return LoginResponse.builder()
            .accessToken(accessToken)
            .refreshToken(rotated.getToken())
            .user(toDto(user))
            .build();
    }

    private RefreshToken upsertRefreshToken(User user) {
        refreshTokenRepository.deleteByUserId(user.getId());
        RefreshToken refreshToken = new RefreshToken();
        refreshToken.setToken(UUID.randomUUID().toString());
        refreshToken.setUser(user);
        refreshToken.setCreatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        refreshToken.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        refreshToken.setExpiresAt(OffsetDateTime.now(ZoneOffset.UTC).plus(refreshTtlHours, ChronoUnit.HOURS));
        return refreshTokenRepository.save(refreshToken);
    }

    private UserDto toDto(User user) {
        return UserDto.builder()
            .id(user.getId())
            .email(user.getEmail())
            .name(user.getName())
            .build();
    }
}
