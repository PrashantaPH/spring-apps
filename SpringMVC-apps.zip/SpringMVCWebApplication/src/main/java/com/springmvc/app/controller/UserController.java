package com.springmvc.app.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springmvc.app.dto.User;

@RestController
@RequestMapping("api/v1/user")
public class UserController {

	@PostMapping("/create")
	public User create(@RequestBody User user){
		return user;
	}
	
	@PostMapping("/message")
	public String get(@RequestBody String user){
		return "Successfully invoked the rest api....!";
	}
	
}
