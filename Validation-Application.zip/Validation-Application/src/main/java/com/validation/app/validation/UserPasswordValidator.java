package com.validation.app.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class UserPasswordValidator implements ConstraintValidator<ValidatePassword, String> {

	private static final String PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";

	@Override
	public boolean isValid(String passwordValue, ConstraintValidatorContext context) {

		int pwdLength = passwordValue.length();
		
		if (pwdLength >= 8) {
			return passwordValue.matches(PATTERN);
		}

		return false;
	}
	
	public static void main(String[] args) {
		UserPasswordValidator passwordValidation = new UserPasswordValidator();
		boolean bol = passwordValidation.isValid("Prashanta@6362", null);
		
		System.out.println(bol);
	}

}
