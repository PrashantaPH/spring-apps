package com.springbatch.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbatchNewVersionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbatchNewVersionApplication.class, args);
	}

}
