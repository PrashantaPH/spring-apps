package com.devdocs.ingestion.repository;

import com.devdocs.ingestion.entity.DocumentChunk;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DocumentChunkRepository extends JpaRepository<DocumentChunk, UUID> {
	@Modifying
	@Query("update DocumentChunk c set c.active = :active, c.updatedAt = current_timestamp where c.documentId = :documentId")
	int updateActiveByDocumentId(@Param("documentId") Long documentId, @Param("active") boolean active);

	@Modifying
	@Query("delete from DocumentChunk c where c.documentId = :documentId")
	int deleteByDocumentId(@Param("documentId") Long documentId);

	List<DocumentChunk> findByDocumentIdAndActiveTrue(Long documentId);
}
