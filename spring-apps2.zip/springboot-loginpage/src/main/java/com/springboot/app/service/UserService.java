package com.springboot.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.app.dto.Login;
import com.springboot.app.dto.User;
import com.springboot.app.repository.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository repository;
	
	public User saveUser(User user){
		return repository.save(user);
	}
	
	public User loginValidate(Login login) {
		if("test6362@gmail.com".equals(login.getEmail()) && "Test@6362".equals(login.getPassword())) {
			return repository.userLoging(login.getEmail(),login.getPassword());
		}
		return null;
	}
}
