package com.basic.extraction;


public class TRSExtractionData {

}
