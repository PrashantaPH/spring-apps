package com.devdocs.chat.dto;

import java.util.List;
import lombok.Builder;

@Builder
public class GenerateResponse {
    private String output;
    private List<CitationDto> citations;

    public String getOutput() {
        return output;
    }

    public List<CitationDto> getCitations() {
        return citations;
    }
}
