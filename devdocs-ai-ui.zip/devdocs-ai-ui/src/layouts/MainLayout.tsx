import { Box } from '@mui/material';
import { Outlet } from 'react-router-dom';
import LeftSidebar from '../components/LeftSidebar';

interface MainLayoutProps {
  mode: 'light' | 'dark';
  setMode: (mode: 'light' | 'dark') => void;
}

const MainLayout: React.FC<MainLayoutProps> = ({ mode, setMode }) => (
  <Box sx={{ display: 'flex', minHeight: '100vh' }}>
    <Box sx={{ width: 260, borderRight: '1px solid #eee' }}>
      <LeftSidebar mode={mode} setMode={setMode} />
    </Box>
    <Box sx={{ flex: 1, p: 2 }}>
      <Outlet />
    </Box>
  </Box>
);

export default MainLayout;