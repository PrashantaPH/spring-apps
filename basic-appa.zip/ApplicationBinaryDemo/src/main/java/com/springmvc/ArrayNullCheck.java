package com.springmvc;

public class ArrayNullCheck {

public static void main(String[] args) {
		
		String[] arr = {};
		
		if(arr.length > 0) {
			System.out.println("re");
		}
	}
}
