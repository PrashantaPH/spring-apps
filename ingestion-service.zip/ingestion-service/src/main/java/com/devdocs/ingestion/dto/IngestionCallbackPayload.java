package com.devdocs.ingestion.dto;

import java.time.OffsetDateTime;

public record IngestionCallbackPayload(
    Long documentId,
    Long runId,
    Long versionId,
    String status,
    Integer chunks,
    Integer embeddings,
    Long durationMs,
    String errorCode,
    String errorMessage,
    OffsetDateTime occurredAt
) {
}
