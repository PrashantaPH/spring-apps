package com.devdocs.common.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

public abstract class ServiceTokenAuthenticationFilterBase extends OncePerRequestFilter {

    private static final String SERVICE_TOKEN_HEADER = "X-Service-Token";

    private final SecurityErrorHandler securityErrorHandler;
    private final String serviceToken;
    private final String pathPrefix;
    private final boolean requireHeader;

    protected ServiceTokenAuthenticationFilterBase(SecurityErrorHandler securityErrorHandler, String serviceToken,
        String pathPrefix, boolean requireHeader) {
        this.securityErrorHandler = securityErrorHandler;
        this.serviceToken = serviceToken;
        this.pathPrefix = pathPrefix;
        this.requireHeader = requireHeader;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
        throws ServletException, IOException {
        String path = request.getRequestURI();
        if (path.startsWith(pathPrefix)) {
            String header = request.getHeader(SERVICE_TOKEN_HEADER);
            if (header != null && header.equals(serviceToken)) {
                var auth = new UsernamePasswordAuthenticationToken(
                    "service", null, List.of(new SimpleGrantedAuthority("ROLE_SERVICE")));
                SecurityContextHolder.getContext().setAuthentication(auth);
            } else if (requireHeader || header != null) {
                SecurityContextHolder.clearContext();
                if (!response.isCommitted()) {
                    securityErrorHandler.commence(request, response,
                        new BadCredentialsException("Invalid service token"));
                }
                return;
            }
        }
        filterChain.doFilter(request, response);
    }
}
