package com.devdocs.common.security;

import org.springframework.security.core.AuthenticationException;

public class TokenExpiredAuthenticationException extends AuthenticationException {
    public TokenExpiredAuthenticationException() {
        super("Token expired");
    }

    public TokenExpiredAuthenticationException(String message) {
        super(message);
    }

    public TokenExpiredAuthenticationException(String message, Throwable cause) {
        super(message, cause);
    }
}
