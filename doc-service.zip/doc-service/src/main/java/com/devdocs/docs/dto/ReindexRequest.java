package com.devdocs.docs.dto;

import lombok.Data;

@Data
public class ReindexRequest {
    private ChunkingOptions chunking;
    private String embeddingModel;
    private Boolean refreshVectors;
    private Boolean upsert;

    @Data
    public static class ChunkingOptions {
        private String strategy;
        private Integer maxChars;
        private Integer overlap;
    }
}
