package com.intellect.basics;

import java.util.ArrayList;
import java.util.Arrays;

public class ArrDemo {

	public static void main(String[] args) {
		
		int[] arr = new int[4];
		
		arr[0] =10;
		arr[1] =20;
		arr[2] =30;
		arr[3] =40;
		
		int logicalSize = arr.length;
		int target = 3;
		
		for(int i=target; i<logicalSize-1;i++)
		{
			arr[i] = arr[i-1];
		}
		arr[logicalSize-1]=0;
		
		logicalSize--;
		if(arr[0] >0)
		System.out.println(Arrays.toString(arr));

	}
}
