package com.devdocs.docs.service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.commonmark.node.Node;
import org.commonmark.parser.Parser;
import org.commonmark.renderer.text.TextContentRenderer;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Slf4j
@Service
public class DocumentContentExtractor {

    private final Parser markdownParser = Parser.builder().build();
    private final TextContentRenderer markdownRenderer = TextContentRenderer.builder().build();

    public String extract(MultipartFile file) {
        String filename = file.getOriginalFilename() == null ? "" : file.getOriginalFilename().toLowerCase();
        String contentType = file.getContentType() == null ? "" : file.getContentType().toLowerCase();

        try (InputStream inputStream = file.getInputStream()) {
            if (contentType.contains("pdf") || filename.endsWith(".pdf")) {
                return extractPdf(inputStream);
            }
            if (contentType.contains("markdown") || filename.endsWith(".md") || filename.endsWith(".markdown")) {
                return extractMarkdown(new String(inputStream.readAllBytes(), StandardCharsets.UTF_8));
            }
            if (contentType.startsWith("text/") || filename.endsWith(".txt")) {
                return new String(inputStream.readAllBytes(), StandardCharsets.UTF_8);
            }
        } catch (IOException ex) {
            log.error("Failed to extract content from upload. filename={}", filename, ex);
            throw new IllegalArgumentException("Unable to read uploaded document.");
        }

        throw new IllegalArgumentException("Unsupported file type. Please upload PDF, Markdown, or text files.");
    }

    private String extractPdf(InputStream inputStream) throws IOException {
        try (PDDocument document = PDDocument.load(inputStream)) {
            PDFTextStripper stripper = new PDFTextStripper();
            return stripper.getText(document);
        }
    }

    private String extractMarkdown(String markdown) {
        Node node = markdownParser.parse(markdown);
        return markdownRenderer.render(node);
    }
}
