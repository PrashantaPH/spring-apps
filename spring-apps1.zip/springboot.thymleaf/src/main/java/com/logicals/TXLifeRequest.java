package com.logicals;

public class TXLifeRequest {

	private String transSubType;
	private String transactionContext;

	public String getTransSubType() {
		return transSubType;
	}

	public void setTransSubType(String transSubType) {
		this.transSubType = transSubType;
	}

	public String getTransactionContext() {
		return transactionContext;
	}

	public void setTransactionContext(String transactionContext) {
		this.transactionContext = transactionContext;
	}

}
