package com.intellect.basics;

import java.util.Arrays;

public class ArraySorting {

	public static void main(String[] args) {

		int[] listOfNum = { 1, 4, 5, 2, 4, 6, 3, 7, 8 };
		
		for (int i = 0; i < listOfNum.length; i++) {
			for (int j = i + 1; j < listOfNum.length; j++) {
				if (listOfNum[i] > listOfNum[j]) {
					
//					int temp = listOfNum[i];
//					listOfNum[i] = listOfNum[j];
//					listOfNum[j] = temp;

					listOfNum[i] = listOfNum[i] + listOfNum[j];
					listOfNum[j] = listOfNum[i] - listOfNum[j];
					listOfNum[i] = listOfNum[i] - listOfNum[j];

				}
			}
		}
		System.out.println(Arrays.toString(listOfNum));
	}
}
