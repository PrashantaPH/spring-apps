package com.springboot.basic;

import java.util.Scanner;

import org.springframework.boot.SpringApplication;

public class LeapYear {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		int year = scanner.nextInt();
		
		System.out.println("Res : "+year);
	}
}
