package com.intellect.DemoJunitJupiter;

public class B {

	void m1() {
		System.out.println("m1 method");
	}
}
