// models/Document.js
import mongoose from "mongoose";

const documentSchema = new mongoose.Schema({
  imageId: {
    type: String,
    required: true,
    unique: true,
  },
  eventId: {
    type: String,
    required: true,
  },
  fileName: {
    type: String,
    required: true,
  },
  fileType: {
    type: String, // 'image' or 'video'
    required: true,
  },
  fileData: {
    type: Buffer, // store file as binary
    required: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

export default mongoose.model("documents", documentSchema);
