package com.devdocs.chat.dto;

import java.time.OffsetDateTime;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ChatMessageResponse {
    Long id;
    String role;
    String content;
    Integer msgVersion;
    OffsetDateTime createdAt;
    OffsetDateTime updatedAt;
    OffsetDateTime editedAt;
    Long editedBy;
}
