import express from "express";
import { createEvent, getEvents, getEvent} from "../controllers/eventController.js";

const router = express.Router();
router.post("/create-event", createEvent);
router.get("/get-events", getEvents );
router.get("/get-event/:eventId", getEvent);
export default router;
