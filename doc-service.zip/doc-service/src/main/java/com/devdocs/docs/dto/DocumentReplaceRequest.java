package com.devdocs.docs.dto;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class DocumentReplaceRequest {
    String title;
    String description;
    String sourceUri;
    String content;
    String checksum;
    boolean reindex;
}
