package com.devdocs.docs.dto;

import java.util.List;
import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class BatchDeleteResponse {
    List<DeleteResult> results;
}
