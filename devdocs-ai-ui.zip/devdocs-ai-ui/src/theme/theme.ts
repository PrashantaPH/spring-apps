import { createTheme } from '@mui/material/styles';

const lightPalette = {
  primary: { main: '#0075e4' },
  text: { primary: '#000000de', secondary: '#00000099' },
  background: { default: '#ffffff', paper: '#ffffff' },
};

const darkPalette = {
  primary: { main: '#0075e4' },
  text: { primary: '#ffffff', secondary: '#ffffffb3' },
  background: { default: '#0b0b0b', paper: '#121212' },
};

export const getTheme = (mode: 'light' | 'dark') =>
  createTheme({
    palette: {
      mode,
      ...(mode === 'light' ? lightPalette : darkPalette),
    },
    typography: {
      fontFamily:
        '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue", sans-serif',
    },
    components: {
      MuiOutlinedInput: {
        styleOverrides: {
          root: {
            "& .MuiOutlinedInput-notchedOutline": {
              borderColor: mode === "dark" ? "#555" : "#ccc",
            },
            "&:hover .MuiOutlinedInput-notchedOutline": {
              borderColor: "#0075e4",
            },
            "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
              borderColor: "#0075e4",
            },
          },
        },
      },
    },
  });