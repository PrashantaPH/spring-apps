package com.devdocs.ingestion.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import com.devdocs.ingestion.web.ContentTooLargeException;
import org.springframework.stereotype.Component;

@Component
public class Chunker {

    @Value("${ingestion.max-content-chars:2000000}")
    private int maxContentChars;

    @Value("${ingestion.max-chunks:10000}")
    private int maxChunks;

    public List<String> chunk(String content, int maxChars) {
        return chunk(content, maxChars, 0);
    }

    public List<String> chunk(String content, int maxChars, int overlap) {
        List<String> chunks = new ArrayList<>();
        if (content == null || content.isBlank()) {
            return chunks;
        }
        if (content.length() > maxContentChars) {
            throw new ContentTooLargeException("Document content is too large. Please upload a smaller file.");
        }
        int safeMax = Math.max(1, maxChars);
        int safeOverlap = Math.max(0, Math.min(overlap, safeMax - 1));
        int step = Math.max(1, safeMax - safeOverlap);
        long estimatedChunks = (content.length() + step - 1L) / step;
        if (estimatedChunks > maxChunks) {
            throw new ContentTooLargeException("Document is too large to chunk with current settings.");
        }
        int start = 0;
        while (start < content.length()) {
            int end = Math.min(start + safeMax, content.length());
            chunks.add(content.substring(start, end));
            start = end - safeOverlap;
            if (start < 0) {
                start = 0;
            }
            if (start >= end) {
                start = end;
            }
        }
        return chunks;
    }
}
