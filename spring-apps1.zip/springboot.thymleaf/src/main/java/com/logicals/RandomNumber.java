package com.logicals;

import java.util.HashMap;
import java.util.Map;

public class RandomNumber {

	public static void main(String[] args) {
		String resultString = null;
		Map<String, String> map = new HashMap<>();
		String illustrationId = null;
		String policyNumber = null;
		String accountsearchproductcode = null;
		String connectionId = null;
		String customerId = null;
		String productCode = null;
		String applicationStatus = "OLI_APPTYPE_INPROGRESS";
		map.put("OLI_APPTYPE_NEW", getApplicationNewIlustrationInquiry(illustrationId, policyNumber,accountsearchproductcode, connectionId, customerId, resultString));
		map.put("OLI_APPTYPE_INPROGRESS",getApplicationSaveIlustrationInquiry(illustrationId,policyNumber, accountsearchproductcode, connectionId, customerId, resultString));
		map.put("OLI_APPTYPE_SUBMIT", getApplicationSubmitIlustrationInquiry(illustrationId,policyNumber, productCode, connectionId, customerId, resultString));

		if (map.containsKey(applicationStatus)) {
			resultString = map.get(applicationStatus);
		}
		
		System.out.println(resultString);

	}

	private static String getApplicationSubmitIlustrationInquiry(String illustrationId, String policyNumber,
			String productCode, String connectionId, String customerId, String resultString) {
		
		return "OLI_APPTYPE_NEW";
	}

	private static String getApplicationSaveIlustrationInquiry(String illustrationId, String policyNumber,
			String accountsearchproductcode, String connectionId, String customerId, String resultString) {
		
		return "OLI_APPTYPE_INPROGRESS";
	}

	private static String getApplicationNewIlustrationInquiry(String illustrationId, String policyNumber,
			String accountsearchproductcode, String connectionId, String customerId, String resultString) {
		
		return "OLI_APPTYPE_SUBMIT";
	}
	
}