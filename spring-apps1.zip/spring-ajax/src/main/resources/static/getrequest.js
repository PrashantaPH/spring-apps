GET: 
$(document).ready(
	function(){
		$("#getAllBooks").click(function(event){
			event.preventDefault();
			ajaxGet();
		});
		
		function ajaxGet(){
			$.ajax({
				type : "GET",
				url :  "getBooks",
				success : function(result){
					if(result.status == "Success"){
						$('#getResultDiv ul').empty();
						/*var custList = "";*/
						$.each( result.data, function( key, book ) {
 							 alert( key + ": " + book );
						});
						/*$.each(result.data, functon(i,book){
							var user = "Book Name " +book.bookName +
									  ", Book Author " +book.bookAuthor +"<br>";
							$('#getResuldDiv .list-group').append(book)
						});*/
						
						console.log("Success: "+ result);
					}else {
						$("#getResultDiv").html("<strong>Error</strong>");
						console.log("Fail: ", result);
					}
					
				},
				error : function(e){
					$("#getResultDiv").html("<strong>Error</strong>");
					console.log("ERROR: ", e);
				}
			});
		}
	})