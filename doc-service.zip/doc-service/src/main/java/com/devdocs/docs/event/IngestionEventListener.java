package com.devdocs.docs.event;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.HashMap;


@Slf4j
@Component
@RequiredArgsConstructor
public class IngestionEventListener {

    private final WebClient.Builder webClientBuilder;

    @Value("${ingestion.base-url}")
    private String ingestionBaseUrl;

    @Value("${service.auth.token}")
    private String serviceToken;

    @Async
    @EventListener
    public void onIngestionRequested(IngestionRequestedEvent event) {
        var payload = new HashMap<String, Object>();
        payload.put("documentId", event.documentId());
        payload.put("documentVersionId", event.versionId());
        payload.put("content", event.content());
        if (event.reindexRequest() != null) {
            payload.put("reindex", true);
            payload.put("refreshVectors", event.reindexRequest().getRefreshVectors());
            payload.put("upsert", event.reindexRequest().getUpsert());
            payload.put("embeddingModel", event.reindexRequest().getEmbeddingModel());
            payload.put("chunking", event.reindexRequest().getChunking());
        }

        webClientBuilder.baseUrl(ingestionBaseUrl)
            .build()
            .post()
            .uri("/api/v1/ingestions")
            .header("X-Service-Token", serviceToken)
            .bodyValue(payload)
            .retrieve()
            .toBodilessEntity()
            .doOnError(ex -> log.error("Failed to trigger ingestion for document {}", event.documentId(), ex))
            .subscribe();
    }
}
