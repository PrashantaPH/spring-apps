package com.springmvc.mapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;

import com.springmvc.dto.Registration;

@Service
public class RegistrationDataMapper {

	
	public Context registrationSetData(Registration registration) {
		
		Context context = new Context();
		
		Map<String, Object> map = new HashMap<>();
		
		map.put("registration", registration);
		
		context.setVariables(map);
		
		return context;
	}
}
