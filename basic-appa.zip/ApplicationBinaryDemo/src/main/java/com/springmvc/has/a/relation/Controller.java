package com.springmvc.has.a.relation;

public class Controller {

	
	public static void main(String[] args) {
		
		Controller controller = new Controller();
		
		Chield chield = new Chield();
		
		Parent parent = new Parent();
		
		chield.setName("PPH");
		
		chield = controller.setResult(parent,chield);
		
		parent.setObject(chield);
		
	}
	
	private Chield setResult(Parent parent,Chield chield) {
		if(parent != null)
		chield.setResult("Yes");
		
		return chield;
	}
}
