package com.controller;

import java.util.HashMap;
import java.util.Map;

import com.springmvc.dto.Client;
import com.springmvc.dto.PersonalClient;

public class DriverClient {

	public static void main(String[] args) {
		
		PersonalClient rqPersonal = new PersonalClient();
		
		PersonalClient rsPersonal = new PersonalClient();
		
		Client resClient = new Client();
		
		Map<Boolean, Client> map = new HashMap<>();
        
//        map.put(!compareValues( rqPersonal.getFirstNames(), rsPersonal.getFirstNames() ), insertPersonChanges( resClient ));
//        map.put(!compareValues( rqPersonal.getLastName(), rsPersonal.getLastName() ), insertPersonChanges( resClient ));
//        map.put(!compareValues( rqPersonal.getBirthDate(), rsPersonal.getBirthDate() ) , insertPersonChanges( resClient ));
//        map.put(!compareValues( rqPersonal.getGenderCode(), rsPersonal.getGenderCode() ), insertPersonChanges( resClient ));
//        map.put(!compareValues( rqPersonal.getMaritalStatusID(), rsPersonal.getMaritalStatusID() ), insertPersonChanges( resClient ));
//        map.put(!compareValues( rqPersonal.getnINumber(), rsPersonal.getnINumber() ), insertPersonChanges( resClient ));
//        map.put(!compareValues( rqPersonal.getSpouseID(), rsPersonal.getSpouseID() ), insertPersonChanges( resClient ));
//        map.put(!compareValues( rqPersonal.getTitle(), rsPersonal.getTitle() ), insertPersonChanges( resClient ));
//
//        if(map.containsKey(resClient)) {
//        	copyRqToRsClient( rqClient, resClient );
//        	return insertPersonChanges(rqClient);
//        }
	}
}
