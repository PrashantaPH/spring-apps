ALTER TABLE IF EXISTS chat_sessions
    ADD COLUMN IF NOT EXISTS title VARCHAR(255),
    ADD COLUMN IF NOT EXISTS system_prompt TEXT,
    ADD COLUMN IF NOT EXISTS doc_id BIGINT;

ALTER TABLE IF EXISTS chat_messages
    ADD COLUMN IF NOT EXISTS msg_version INTEGER NOT NULL DEFAULT 1,
    ADD COLUMN IF NOT EXISTS edited_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS edited_by BIGINT;

CREATE TABLE IF NOT EXISTS chat_message_revisions (
    id BIGSERIAL PRIMARY KEY,
    message_id BIGINT NOT NULL REFERENCES chat_messages(id) ON DELETE CASCADE,
    version INTEGER NOT NULL,
    content TEXT NOT NULL,
    edited_at TIMESTAMPTZ NOT NULL,
    edited_by BIGINT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_chat_message_revisions_message ON chat_message_revisions(message_id, version);

CREATE TABLE IF NOT EXISTS audit_events (
    id BIGSERIAL PRIMARY KEY,
    actor_id BIGINT NOT NULL,
    action VARCHAR(64) NOT NULL,
    resource_type VARCHAR(64) NOT NULL,
    resource_id VARCHAR(128),
    details TEXT,
    created_at TIMESTAMPTZ NOT NULL
);

ALTER TABLE IF EXISTS document_chunks
    ADD COLUMN IF NOT EXISTS version_id BIGINT,
    ADD COLUMN IF NOT EXISTS active BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_chat_document_chunks_active ON document_chunks(document_id, active);
