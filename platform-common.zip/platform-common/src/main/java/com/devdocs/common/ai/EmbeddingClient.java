package com.devdocs.common.ai;

import com.devdocs.common.ai.dto.EmbeddingResponse;

public interface EmbeddingClient {
    EmbeddingResponse embed(String text);
}
