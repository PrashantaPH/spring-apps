package com.devdocs.docs.dto;

import java.util.List;
import lombok.Data;

@Data
public class AclDto {
    private Boolean isPublic;
    private List<Long> allowedUserIds;
}
