package com.intellect.enumdemo;

public class User {

	private EnumDemo name;
	private EnumDemo last;
	
	public EnumDemo getName() {
		return name;
	}
	public void setName(EnumDemo name) {
		this.name = name;
	}
	public EnumDemo getLast() {
		return last;
	}
	public void setLast(EnumDemo last) {
		this.last = last;
	}
	
	
	
}
