package com.devdocs.ingestion.security;

import com.devdocs.common.security.SecurityErrorHandler;
import com.devdocs.common.security.ServiceTokenAuthenticationFilterBase;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ServiceTokenAuthenticationFilter extends ServiceTokenAuthenticationFilterBase {

    private static final String INGESTION_PATH_PREFIX = "/api/v1/ingestions";

    public ServiceTokenAuthenticationFilter(SecurityErrorHandler securityErrorHandler,
        @Value("${service.auth.token}") String serviceToken) {
        super(securityErrorHandler, serviceToken, INGESTION_PATH_PREFIX, false);
    }
}
