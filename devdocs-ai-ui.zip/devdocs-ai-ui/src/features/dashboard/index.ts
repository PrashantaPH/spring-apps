export { default as DashboardPage } from '../../pages/Dashboard';
