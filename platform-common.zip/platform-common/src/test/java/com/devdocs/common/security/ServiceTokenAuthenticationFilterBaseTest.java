package com.devdocs.common.security;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicBoolean;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

class ServiceTokenAuthenticationFilterBaseTest {

    @AfterEach
    void clearContext() {
        org.springframework.security.core.context.SecurityContextHolder.clearContext();
    }

    @Test
    void allowsRequestWhenTokenMatches() throws ServletException, IOException {
        ServiceTokenAuthenticationFilterBase filter = new TestFilter("/api/v1/ingestions", false);
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/api/v1/ingestions/run");
        request.addHeader("X-Service-Token", "token");
        MockHttpServletResponse response = new MockHttpServletResponse();
        AtomicBoolean chainCalled = new AtomicBoolean(false);
        FilterChain chain = (req, res) -> chainCalled.set(true);

        filter.doFilter(request, response, chain);

        assertThat(chainCalled).isTrue();
        assertThat(org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication())
            .isNotNull();
    }

    @Test
    void blocksWhenTokenMissingAndRequired() throws ServletException, IOException {
        ServiceTokenAuthenticationFilterBase filter = new TestFilter("/api/v1/ingestions/callbacks", true);
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/api/v1/ingestions/callbacks");
        MockHttpServletResponse response = new MockHttpServletResponse();
        AtomicBoolean chainCalled = new AtomicBoolean(false);
        FilterChain chain = (req, res) -> chainCalled.set(true);

        filter.doFilter(request, response, chain);

        assertThat(chainCalled).isFalse();
        assertThat(response.getStatus()).isEqualTo(401);
    }

    @Test
    void blocksWhenTokenInvalidAndPresent() throws ServletException, IOException {
        ServiceTokenAuthenticationFilterBase filter = new TestFilter("/api/v1/ingestions", false);
        MockHttpServletRequest request = new MockHttpServletRequest("POST", "/api/v1/ingestions/run");
        request.addHeader("X-Service-Token", "bad");
        MockHttpServletResponse response = new MockHttpServletResponse();
        AtomicBoolean chainCalled = new AtomicBoolean(false);
        FilterChain chain = (req, res) -> chainCalled.set(true);

        filter.doFilter(request, response, chain);

        assertThat(chainCalled).isFalse();
        assertThat(response.getStatus()).isEqualTo(401);
    }

    private static class TestFilter extends ServiceTokenAuthenticationFilterBase {
        TestFilter(String pathPrefix, boolean requireHeader) {
            super(new SecurityErrorHandler(new ObjectMapper().findAndRegisterModules()), "token", pathPrefix, requireHeader);
        }
    }
}
