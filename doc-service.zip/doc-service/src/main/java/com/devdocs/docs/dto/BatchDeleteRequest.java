package com.devdocs.docs.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import java.util.List;
import lombok.Data;

@Data
public class BatchDeleteRequest {
    @NotEmpty
    private List<Long> documentIds;

    @NotNull
    private String mode; // soft or hard

    private Boolean deleteVectors;
    private Boolean purgeBinary;
}
