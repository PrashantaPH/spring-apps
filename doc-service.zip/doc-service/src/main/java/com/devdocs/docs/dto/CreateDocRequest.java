package com.devdocs.docs.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CreateDocRequest {
    @NotBlank
    private String title;

    @NotBlank
    private String content;

    private String description;
    private String sourceUri;
}
