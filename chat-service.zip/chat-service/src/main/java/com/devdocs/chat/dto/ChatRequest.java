package com.devdocs.chat.dto;

import com.devdocs.common.ai.dto.ChatMessageDto;
import com.fasterxml.jackson.annotation.JsonAlias;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import java.util.List;
import lombok.Data;

@Data
public class ChatRequest {
//    @JsonAlias("documentId")
//    @Positive
    private Long docId;

    @NotBlank
    private String question;

    private List<ChatMessageDto> history;
}
