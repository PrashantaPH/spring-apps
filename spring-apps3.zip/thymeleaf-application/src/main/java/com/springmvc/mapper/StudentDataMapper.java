package com.springmvc.mapper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;

import com.springmvc.dto.Student;

@Service
public class StudentDataMapper {

	public Context setData(List<Student> studentList) {
		
		Context context = new Context();
		
		Map<String, Object> data = new HashMap<>();
		
		data.put("students", studentList);
		
		context.setVariables(data);
		
		return context;
	}
}
