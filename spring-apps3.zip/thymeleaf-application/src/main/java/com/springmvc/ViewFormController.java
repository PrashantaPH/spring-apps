package com.springmvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.springmvc.dto.Employee;

@Controller
public class ViewFormController {

	@GetMapping("/bootstrap")
	public String formCreation(@ModelAttribute("user") User user) {
		System.out.println();
		return "bootstrapcss";
	}
	
	List<Employee> employees = new ArrayList<>();
	
	@GetMapping("/showSaveEmployee")
	public String showEmployeeForm(Model model) {
		Employee employee = new Employee();
		model.addAttribute("employee", employee);
		return "saveemployee";
	}
	
	@PostMapping("/saveEmployee")
	public String save(@ModelAttribute("employee") Employee employee) {
		System.out.println(employee);
		employees.add(employee);
		return "redirect:/";
	}
	
	@GetMapping({"/list", "/"})
	public ModelAndView getAll() {
		ModelAndView andView = new ModelAndView("listOfEmployees");
		andView.addObject("employees", employees);
		return andView;
	}
	
	
}
