import { Container, Typography } from '@mui/material';

const NotFound = () => (
  <Container maxWidth="md" sx={{ mt: 8, textAlign: 'center' }}>
    <Typography variant="h3">404</Typography>
    <Typography variant="h5" gutterBottom>
      Page Not Found
    </Typography>
    <Typography variant="body1">
      The requested resource doesn’t exist. Go back to the homepage.
    </Typography>
  </Container>
);

export default NotFound;
