package com.devdocs.chat.web;

@Deprecated(forRemoval = true)
public class ChatServiceExceptionHandler {
}
