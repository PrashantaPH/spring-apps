package com.convertion.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class ConvertionService {
	
	private static final int PRETTY_PRINT = 4;
	
	private static final String HKIIP = "HKIIP";
	private static final String IB = "IB";
	private static final String PIIB = "PIIB";
	private static final String ISA = "ISA";
	private static final String POST = "POST";
	private static final String PRE = "PRE";
	private static final String TIA = "TIA";
	private static final String UT = "UT";
	private static final String PIRIB = "PIRIB";
	private static final String PSGIIA = "PSGIIA";
	private static final String PAMIIB = "PAMIIB";
	private static final String PHKIIP = "PHKIIP";
	
	private static final String PRODUCT_NAME = "ProductName";
	
	private static final String OBJ_HEADER = "ObjHeader";
	private static final String COL_SJPFUND_CHARGE = "colSJPFundCharge";
	private static final String OBJ_SJPFUND_CHARGE = "objSJPFundCharge";
	private static final String COL_SJPFUND_PORTFOLIO = "colSJPFundPortfolio";
	private static final String OBJ_SJPFUND_PORTFOLIO = "objSJPFundPortfolio";
	private static final String HDR_SJPCONT_CHARGE = "hdrSJPContCharge";
	private static final String HDR_SJPPRODUCT_CHARGES_OVERRIDE = "hdrSJPProductChargesOverride";
	
	private	JSONArray jsonHKIIPFundArray = new JSONArray();
	private	JSONArray jsonIBFundArray = new JSONArray();
	private	JSONArray jsonPIIBFundArray = new JSONArray();
	private	JSONArray jsonISAFundArray = new JSONArray();
	private	JSONArray jsonPOSTFundArray = new JSONArray();
	private	JSONArray jsonPREFundArray = new JSONArray();
	private	JSONArray jsonPSGIIAFundArray = new JSONArray();
	private	JSONArray jsonTIAFundArray = new JSONArray();
	private	JSONArray jsonUTFundArray = new JSONArray();
	private	JSONArray jsonPIRIBFundArray = new JSONArray();
	private	JSONArray jsonPAMIIBFundArray = new JSONArray();
	private	JSONArray jsonPHKIIPFundArray = new JSONArray();
	
	private	JSONArray jsonIBPortfolioArray = new JSONArray();
	private	JSONArray jsonPIIBPortfolioArray = new JSONArray();
	private	JSONArray jsonISAPortfolioArray = new JSONArray();
	private	JSONArray jsonPOSTPortfolioArray = new JSONArray();
	private	JSONArray jsonPREPortfolioArray = new JSONArray();
	private	JSONArray jsonPSGIIAPortfolioArray = new JSONArray();
	private	JSONArray jsonTIAPortfolioArray = new JSONArray();
	private	JSONArray jsonUTPortfolioArray = new JSONArray();
	private	JSONArray jsonPIRIBPortfolioArray = new JSONArray();
	private	JSONArray jsonPAMIIBPortfolioArray = new JSONArray();
	
	private JSONObject jsonObjColSJPHKIIPFundCharge = new JSONObject();
	private JSONObject jsonObjColSJPIBFundCharge = new JSONObject();
	private JSONObject jsonObjColSJPPIIBFundCharge = new JSONObject();
	private JSONObject jsonObjColSJPISAFundCharge = new JSONObject();
	private JSONObject jsonObjColSJPPOSTFundCharge = new JSONObject();
	private JSONObject jsonObjColSJPPREFundCharge = new JSONObject();
	private JSONObject jsonObjColSJPPSGIIAFundCharge = new JSONObject();
	private JSONObject jsonObjColSJPTIAFundCharge = new JSONObject();
	private JSONObject jsonObjColSJPUTFundCharge = new JSONObject();
	private JSONObject jsonObjColSJPPIRIBFundCharge = new JSONObject();
	private JSONObject jsonObjColSJPPAMIIBFundCharge = new JSONObject();
	private JSONObject jsonObjColSJPPHKIIPFundCharge = new JSONObject();
	
	private JSONObject jsonObjColSJPIBFundPortfolio = new JSONObject();
	private JSONObject jsonObjColSJPPIIBFundPortfolio = new JSONObject();
	private JSONObject jsonObjColSJPISAFundPortfolio = new JSONObject();
	private JSONObject jsonObjColSJPPOSTFundPortfolio = new JSONObject();
	private JSONObject jsonObjColSJPPREFundPortfolio = new JSONObject();
	private JSONObject jsonObjColSJPPSGIIAFundPortfolio = new JSONObject();
	private JSONObject jsonObjColSJPTIAFundPortfolio = new JSONObject();
	private JSONObject jsonObjColSJPUTFundPortfolio = new JSONObject();
	private JSONObject jsonObjColSJPPIRIBFundPortfolio = new JSONObject();
	private JSONObject jsonObjColSJPPAMIIBFundPortfolio = new JSONObject();
	
	private JSONArray jsonObjhdrSJPHKIIPContCharge = new JSONArray();
	private JSONArray jsonObjhdrSJPIBContCharge = new JSONArray();
	private JSONArray jsonObjhdrSJPPIIBContCharge = new JSONArray();
	private JSONArray jsonObjhdrSJPISAContCharge = new JSONArray();
	private JSONArray jsonObjhdrSJPPOSTContCharge = new JSONArray();
	private JSONArray jsonObjhdrSJPPREContCharge = new JSONArray();
	private JSONArray jsonObjhdrSJPPSGIIAContCharge = new JSONArray();
	private JSONArray jsonObjhdrSJPTIAContCharge = new JSONArray();
	private JSONArray jsonObjhdrSJPUTContCharge = new JSONArray();
	private JSONArray jsonObjhdrSJPPIRIBContCharge = new JSONArray();
	private JSONArray jsonObjhdrSJPPAMIIBContCharge = new JSONArray();
	private JSONArray jsonObjhdrSJPPHKIIPContCharge = new JSONArray();
	
	private JSONArray jsonObjhdrSJPHKIIPProductChargesOverride = new JSONArray();
	private JSONArray jsonObjhdrSJPIBProductChargesOverride = new JSONArray();
	private JSONArray jsonObjhdrSJPPIIBProductChargesOverride = new JSONArray();
	private JSONArray jsonObjhdrSJPISAProductChargesOverride = new JSONArray();
	private JSONArray jsonObjhdrSJPPOSTProductChargesOverride = new JSONArray();
	private JSONArray jsonObjhdrSJPPREProductChargesOverride = new JSONArray();
	private JSONArray jsonObjhdrSJPPSGIIAProductChargesOverride = new JSONArray();
	private JSONArray jsonObjhdrSJPTIAProductChargesOverride = new JSONArray();
	private JSONArray jsonObjhdrSJPUTProductChargesOverride = new JSONArray();
	private JSONArray jsonObjhdrSJPPIRIBProductChargesOverride = new JSONArray();
	private JSONArray jsonObjhdrSJPPAMIIBProductChargesOverride = new JSONArray();
	private JSONArray jsonObjhdrSJPPHKIIPProductChargesOverride = new JSONArray();
	
	private JSONObject jsonObjHKIIPHeader = new JSONObject();
	private JSONObject jsonObjIBHeader = new JSONObject();
	private JSONObject jsonObjPIIBHeader = new JSONObject();
	private JSONObject jsonObjISAHeader = new JSONObject();
	private JSONObject jsonObjPOSTHeader = new JSONObject();
	private JSONObject jsonObjPREHeader = new JSONObject();
	private JSONObject jsonObjPSGIIAHeader = new JSONObject();
	private JSONObject jsonObjTIAHeader = new JSONObject();
	private JSONObject jsonObjUTHeader = new JSONObject();
	private JSONObject jsonObjPIRIBHeader = new JSONObject();
	private JSONObject jsonObjPAMIIBHeader = new JSONObject();
	private JSONObject jsonObjPHKIIPHeader = new JSONObject();
	
	private JSONObject jsonObjHeader = new JSONObject();
	
	public static void main(String[] args) throws Exception {
		ConvertionService convertionService = new ConvertionService();
		String strPath = "src/main/resources/IFDSStandingData.xml";
//		String strPath = "src/main/resources/IFDSStandingData_R1490.xml";
		try {
			String strXml = new String(Files.readAllBytes(Paths.get(strPath)));
			convertionService.convertXMLtoJson(strXml);
			
//			XPathFactory xPathFactory = XPathFactory.newInstance();
//			XPath xPath = xPathFactory.newXPath();
//			XPathExpression xPathExpression = xPath.compile("//entry[@PortfolioRef='SYSTEM.1010' and @ProductCode='PISA']");
//			Document document = getDocument();
//			Node node = (Node) xPathExpression.evaluate(document, XPathConstants.NODE);
//			Element element = (Element) node;
//			System.out.println(element.getAttribute("PortfolioName"));
			
	} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void convertXMLtoJson(String strXml) throws Exception {
		JSONObject jsonObject = XML.toJSONObject(strXml);
		JSONObject objHeader = jsonObject.getJSONObject(OBJ_HEADER);
		JSONObject colSJPFundPortfolio = objHeader.getJSONObject(COL_SJPFUND_PORTFOLIO);
		JSONArray objSJPFundPortfolioArr = colSJPFundPortfolio.getJSONArray(OBJ_SJPFUND_PORTFOLIO);
		
		JSONObject colSJPFundCharge = objHeader.getJSONObject(COL_SJPFUND_CHARGE);
		JSONArray objSJPFundChargeArr = colSJPFundCharge.getJSONArray(OBJ_SJPFUND_CHARGE);
		
		JSONArray hdrSJPContChargeArr = objHeader.getJSONArray(HDR_SJPCONT_CHARGE);
		JSONArray hdrSJPProductChargesOverrideArr = objHeader.getJSONArray(HDR_SJPPRODUCT_CHARGES_OVERRIDE);
		
		for(Object object : objSJPFundPortfolioArr) {
			JSONObject objSJPFundPortfolio = (JSONObject) object;
			String productName = objSJPFundPortfolio.getString(PRODUCT_NAME);
			if(productName.equals(IB)) {
				convertSJPFundPortfolioToJson(objSJPFundPortfolio);
				jsonIBPortfolioArray.put(objSJPFundPortfolio);
			} else if(productName.equals(PIIB)) {
				convertSJPFundPortfolioToJson(objSJPFundPortfolio);
				jsonPIIBPortfolioArray.put(objSJPFundPortfolio);
			} else if(productName.equals(PIRIB)) {
				convertSJPFundPortfolioToJson(objSJPFundPortfolio);
				jsonPIRIBPortfolioArray.put(objSJPFundPortfolio);
			} else if(productName.equals(ISA)) {
				convertSJPFundPortfolioToJson(objSJPFundPortfolio);
				jsonISAPortfolioArray.put(objSJPFundPortfolio);
			} else if(productName.equals(POST)) {
				convertSJPFundPortfolioToJson(objSJPFundPortfolio);
				jsonPOSTPortfolioArray.put(objSJPFundPortfolio);
			} else if(productName.equals(PRE)) {
				convertSJPFundPortfolioToJson(objSJPFundPortfolio);
				jsonPREPortfolioArray.put(objSJPFundPortfolio);
			} else if(productName.equals(TIA)) {
				convertSJPFundPortfolioToJson(objSJPFundPortfolio);
				jsonTIAPortfolioArray.put(objSJPFundPortfolio);
			} else if(productName.equals(UT)) {
				convertSJPFundPortfolioToJson(objSJPFundPortfolio);
				jsonUTPortfolioArray.put(objSJPFundPortfolio);
			} else if(productName.equals(PSGIIA)) {
				convertSJPFundPortfolioToJson(objSJPFundPortfolio);
				jsonPSGIIAPortfolioArray.put(objSJPFundPortfolio);
			} else if(productName.equals(PAMIIB)) {
				convertSJPFundPortfolioToJson(objSJPFundPortfolio);
				jsonPAMIIBPortfolioArray.put(objSJPFundPortfolio);
			}
		}
		
		for (Object object : objSJPFundChargeArr) {
			JSONObject objSJPFundCharge = (JSONObject) object;
			String productName = objSJPFundCharge.getString(PRODUCT_NAME);
			if(productName.equals(HKIIP)) {
				convertSJPFundChargeToJson(objSJPFundCharge);
				jsonHKIIPFundArray.put(objSJPFundCharge);
			} else if(productName.equals(IB)) {
				convertSJPFundChargeToJson(objSJPFundCharge);
				jsonIBFundArray.put(objSJPFundCharge);
			} else if(productName.equals(PIIB)) {
				convertSJPFundChargeToJson(objSJPFundCharge);
				jsonPIIBFundArray.put(objSJPFundCharge);
			} else if(productName.equals(PIRIB)) {
				convertSJPFundChargeToJson(objSJPFundCharge);
				jsonPIRIBFundArray.put(objSJPFundCharge);
			} else if(productName.equals(ISA)) {
				convertSJPFundChargeToJson(objSJPFundCharge);
				jsonISAFundArray.put(objSJPFundCharge);
			} else if(productName.equals(POST)) {
				convertSJPFundChargeToJson(objSJPFundCharge);
				jsonPOSTFundArray.put(objSJPFundCharge);
			} else if(productName.equals(PRE)) {
				convertSJPFundChargeToJson(objSJPFundCharge);
				jsonPREFundArray.put(objSJPFundCharge);
			} else if(productName.equals(TIA)) {
				convertSJPFundChargeToJson(objSJPFundCharge);
				jsonTIAFundArray.put(objSJPFundCharge);
			} else if(productName.equals(UT)) {
				convertSJPFundChargeToJson(objSJPFundCharge);
				jsonUTFundArray.put(objSJPFundCharge);
			} else if(productName.equals(PSGIIA)) {
				convertSJPFundChargeToJson(objSJPFundCharge);
				jsonPSGIIAFundArray.put(objSJPFundCharge);
			} else if(productName.equals(PAMIIB)) {
				convertSJPFundChargeToJson(objSJPFundCharge);
				jsonPAMIIBFundArray.put(objSJPFundCharge);
			} else if(productName.equals(PHKIIP)) {
				convertSJPFundChargeToJson(objSJPFundCharge);
				jsonPHKIIPFundArray.put(objSJPFundCharge);
			}
		}
		
		for (Object object : hdrSJPContChargeArr) {
			JSONObject hdrSJPContCharge = (JSONObject) object;
			String productName = hdrSJPContCharge.getString(PRODUCT_NAME);
			if(productName.equals(HKIIP)) {
				jsonObjhdrSJPHKIIPContCharge.put(hdrSJPContCharge);
			} else if(productName.equals(IB)) {
				jsonObjhdrSJPIBContCharge.put(hdrSJPContCharge);
			} else if(productName.equals(PIIB)) {
				jsonObjhdrSJPPIIBContCharge.put(hdrSJPContCharge);
			} else if(productName.equals(PIRIB)) {
				jsonObjhdrSJPPIRIBContCharge.put(hdrSJPContCharge);
			} else if(productName.equals(ISA)) {
				jsonObjhdrSJPISAContCharge.put(hdrSJPContCharge);
			} else if(productName.equals(POST)) {
				jsonObjhdrSJPPOSTContCharge.put(hdrSJPContCharge);
			} else if(productName.equals(PRE)) {
				jsonObjhdrSJPPREContCharge.put(hdrSJPContCharge);
			} else if(productName.equals(TIA)) {
				jsonObjhdrSJPTIAContCharge.put(hdrSJPContCharge);
			} else if(productName.equals(UT)) {
				jsonObjhdrSJPUTContCharge.put( hdrSJPContCharge);
			} else if(productName.equals(PSGIIA)) {
				jsonObjhdrSJPPSGIIAContCharge.put( hdrSJPContCharge);
			} else if(productName.equals(PAMIIB)) {
				jsonObjhdrSJPPAMIIBContCharge.put(hdrSJPContCharge);
			} else if(productName.equals(PHKIIP)) {
				jsonObjhdrSJPPHKIIPContCharge.put(hdrSJPContCharge);
			}
		}
		
		for (Object object : hdrSJPProductChargesOverrideArr) {
			JSONObject hdrSJPProductChargesOverride = (JSONObject) object;
			String productName = hdrSJPProductChargesOverride.getString(PRODUCT_NAME);
			if(productName.equals(HKIIP)) {
				jsonObjhdrSJPHKIIPProductChargesOverride.put(hdrSJPProductChargesOverride);
			} else if(productName.equals(IB)) {
				jsonObjhdrSJPIBProductChargesOverride.put(hdrSJPProductChargesOverride);
			} else if(productName.equals(PIIB)) {
				jsonObjhdrSJPPIIBProductChargesOverride.put(hdrSJPProductChargesOverride);
			} else if(productName.equals(PIRIB)) {
				jsonObjhdrSJPPIRIBProductChargesOverride.put(hdrSJPProductChargesOverride);
			} else if(productName.equals(ISA)) {
				jsonObjhdrSJPISAProductChargesOverride.put(hdrSJPProductChargesOverride);
			} else if(productName.equals(POST)) {
				jsonObjhdrSJPPOSTProductChargesOverride.put(hdrSJPProductChargesOverride);
			} else if(productName.equals(PRE)) {
				jsonObjhdrSJPPREProductChargesOverride.put(hdrSJPProductChargesOverride);
			} else if(productName.equals(TIA)) {
				jsonObjhdrSJPTIAProductChargesOverride.put(hdrSJPProductChargesOverride);
			} else if(productName.equals(UT)) {
				jsonObjhdrSJPUTProductChargesOverride.put( hdrSJPProductChargesOverride);
			} else if(productName.equals(PSGIIA)) {
				jsonObjhdrSJPPSGIIAProductChargesOverride.put( hdrSJPProductChargesOverride);
			} else if(productName.equals(PAMIIB)) {
				jsonObjhdrSJPPAMIIBProductChargesOverride.put(hdrSJPProductChargesOverride);
			} else if(productName.equals(PHKIIP)) {
				jsonObjhdrSJPPHKIIPProductChargesOverride.put(hdrSJPProductChargesOverride);
			}
		}
		
		jsonObjColSJPHKIIPFundCharge.put(OBJ_SJPFUND_CHARGE, jsonHKIIPFundArray);
		
		jsonObjHKIIPHeader.put(COL_SJPFUND_CHARGE, jsonObjColSJPHKIIPFundCharge);
		jsonObjHKIIPHeader.put(HDR_SJPCONT_CHARGE, jsonObjhdrSJPHKIIPContCharge.get(0));
		jsonObjHKIIPHeader.put(HDR_SJPPRODUCT_CHARGES_OVERRIDE, jsonObjhdrSJPHKIIPProductChargesOverride.get(0));
		jsonObjHKIIPHeader = convertNumberAsString(jsonObjHKIIPHeader);
		jsonObjHeader.put(OBJ_HEADER, jsonObjHKIIPHeader);
		System.out.println(jsonObjHeader.toString(PRETTY_PRINT)+ "\n-------------------------------------HKIIP");
		
		jsonObjColSJPIBFundCharge.put(OBJ_SJPFUND_CHARGE, jsonIBFundArray);
		jsonObjColSJPIBFundPortfolio.put(OBJ_SJPFUND_PORTFOLIO, jsonIBPortfolioArray);
		
		jsonObjIBHeader.put(COL_SJPFUND_CHARGE, jsonObjColSJPIBFundCharge);
		jsonObjIBHeader.put(COL_SJPFUND_PORTFOLIO, jsonObjColSJPIBFundPortfolio);
		jsonObjIBHeader.put(HDR_SJPCONT_CHARGE, jsonObjhdrSJPIBContCharge.get(0));
		jsonObjIBHeader.put(HDR_SJPPRODUCT_CHARGES_OVERRIDE, jsonObjhdrSJPIBProductChargesOverride.get(0));
		jsonObjIBHeader = convertNumberAsString(jsonObjIBHeader);
		jsonObjHeader.put(OBJ_HEADER, jsonObjIBHeader);
		System.out.println(jsonObjHeader.toString(PRETTY_PRINT)+ "\n-------------------------------------IB");
		
		jsonObjColSJPPIIBFundCharge.put(OBJ_SJPFUND_CHARGE, jsonPIIBFundArray);
		jsonObjColSJPPIIBFundPortfolio.put(OBJ_SJPFUND_PORTFOLIO, jsonPIIBPortfolioArray);
		
		jsonObjPIIBHeader.put(COL_SJPFUND_CHARGE, jsonObjColSJPPIIBFundCharge);
		jsonObjPIIBHeader.put(COL_SJPFUND_PORTFOLIO, jsonObjColSJPPIIBFundPortfolio);
		jsonObjPIIBHeader.put(HDR_SJPCONT_CHARGE, jsonObjhdrSJPPIIBContCharge.get(0));
		jsonObjPIIBHeader.put(HDR_SJPPRODUCT_CHARGES_OVERRIDE, jsonObjhdrSJPPIIBProductChargesOverride.get(0));
		jsonObjPIIBHeader = convertNumberAsString(jsonObjPIIBHeader);
		jsonObjHeader.put(OBJ_HEADER, jsonObjPIIBHeader);
		System.out.println(jsonObjHeader.toString(PRETTY_PRINT)+ "\n-------------------------------------PIIB");
		
		jsonObjColSJPISAFundCharge.put(OBJ_SJPFUND_CHARGE, jsonISAFundArray);
		jsonObjColSJPISAFundPortfolio.put(OBJ_SJPFUND_PORTFOLIO, jsonISAPortfolioArray);
		
		jsonObjISAHeader.put(COL_SJPFUND_CHARGE, jsonObjColSJPISAFundCharge);
		jsonObjISAHeader.put(COL_SJPFUND_PORTFOLIO, jsonObjColSJPISAFundPortfolio);
		jsonObjISAHeader.put(HDR_SJPCONT_CHARGE, jsonObjhdrSJPISAContCharge.get(0));
		jsonObjISAHeader.put(HDR_SJPPRODUCT_CHARGES_OVERRIDE, jsonObjhdrSJPISAProductChargesOverride.get(0));
		jsonObjISAHeader = convertNumberAsString(jsonObjISAHeader);
		jsonObjHeader.put(OBJ_HEADER, jsonObjISAHeader);
		System.out.println(jsonObjHeader.toString(PRETTY_PRINT)+ "\n-------------------------------------ISA");
		
		jsonObjColSJPPOSTFundCharge.put(OBJ_SJPFUND_CHARGE, jsonPOSTFundArray);
		jsonObjColSJPPOSTFundPortfolio.put(OBJ_SJPFUND_PORTFOLIO, jsonPOSTPortfolioArray);
		
		jsonObjPOSTHeader.put(COL_SJPFUND_CHARGE, jsonObjColSJPPOSTFundCharge);
		jsonObjPOSTHeader.put(COL_SJPFUND_PORTFOLIO, jsonObjColSJPPOSTFundPortfolio);
		jsonObjPOSTHeader.put(HDR_SJPCONT_CHARGE, jsonObjhdrSJPPOSTContCharge.get(0));
		jsonObjPOSTHeader.put(HDR_SJPPRODUCT_CHARGES_OVERRIDE, jsonObjhdrSJPPOSTProductChargesOverride.get(0));
		jsonObjPOSTHeader.put("hdrSJPAdvice",  objHeader.getJSONObject("hdrSJPAdvice"));
		jsonObjPOSTHeader = convertNumberAsString(jsonObjPOSTHeader);
		jsonObjHeader.put(OBJ_HEADER, jsonObjPOSTHeader);
		System.out.println(jsonObjHeader.toString(PRETTY_PRINT)+ "\n-------------------------------------POST");
		
		jsonObjColSJPPREFundCharge.put(OBJ_SJPFUND_CHARGE, jsonPREFundArray);
		jsonObjColSJPPREFundPortfolio.put(OBJ_SJPFUND_PORTFOLIO, jsonPREPortfolioArray);
		
		jsonObjPREHeader.put(COL_SJPFUND_CHARGE, jsonObjColSJPPREFundCharge);
		jsonObjPREHeader.put(COL_SJPFUND_PORTFOLIO, jsonObjColSJPPREFundPortfolio);
		jsonObjPREHeader.put(HDR_SJPCONT_CHARGE, jsonObjhdrSJPPREContCharge.get(0));
		jsonObjPREHeader.put(HDR_SJPPRODUCT_CHARGES_OVERRIDE, jsonObjhdrSJPPREProductChargesOverride.get(0));
		jsonObjPREHeader.put("hdrSJPAdvice",  objHeader.getJSONObject("hdrSJPAdvice"));
		jsonObjPREHeader = convertNumberAsString(jsonObjPREHeader);
		jsonObjHeader.put(OBJ_HEADER, jsonObjPREHeader);
		System.out.println(jsonObjHeader.toString(PRETTY_PRINT)+ "\n-------------------------------------PRE");
		
		jsonObjColSJPPSGIIAFundCharge.put(OBJ_SJPFUND_CHARGE, jsonPSGIIAFundArray);
		jsonObjColSJPPSGIIAFundPortfolio.put(OBJ_SJPFUND_PORTFOLIO, jsonPSGIIAPortfolioArray);
		
		jsonObjPSGIIAHeader.put(COL_SJPFUND_CHARGE, jsonObjColSJPPSGIIAFundCharge);
		jsonObjPSGIIAHeader.put(COL_SJPFUND_PORTFOLIO, jsonObjColSJPPSGIIAFundPortfolio);
		jsonObjPSGIIAHeader.put(HDR_SJPCONT_CHARGE, jsonObjhdrSJPPSGIIAContCharge.get(0));
		jsonObjPSGIIAHeader.put(HDR_SJPPRODUCT_CHARGES_OVERRIDE, jsonObjhdrSJPPSGIIAProductChargesOverride.get(0));
		jsonObjPSGIIAHeader = convertNumberAsString(jsonObjPSGIIAHeader);
		jsonObjHeader.put(OBJ_HEADER, jsonObjPSGIIAHeader);
		System.out.println(jsonObjHeader.toString(PRETTY_PRINT)+ "\n-------------------------------------PSGIIA");
		
		jsonObjColSJPTIAFundCharge.put(OBJ_SJPFUND_CHARGE, jsonTIAFundArray);
		jsonObjColSJPTIAFundPortfolio.put(OBJ_SJPFUND_PORTFOLIO, jsonTIAPortfolioArray);
		
		jsonObjTIAHeader.put(COL_SJPFUND_CHARGE, jsonObjColSJPTIAFundCharge);
		jsonObjTIAHeader.put(COL_SJPFUND_PORTFOLIO, jsonObjColSJPTIAFundPortfolio);
		jsonObjTIAHeader.put(HDR_SJPCONT_CHARGE, jsonObjhdrSJPTIAContCharge.get(0));
		jsonObjTIAHeader.put(HDR_SJPPRODUCT_CHARGES_OVERRIDE, jsonObjhdrSJPTIAProductChargesOverride.get(0));
		jsonObjTIAHeader = convertNumberAsString(jsonObjTIAHeader);
		jsonObjHeader.put(OBJ_HEADER, jsonObjTIAHeader);
		System.out.println(jsonObjHeader.toString(PRETTY_PRINT)+ "\n-------------------------------------TIA");
		
		jsonObjColSJPUTFundCharge.put(OBJ_SJPFUND_CHARGE, jsonUTFundArray);
		jsonObjColSJPUTFundPortfolio.put(OBJ_SJPFUND_PORTFOLIO, jsonUTPortfolioArray);
		
		jsonObjUTHeader.put(COL_SJPFUND_CHARGE, jsonObjColSJPUTFundCharge);
		jsonObjUTHeader.put(COL_SJPFUND_PORTFOLIO, jsonObjColSJPUTFundPortfolio);
		jsonObjUTHeader.put(HDR_SJPCONT_CHARGE, jsonObjhdrSJPUTContCharge.get(0));
		jsonObjUTHeader.put(HDR_SJPPRODUCT_CHARGES_OVERRIDE, jsonObjhdrSJPUTProductChargesOverride.get(0));
		jsonObjUTHeader = convertNumberAsString(jsonObjUTHeader);
		jsonObjHeader.put(OBJ_HEADER, jsonObjUTHeader);
		System.out.println(jsonObjHeader.toString(PRETTY_PRINT)+ "\n-------------------------------------UT");
		
		jsonObjColSJPPIRIBFundCharge.put(OBJ_SJPFUND_CHARGE, jsonPIRIBFundArray);
		jsonObjColSJPPIRIBFundPortfolio.put(OBJ_SJPFUND_PORTFOLIO, jsonPIRIBPortfolioArray);
		
		jsonObjPIRIBHeader.put(COL_SJPFUND_CHARGE, jsonObjColSJPPIRIBFundCharge);
		jsonObjPIRIBHeader.put(COL_SJPFUND_PORTFOLIO, jsonObjColSJPPIRIBFundPortfolio);
		jsonObjPIRIBHeader.put(HDR_SJPCONT_CHARGE, jsonObjhdrSJPPIRIBContCharge.get(0));
		jsonObjPIRIBHeader.put(HDR_SJPPRODUCT_CHARGES_OVERRIDE, jsonObjhdrSJPPIRIBProductChargesOverride.get(0));
		jsonObjPIRIBHeader = convertNumberAsString(jsonObjPIRIBHeader);
		jsonObjHeader.put(OBJ_HEADER, jsonObjPIRIBHeader);
		System.out.println(jsonObjHeader.toString(PRETTY_PRINT)+ "\n-------------------------------------PIRIB");
		
		jsonObjColSJPPAMIIBFundCharge.put(OBJ_SJPFUND_CHARGE, jsonPAMIIBFundArray);
		jsonObjColSJPPAMIIBFundPortfolio.put(OBJ_SJPFUND_PORTFOLIO, jsonPAMIIBPortfolioArray);
		
		jsonObjPAMIIBHeader.put(COL_SJPFUND_CHARGE, jsonObjColSJPPAMIIBFundCharge);
		jsonObjPAMIIBHeader.put(COL_SJPFUND_PORTFOLIO, jsonObjColSJPPAMIIBFundPortfolio);
		jsonObjPAMIIBHeader.put(HDR_SJPCONT_CHARGE, jsonObjhdrSJPPAMIIBContCharge.get(0));
		jsonObjPAMIIBHeader.put(HDR_SJPPRODUCT_CHARGES_OVERRIDE, jsonObjhdrSJPPAMIIBProductChargesOverride.get(0));
		jsonObjPAMIIBHeader = convertNumberAsString(jsonObjPAMIIBHeader);
		jsonObjHeader.put(OBJ_HEADER, jsonObjPAMIIBHeader);
		System.out.println(jsonObjHeader.toString(PRETTY_PRINT)+ "\n-------------------------------------PAMIIB");
		
		jsonObjColSJPPHKIIPFundCharge.put(OBJ_SJPFUND_CHARGE, jsonPHKIIPFundArray);
		
		jsonObjPHKIIPHeader.put(COL_SJPFUND_CHARGE, jsonObjColSJPPHKIIPFundCharge);
		jsonObjPHKIIPHeader.put(HDR_SJPCONT_CHARGE, jsonObjhdrSJPPHKIIPContCharge.get(0));
		jsonObjPHKIIPHeader.put(HDR_SJPPRODUCT_CHARGES_OVERRIDE, jsonObjhdrSJPPHKIIPProductChargesOverride.get(0));
		jsonObjPHKIIPHeader = convertNumberAsString(jsonObjPHKIIPHeader);
		jsonObjHeader.put(OBJ_HEADER, jsonObjPHKIIPHeader);
		System.out.println(jsonObjHeader.toString(PRETTY_PRINT)+ "\n-------------------------------------PHKIIP");
	}
	
	private static void convertSJPFundChargeToJson(JSONObject objSJPFundCharge) throws XPathExpressionException {
		String productName = objSJPFundCharge.getString(PRODUCT_NAME);
		Object unitReference = objSJPFundCharge.get("UnitReference"); //This should be object type
		
		XPathFactory xPathFactory = XPathFactory.newInstance();
		XPath xPath = xPathFactory.newXPath();
		XPathExpression xPathExpression = xPath.compile("//entry[@UnitRef='" + unitReference +"']");
//		XPathExpression xPathExpression = xPath.compile("//entry[@UnitRef='" + unitReference +"' and @ProductCode='"+getProductCode(productName, "")+"']");
		Document document = getDocument();
		Node node = (Node) xPathExpression.evaluate(document, XPathConstants.NODE);
		Element element = (Element) node;
		if (element != null) {
			String fundName = element.getAttribute("fundName");
			String fundStatus = element.getAttribute("FundStatus");
			String transanctioncast = element.getAttribute("transactioncost");
			
			if (productName.equals("ISA") || productName.equals("UT")) {
				objSJPFundCharge.put("TransactionCost", transanctioncast);
			} else {
				if(!fundName.equals("Cash Account")) {
					if (productName.equals("PIIB") || productName.equals("PIRIB") || productName.equals("PAMIIB")) { // PIIB,PIRIB=SJPI, PAMIIB=SJPA
						fundName = fundName.substring(5, fundName.length() - 4); // Remove currency
					} else if (productName.equals("PSGIIA")) { // PSGIIA=SJPISG
						fundName = fundName.substring(7, fundName.length() - 4);
					} else if (productName.equals("PHKIIP")) {
						fundName = fundName.substring(0, fundName.length() - 4);
					}
				}
			}
			objSJPFundCharge.put("FundName", fundName);// object.put("FundName", "Asia Pacific");
			objSJPFundCharge.put("FundStatus", fundStatus);
		}
	}
	
	private static void convertSJPFundPortfolioToJson(JSONObject objSJPFundPortfolio) throws XPathExpressionException {
		String productName = objSJPFundPortfolio.getString(PRODUCT_NAME);
		String fundPortfolioRef = objSJPFundPortfolio.getString("FundPortfolioRef");
		String fundPortfolioShortName = objSJPFundPortfolio.getString("FundPortfolioShortName");
		
		XPathFactory xPathFactory = XPathFactory.newInstance();
		XPath xPath = xPathFactory.newXPath();
		objSJPFundPortfolio.remove("FundPortfolioName");
//		XPathExpression xPathExpression = xPath.compile("//entry[@PortfolioRef='" + fundPortfolioRef + "']");
//		XPathExpression xPathExpression = xPath.compile("//entry[@PortfolioRef='"+fundPortfolioRef+"' and @ProductCode='"+getProductCode(productName, fundPortfolioShortName)+"']");
		if(fundPortfolioShortName.contains("Inc")) {
			objSJPFundPortfolio.put("CarrierCode", "I");
		} else if(fundPortfolioShortName.contains("Acc")) {
			objSJPFundPortfolio.put("CarrierCode", "A");
		}
		if(productName.equals("ISA")) {
			setISAPortfolio(xPath, fundPortfolioRef, productName, fundPortfolioShortName, objSJPFundPortfolio);
		} else {
			XPathExpression xPathExpression = xPath.compile("//entry[@PortfolioRef='" + fundPortfolioRef + "']");
			Document document = getDocument();
			Node node = (Node) xPathExpression.evaluate(document, XPathConstants.NODE);
			Element element = (Element) node;
//			objSJPFundPortfolio.remove("FundPortfolioName");
			if (element != null) {
				String portfolioName = element.getAttribute("PortfolioName");
				String portfolioStatus = element.getAttribute("PortfolioStatus");
				String portfoioVersion = element.getAttribute("PortfoioVersion");
//				String productCode = element.getAttribute("ProductCode");
//				if (productName.equals("ISA")) {
//					objSJPFundPortfolio.put("SubProductType", productCode);
//				}
				if (productName.equals("PIIB") || productName.equals("PIRIB") || productName.equals("PSGIIA") || productName.equals("PAMIIB")) {
					portfolioName = portfolioName.substring(0, portfolioName.length() - 3).concat("Portfolio");
				}
				objSJPFundPortfolio.put("PortfolioName", portfolioName);
				objSJPFundPortfolio.put("PortfolioStatus", portfolioStatus);
				objSJPFundPortfolio.put("PortfolioVersion", portfoioVersion);
			}
		}
	}
	
	private static void setISAPortfolio(XPath xPath, String fundPortfolioRef, String productName, String fundPortfolioShortName, JSONObject objSJPFundPortfolio) throws XPathExpressionException {
		if(productName.equals("ISA") && (fundPortfolioShortName.contains("Junior") || fundPortfolioShortName.contains("JISA"))) {
			productName = "PJISA";	
		} else {
			productName = "PISA";
		}
		XPathExpression xPathExpression = xPath.compile("//entry[@PortfolioRef='"+fundPortfolioRef+"' and @ProductCode='"+ productName +"']");
		Node node = (Node) xPathExpression.evaluate(getDocument(), XPathConstants.NODE);
		Element element = (Element) node;
		if (element != null) {
			String portfolioName = element.getAttribute("PortfolioName");
			String portfolioStatus = element.getAttribute("PortfolioStatus");
			String portfoioVersion = element.getAttribute("PortfoioVersion");
			String productCode = element.getAttribute("ProductCode");
			objSJPFundPortfolio.put("SubProductType", productCode);
			objSJPFundPortfolio.put("PortfolioName", portfolioName);
			objSJPFundPortfolio.put("PortfolioStatus", portfolioStatus);
			objSJPFundPortfolio.put("PortfolioVersion", portfoioVersion);
		}
	}
	
	private static String getProductCode(String productName, String fundPortfolioShortName) {
		if(productName.equals("IB")) {
			productName = "PIB";
		} else if(productName.equals("ISA") && (fundPortfolioShortName.contains("Junior") || fundPortfolioShortName.contains("JISA"))) {
			productName = "PJISA";								// Strategic Growth Portfolio Acc. St. James's Place JISA
		} else if(productName.equals("ISA")) {					// Conservative Portfolio Acc. St. James's Place Junior S&S ISA
			productName = "PISA";
		} else if(productName.equals("UT")) {
			productName = "PUT";
		}
		return productName;
	}
	
	private static JSONObject convertNumberAsString(JSONObject jsonObject) {
		for(Object key : jsonObject.keySet()) {
			Object object = jsonObject.get(key+"");
			if(object instanceof JSONObject) {
				jsonObject.put(key+"", convertNumberAsString((JSONObject)object));
			} else if (object instanceof JSONArray) {
				JSONArray jsonArray = (JSONArray)object;
				for( int i=0; i< jsonArray.length(); i++) {
					Object obj = jsonArray.get(i);
					if(obj instanceof JSONObject) {
						jsonArray.put(i, convertNumberAsString((JSONObject)obj));
					} 
					else if(obj instanceof Number) {
//						if(obj instanceof Integer) {
							jsonArray.put(i, obj.toString());
//						} 
						
					}
				}
			} else if(object instanceof Number) {
				jsonObject.put(key+"", object.toString());
			}
		}
		return jsonObject;
	}

	private static Document getDocument() {
		Document document = null;
		try {
			DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = builderFactory.newDocumentBuilder();
			document = builder.parse("src/main/resources/IFDSFundCodeMapping.xml");
//			document = builder.parse("src/main/resources/IFDSFundCodeMapping_R1490.xml");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return document;
	}

}
