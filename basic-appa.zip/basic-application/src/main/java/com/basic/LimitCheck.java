package com.basic;

public class LimitCheck {
	
	public static void main(String[] args) {
		int limit = 3;
		
		if(limit < 10) {
			System.out.println("true");
		}else {
			System.out.println("false");
		}
	}

	
}
