package com.devdocs.ingestion.web;

import com.devdocs.common.web.ApiError;
import com.devdocs.common.web.ErrorCode;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@Slf4j
@RestControllerAdvice
public class IngestionServiceExceptionHandler {

    @ExceptionHandler(ContentTooLargeException.class)
    public ResponseEntity<ApiError> handleContentTooLarge(ContentTooLargeException ex) {
        return buildError(HttpStatus.PAYLOAD_TOO_LARGE, ErrorCode.VALIDATION_ERROR,
            ex.getMessage(), ex);
    }

    private ResponseEntity<ApiError> buildError(HttpStatus status, ErrorCode code, String message, Exception ex) {
        log.error("Handling error: {} {}", code, status.value(), ex);
        ApiError body = ApiError.builder()
            .statusCode(status.value())
            .errorCode(code.name())
            .message(message)
            .timestamp(OffsetDateTime.now(ZoneOffset.UTC))
            .build();
        return ResponseEntity.status(status).body(body);
    }
}
