import { Routes, Route, Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../context/Auth.context';
import Login from '../pages/Login';
import Register from '../pages/Register';
import Dashboard from '../pages/Dashboard';
import Home from '../pages/Home';
import UploadDocument from '../pages/UploadDocument' // Import the UploadPage component
// import DocumentsPage from '../pages/DocumentsPage'; // Import if you have it
// import ChatPage from '../pages/ChatPage'; // Import if you have it
// import SettingsPage from '../pages/SettingsPage'; // Import if you have it
// import GenerateReleaseNotes from '../pages/GenerateReleaseNotes'; // Import if you have it
// import GenerateUserStories from '../pages/GenerateUserStories'; // Import if you have it
// import GenerateOnboarding from '../pages/GenerateOnboarding'; // Import if you have it
// import ProfilePage from '../pages/ProfilePage'; // Import if you have it
import NotFound from '../pages/NotFound';
import MainLayout from '../layouts/MainLayout';
import Chat from '../pages/Chat';

interface AppRoutesProps {
  mode: 'light' | 'dark';
  setMode: (mode: 'light' | 'dark') => void;
}

const PrivateRoute = () => {
  const { isAuthenticated, isAuthLoading } = useAuth();
  if (isAuthLoading) return <div>Loading...</div>;
  return isAuthenticated ? <Outlet /> : <Navigate to="/login" replace />;
};

const PublicRoute = () => {
  const { isAuthenticated } = useAuth();
  return isAuthenticated ? <Navigate to="/dashboard" replace /> : <Outlet />;
};

const AppRoutes: React.FC<AppRoutesProps> = ({ mode, setMode }) => (
  <Routes>
    <Route element={<PublicRoute />}>
      <Route path="/login" element={<Login mode={mode} setMode={setMode} />} />
      <Route path="/register" element={<Register mode={mode} setMode={setMode} />} />
      <Route path="/" element={<Navigate to="/login" replace />} />
    </Route>

    <Route element={<PrivateRoute />}>
      <Route element={<MainLayout mode={mode} setMode={setMode} />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/dashboard/home" element={<Home />} />
        
        {/* Document Management Routes */}
        <Route path="/dashboard/upload" element={<UploadDocument />} />
        <Route path="/dashboard/chat" element={<Chat />} />

        {/* <Route path="/dashboard/documents" element={<DocumentsPage />} /> */}
        
        {/* Chat Route */}
        {/* <Route path="/dashboard/chat" element={<ChatPage />} /> */}
        
        {/* Generate Routes */}
        {/* <Route path="/dashboard/generate/release-notes" element={<GenerateReleaseNotes />} /> */}
        {/* <Route path="/dashboard/generate/user-stories" element={<GenerateUserStories />} /> */}
        {/* <Route path="/dashboard/generate/onboarding" element={<GenerateOnboarding />} /> */}
        
        {/* Settings and Profile */}
        {/* <Route path="/dashboard/settings" element={<SettingsPage />} /> */}
        {/* <Route path="/dashboard/profile" element={<ProfilePage />} /> */}
      </Route>
    </Route>

    <Route path="*" element={<NotFound />} />
  </Routes>
);

export default AppRoutes;