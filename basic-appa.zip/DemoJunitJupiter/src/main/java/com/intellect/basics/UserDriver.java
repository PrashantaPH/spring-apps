package com.intellect.basics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class UserDriver {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		
		ArrayList<Integer> arrayList = new ArrayList<>();
		
		System.out.println("Enter the list of numbers");
		while(scanner.hasNextInt()) {
			Integer integer = scanner.nextInt();
			arrayList.add(integer);
			
		}
		Collections.sort(arrayList);
		
		System.out.println("Ascending Order : "+arrayList);
		
		arrayList.sort(Comparator.reverseOrder());
		
		System.out.println("Descending Order : "+arrayList);
		
		
		/*System.out.println("Enter number of elements");
		int n = scanner.nextInt();
		int arr[] = new int[n];
		
		System.out.println("Enter the elemnets");
		for(int i = 0;i<n;i++)
		{
			 arr[i]=scanner.nextInt();
			 
		}
		
		System.out.println("The arry elements"+ Arrays.toString(arr));*/
		
		
	}
}
