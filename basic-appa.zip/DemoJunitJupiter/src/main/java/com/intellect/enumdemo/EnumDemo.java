package com.intellect.enumdemo;

public enum EnumDemo {

	Prashnata,
	Hanumantagoudra;
	
}


