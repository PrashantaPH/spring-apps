package com.springmvc.dto;

public class Client {

	
}
