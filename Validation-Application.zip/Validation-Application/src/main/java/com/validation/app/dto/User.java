package com.validation.app.dto;

import com.validation.app.validation.ValidatePassword;

public class User {

	private String username;
	
	@ValidatePassword
	private String password;
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
