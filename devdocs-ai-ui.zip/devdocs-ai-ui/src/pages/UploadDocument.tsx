import React, { useMemo, useState } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  InputLabel,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  TableSortLabel,
  TextField,
  Typography,
  useTheme,
} from '@mui/material';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import DeleteIcon from '@mui/icons-material/Delete';

type Order = 'asc' | 'desc';

type DocumentRow = {
  id: string;
  title: string;
  shortDesc: string;
  fileName: string;
  fileType: string;
  rowText: string;
  createdAt: string;
  file?: File | null;
};

const initialData: DocumentRow[] = [
  {
    id: '1',
    title: 'Intro to Project',
    shortDesc: 'Overview PDF',
    fileName: 'project-intro.pdf',
    fileType: 'pdf',
    rowText: 'First page summary',
    createdAt: new Date().toISOString(),
    file: null,
  },
  {
    id: '2',
    title: 'Readme',
    shortDesc: 'Notes in markdown',
    fileName: 'README.md',
    fileType: 'md',
    rowText: 'Setup instructions',
    createdAt: new Date().toISOString(),
    file: null,
  },
];

function descendingComparator<T>(a: T, b: T, orderBy: keyof T) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function getComparator<Key extends keyof any>(
  order: Order,
  orderBy: Key
): (a: { [key in Key]: any }, b: { [key in Key]: any }) => number {
  return order === 'desc'
    ? (a, b) => descendingComparator(a, b, orderBy)
    : (a, b) => -descendingComparator(a, b, orderBy);
}

export default function UploadDocument() {
  const theme = useTheme();
  const [rows, setRows] = useState<DocumentRow[]>(initialData);
  const [order, setOrder] = useState<Order>('asc');
  const [orderBy, setOrderBy] = useState<keyof DocumentRow>('title');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [search, setSearch] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);

  // Upload form state
  const [formTitle, setFormTitle] = useState('');
  const [formShortDesc, setFormShortDesc] = useState('');
  const [formRowText, setFormRowText] = useState('');
  const [formFile, setFormFile] = useState<File | null>(null);

  const handleRequestSort = (property: keyof DocumentRow) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleChangePage = (_: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearch(e.target.value);
    setPage(0);
  };

  const filteredRows = useMemo(() => {
    if (!search.trim()) return rows;
    const q = search.toLowerCase();
    return rows.filter(
      (r) =>
        r.title.toLowerCase().includes(q) ||
        r.shortDesc.toLowerCase().includes(q) ||
        r.rowText.toLowerCase().includes(q)
    );
  }, [rows, search]);

  const sortedRows = useMemo(() => {
    const comparator = getComparator(order, orderBy);
    const stabilized = filteredRows.map((el, index) => [el, index] as [DocumentRow, number]);
    stabilized.sort((a, b) => {
      const cmp = comparator(a[0] as any, b[0] as any);
      if (cmp !== 0) return cmp;
      return a[1] - b[1];
    });
    return stabilized.map((el) => el[0]);
  }, [filteredRows, order, orderBy]);

  const visibleRows = useMemo(
    () => sortedRows.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage),
    [sortedRows, page, rowsPerPage]
  );

  const handleOpenDialog = () => setDialogOpen(true);
  const handleCloseDialog = () => {
    setDialogOpen(false);
    setFormTitle('');
    setFormShortDesc('');
    setFormRowText('');
    setFormFile(null);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files && e.target.files[0];
    if (f) setFormFile(f);
  };

  const handleUpload = () => {
    if (!formTitle || !formFile) {
      // You can add better validation/UI feedback
      return;
    }
    const newRow: DocumentRow = {
      id: String(Date.now()),
      title: formTitle,
      shortDesc: formShortDesc,
      fileName: formFile.name,
      fileType: formFile.name.split('.').pop()?.toLowerCase() ?? '',
      rowText: formRowText,
      createdAt: new Date().toISOString(),
      file: formFile,
    };
    setRows((prev) => [newRow, ...prev]);
    handleCloseDialog();
  };

  const handleDelete = (id: string) => {
    setRows((prev) => prev.filter((r) => r.id !== id));
  };

  return (
    <Box p={2}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h5">Upload Documents</Typography>

        <Box display="flex" gap={1} alignItems="center">
          <TextField
            variant="outlined"
            size="small"
            placeholder="Search title / description / text"
            value={search}
            onChange={handleSearchChange}
            sx={{ width: 360 }}
          />
          <Button
            variant="contained"
            startIcon={<UploadFileIcon />}
            onClick={handleOpenDialog}
            color="primary"
          >
            Upload Doc
          </Button>
        </Box>
      </Box>

      <Paper
        elevation={0}
        sx={{
          background: theme.palette.background.paper,
        }}
      >
        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell sortDirection={orderBy === 'title' ? order : false}>
                  <TableSortLabel
                    active={orderBy === 'title'}
                    direction={orderBy === 'title' ? order : 'asc'}
                    onClick={() => handleRequestSort('title')}
                  >
                    Title
                  </TableSortLabel>
                </TableCell>

                <TableCell sortDirection={orderBy === 'shortDesc' ? order : false}>
                  <TableSortLabel
                    active={orderBy === 'shortDesc'}
                    direction={orderBy === 'shortDesc' ? order : 'asc'}
                    onClick={() => handleRequestSort('shortDesc')}
                  >
                    Short Description
                  </TableSortLabel>
                </TableCell>

                <TableCell sortDirection={orderBy === 'fileName' ? order : false}>
                  <TableSortLabel
                    active={orderBy === 'fileName'}
                    direction={orderBy === 'fileName' ? order : 'asc'}
                    onClick={() => handleRequestSort('fileName')}
                  >
                    File
                  </TableSortLabel>
                </TableCell>

                <TableCell sortDirection={orderBy === 'rowText' ? order : false}>
                  <TableSortLabel
                    active={orderBy === 'rowText'}
                    direction={orderBy === 'rowText' ? order : 'asc'}
                    onClick={() => handleRequestSort('rowText')}
                  >
                    Row Text
                  </TableSortLabel>
                </TableCell>

                <TableCell sortDirection={orderBy === 'createdAt' ? order : false}>
                  <TableSortLabel
                    active={orderBy === 'createdAt'}
                    direction={orderBy === 'createdAt' ? order : 'asc'}
                    onClick={() => handleRequestSort('createdAt')}
                  >
                    Created
                  </TableSortLabel>
                </TableCell>

                <TableCell>Actions</TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {visibleRows.map((row) => (
                <TableRow key={row.id} hover>
                  <TableCell>{row.title}</TableCell>
                  <TableCell>{row.shortDesc}</TableCell>
                  <TableCell>
                    <Box display="flex" alignItems="center" gap={1}>
                      <Typography variant="body2">{row.fileName}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        ({row.fileType})
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>{row.rowText}</TableCell>
                  <TableCell>
                    {new Date(row.createdAt).toLocaleString(undefined, {
                      year: 'numeric',
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </TableCell>
                  <TableCell>
                    <Box display="flex" gap={1}>
                      <IconButton
                        size="small"
                        color="error"
                        onClick={() => handleDelete(row.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                      {row.file && (
                        <Button
                          size="small"
                          variant="outlined"
                          href={URL.createObjectURL(row.file)}
                          target="_blank"
                          rel="noreferrer"
                        >
                          Open
                        </Button>
                      )}
                    </Box>
                  </TableCell>
                </TableRow>
              ))}

              {visibleRows.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} align="center">
                    No documents found
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>

        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={sortedRows.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </Paper>

      {/* Upload Dialog */}
      <Dialog open={dialogOpen} onClose={handleCloseDialog} maxWidth="sm" fullWidth>
        <DialogTitle>Upload Document</DialogTitle>
        <DialogContent>
          <Box display="flex" flexDirection="column" gap={2} mt={1}>
            <TextField
              label="Title"
              value={formTitle}
              onChange={(e) => setFormTitle(e.target.value)}
              fullWidth
            />
            <TextField
              label="Short Description"
              value={formShortDesc}
              onChange={(e) => setFormShortDesc(e.target.value)}
              fullWidth
            />
            <TextField
              label="Row Text"
              value={formRowText}
              onChange={(e) => setFormRowText(e.target.value)}
              fullWidth
              multiline
              minRows={2}
            />

            <Box>
              <InputLabel shrink>File (pdf, txt, md)</InputLabel>
              <input
                accept=".pdf,.txt,.md"
                type="file"
                onChange={handleFileChange}
                style={{ marginTop: 8 }}
              />
              {formFile && (
                <Typography variant="body2" mt={1}>
                  Selected: {formFile.name}
                </Typography>
              )}
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button variant="contained" onClick={handleUpload}>
            Upload
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}