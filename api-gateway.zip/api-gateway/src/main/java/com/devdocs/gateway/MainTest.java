package com.devdocs.gateway;

import java.util.Scanner;

public class MainTest {

    public static void main(String[] args) {
        System.out.println("hello world");
        Scanner sc=new Scanner(System.in);
        System.out.println("enter the number");
    }
}
