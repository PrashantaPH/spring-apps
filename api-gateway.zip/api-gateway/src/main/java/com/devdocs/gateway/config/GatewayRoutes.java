package com.devdocs.gateway.config;

import com.devdocs.gateway.ratelimit.BasicRateLimiterFilter;
import com.devdocs.gateway.security.JwtAuthGatewayFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayRoutes {

    @Value("${gateway.services.auth-uri}")
    private String authUri;

    @Value("${gateway.services.doc-uri}")
    private String docUri;

    @Value("${gateway.services.chat-uri}")
    private String chatUri;

    @Bean
    public RouteLocator routes(RouteLocatorBuilder builder,
                               JwtAuthGatewayFilter jwtAuthGatewayFilter,
                               BasicRateLimiterFilter rateLimiterFilter) {
        return builder.routes()
            .route("auth", r -> r.path("/api/v1/auth/**", "/api/v1/me")
                .uri(authUri))
            .route("docs", r -> r.path("/api/v1/docs/**")
                .filters(f -> f.filter(rateLimiterFilter).filter(jwtAuthGatewayFilter))
                .uri(docUri))
            .route("chat", r -> r.path("/api/v1/chat/**")
                .filters(f -> f.filter(rateLimiterFilter).filter(jwtAuthGatewayFilter))
                .uri(chatUri))
            .route("chats", r -> r.path("/api/v1/chats/**")
                .filters(f -> f.filter(rateLimiterFilter).filter(jwtAuthGatewayFilter))
                .uri(chatUri))
            .route("generate", r -> r.path("/api/v1/generate/**")
                .filters(f -> f.filter(rateLimiterFilter).filter(jwtAuthGatewayFilter))
                .uri(chatUri))
            .build();
    }
}
