package com.springmvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springmvc.dto.User;

@Controller
public class RegisterController {

	@GetMapping("/register")
	public String registerForm(@ModelAttribute("user") User user) {
		System.out.println(user);
		return "register";
	}
}

