package com.convertion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConvertionAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
