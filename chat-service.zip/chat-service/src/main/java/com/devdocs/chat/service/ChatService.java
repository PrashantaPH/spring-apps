package com.devdocs.chat.service;

import com.devdocs.chat.dto.ChatHistoryResponse;
import com.devdocs.chat.dto.ChatMessageHistoryDto;
import com.devdocs.chat.dto.ChatMessageRevisionDto;
import com.devdocs.chat.dto.ChatRequest;
import com.devdocs.chat.dto.ChatResponse;
import com.devdocs.chat.dto.CitationDto;
import com.devdocs.chat.dto.EditMessageRequest;
import com.devdocs.chat.dto.RegenerateRequest;
import com.devdocs.chat.dto.UpdateChatRequest;
import com.devdocs.chat.entity.ChatMessage;
import com.devdocs.chat.entity.ChatMessageRevision;
import com.devdocs.chat.entity.ChatSession;
import com.devdocs.chat.repository.ChatMessageRepository;
import com.devdocs.chat.repository.ChatMessageRevisionRepository;
import com.devdocs.chat.repository.ChatSessionRepository;
import com.devdocs.common.ai.EmbeddingClient;
import com.devdocs.common.ai.LlmClient;
import com.devdocs.common.ai.dto.ChatMessageDto;
import com.devdocs.common.ai.dto.EmbeddingResponse;
import com.devdocs.common.ai.dto.LlmRequest;
import com.devdocs.common.ai.dto.LlmResponse;
import com.devdocs.common.vector.VectorIndexService;
import com.devdocs.common.exception.ForbiddenException;
import com.devdocs.common.exception.NotFoundException;
import jakarta.transaction.Transactional;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ChatService {

    private final ChatSessionRepository chatSessionRepository;
    private final ChatMessageRepository chatMessageRepository;
    private final ChatMessageRevisionRepository chatMessageRevisionRepository;
    private final EmbeddingClient embeddingClient;
    private final LlmClient llmClient;
    private final VectorIndexService vectorIndexService;
    private final AuditService auditService;

    @Value("${chat.max-context-chunks}")
    private int maxChunks;

    @Transactional
    public ChatResponse chat(String userEmail, ChatRequest request) {
        Long userId = Math.abs(userEmail.hashCode()) + 0L;
        ChatSession session = request.getDocId() != null
            ? chatSessionRepository.findTopByUserIdAndDocIdOrderByUpdatedAtDesc(userId, request.getDocId())
                .orElseGet(() -> createSession(userId))
            : chatSessionRepository.findTopByUserIdOrderByUpdatedAtDesc(userId)
                .orElseGet(() -> createSession(userId));

        if (session.getDocId() == null && request.getDocId() != null) {
            session.setDocId(request.getDocId());
        }

        persistMessage(session, "user", request.getQuestion(), userId);

        EmbeddingResponse embedding = embeddingClient.embed(request.getQuestion());
        List<String> contextChunks = fetchNearestChunks(request.getDocId(), embedding.getVector());

        List<ChatMessageDto> messages = buildPromptMessages(session.getSystemPrompt(), contextChunks);
        if (request.getHistory() != null && !request.getHistory().isEmpty()) {
            messages.addAll(request.getHistory().stream()
                .map(item -> ChatMessageDto.builder()
                    .role(item.getRole())
                    .content(item.getContent())
                    .build())
                .collect(Collectors.toList()));
        }

        boolean historyHasLatestUserQuestion = request.getHistory() != null && !request.getHistory().isEmpty()
            && "user".equalsIgnoreCase(request.getHistory().getLast().getRole())
            && request.getQuestion().equals(request.getHistory().getLast().getContent());
        if (!historyHasLatestUserQuestion) {
            messages.add(ChatMessageDto.builder()
                .role("user")
                .content(request.getQuestion())
                .build());
        }

        LlmResponse response = llmClient.chat(LlmRequest.builder()
            .messages(messages)
            .build());

        persistMessage(session, "assistant", response.getAnswer(), userId);

        if (session.getTitle() == null) {
            session.setTitle(buildTitle(request.getQuestion()));
            chatSessionRepository.save(session);
        }

        CitationDto citation = CitationDto.builder()
            .docId(request.getDocId())
            .title("Document " + request.getDocId())
            .url("https://docs.devdocs.ai/docs/" + request.getDocId())
            .build();

        auditService.record(userId, "CHAT_ASK", "CHAT", String.valueOf(session.getId()),
            java.util.Map.of("docId", request.getDocId()));

        return ChatResponse.builder()
            .answer(response.getAnswer())
            .citations(List.of(citation))
            .build();
    }

    @Transactional
    public ChatSession updateChat(Long userId, Long chatId, UpdateChatRequest request) {
        ChatSession session = chatSessionRepository.findByIdAndUserId(chatId, userId)
            .orElseThrow(() -> new NotFoundException("Chat session not found."));
        if (request.getTitle() != null) {
            session.setTitle(request.getTitle());
        }
        if (request.getSystemPrompt() != null) {
            session.setSystemPrompt(request.getSystemPrompt());
        }
        session.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        auditService.record(userId, "CHAT_UPDATE", "CHAT", String.valueOf(chatId), java.util.Map.of());
        return chatSessionRepository.save(session);
    }

    @Transactional
    public ChatMessage editMessage(Long userId, Long chatId, Long messageId, EditMessageRequest request) {
        ChatSession session = chatSessionRepository.findByIdAndUserId(chatId, userId)
            .orElseThrow(() -> new NotFoundException("Chat session not found."));
        ChatMessage message = chatMessageRepository.findByIdAndSessionId(messageId, session.getId())
            .orElseThrow(() -> new NotFoundException("Chat message not found."));

        if (!"user".equalsIgnoreCase(message.getRole())) {
            throw new ForbiddenException("Only user messages can be edited.");
        }

        ChatMessageRevision revision = new ChatMessageRevision();
        revision.setMessage(message);
        revision.setVersion(message.getMsgVersion() == null ? 1 : message.getMsgVersion());
        revision.setContent(message.getContent());
        revision.setEditedAt(OffsetDateTime.now(ZoneOffset.UTC));
        revision.setEditedBy(userId);
        chatMessageRevisionRepository.save(revision);

        message.setContent(request.getContent());
        int nextVersion = message.getMsgVersion() == null ? 2 : message.getMsgVersion() + 1;
        message.setMsgVersion(nextVersion);
        message.setEditedAt(OffsetDateTime.now(ZoneOffset.UTC));
        message.setEditedBy(userId);
        message.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        chatMessageRepository.save(message);

        auditService.record(userId, "CHAT_MESSAGE_EDIT", "CHAT_MESSAGE", String.valueOf(messageId),
            java.util.Map.of("chatId", chatId, "version", nextVersion));
        return message;
    }

    @Transactional
    public ChatResponse regenerate(Long userId, Long chatId, Long messageId, RegenerateRequest request) {
        ChatSession session = chatSessionRepository.findByIdAndUserId(chatId, userId)
            .orElseThrow(() -> new NotFoundException("Chat session not found."));
        ChatMessage message = chatMessageRepository.findByIdAndSessionId(messageId, session.getId())
            .orElseThrow(() -> new NotFoundException("Chat message not found."));

        if (!"user".equalsIgnoreCase(message.getRole())) {
            throw new ForbiddenException("Only user messages can be regenerated.");
        }

        Long docId = request.getDocId() != null ? request.getDocId() : session.getDocId();
        EmbeddingResponse embedding = embeddingClient.embed(message.getContent());
        List<String> contextChunks = (request.getUseRag() == null || request.getUseRag())
            ? fetchNearestChunks(docId, embedding.getVector())
            : List.of();

        List<ChatMessageDto> messages = buildPromptMessages(session.getSystemPrompt(), contextChunks);
        messages.add(ChatMessageDto.builder().role("user").content(message.getContent()).build());

        LlmResponse response = llmClient.chat(LlmRequest.builder().messages(messages).build());
        persistMessage(session, "assistant", response.getAnswer(), userId);

        CitationDto citation = CitationDto.builder()
            .docId(docId)
            .title(docId == null ? null : "Document " + docId)
            .url(docId == null ? null : "https://docs.devdocs.ai/docs/" + docId)
            .build();

        auditService.record(userId, "CHAT_REGENERATE", "CHAT_MESSAGE", String.valueOf(messageId),
            java.util.Map.of("chatId", chatId, "docId", docId));

        return ChatResponse.builder()
            .answer(response.getAnswer())
            .citations(citation.getDocId() == null ? List.of() : List.of(citation))
            .build();
    }

    @Transactional
    public ChatHistoryResponse getHistory(Long userId, Long chatId, boolean includeEdits) {
        ChatSession session = chatSessionRepository.findByIdAndUserId(chatId, userId)
            .orElseThrow(() -> new NotFoundException("Chat session not found."));
        List<ChatMessage> messages = chatMessageRepository.findBySessionIdOrderByCreatedAtAsc(session.getId());

        List<ChatMessageHistoryDto> dtoMessages = messages.stream()
            .map(message -> ChatMessageHistoryDto.builder()
                .id(message.getId())
                .role(message.getRole())
                .content(message.getContent())
                .msgVersion(message.getMsgVersion())
                .createdAt(message.getCreatedAt())
                .updatedAt(message.getUpdatedAt())
                .editedAt(message.getEditedAt())
                .editedBy(message.getEditedBy())
                .revisions(includeEdits ? loadRevisions(message.getId()) : List.of())
                .build())
            .collect(Collectors.toList());

        return ChatHistoryResponse.builder()
            .chatId(session.getId())
            .title(session.getTitle())
            .systemPrompt(session.getSystemPrompt())
            .docId(session.getDocId())
            .messages(dtoMessages)
            .build();
    }

    @Transactional
    public ChatHistoryResponse getHistoryByDocId(Long userId, Long docId, boolean includeEdits) {
        ChatSession session = chatSessionRepository.findTopByUserIdAndDocIdOrderByUpdatedAtDesc(userId, docId)
            .orElseThrow(() -> new NotFoundException("Chat session not found for this document."));
        List<ChatMessage> messages = chatMessageRepository.findBySessionIdOrderByCreatedAtAsc(session.getId());

        List<ChatMessageHistoryDto> dtoMessages = messages.stream()
            .map(message -> ChatMessageHistoryDto.builder()
                .id(message.getId())
                .role(message.getRole())
                .content(message.getContent())
                .msgVersion(message.getMsgVersion())
                .createdAt(message.getCreatedAt())
                .updatedAt(message.getUpdatedAt())
                .editedAt(message.getEditedAt())
                .editedBy(message.getEditedBy())
                .revisions(includeEdits ? loadRevisions(message.getId()) : List.of())
                .build())
            .collect(Collectors.toList());

//        Collections.reverse(dtoMessages); // Show most recent messages first for doc history

        return ChatHistoryResponse.builder()
            .chatId(session.getId())
            .title(session.getTitle())
            .systemPrompt(session.getSystemPrompt())
            .docId(session.getDocId())
            .messages(dtoMessages)
            .build();
    }

    private ChatSession createSession(Long userId) {
        ChatSession session = new ChatSession();
        session.setUserId(userId);
        session.setCreatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        session.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        return chatSessionRepository.save(session);
    }

    private void persistMessage(ChatSession session, String role, String content, Long userId) {
        String sanitizedContent = sanitizeForWin1252(content);
        ChatMessage message = new ChatMessage();
        message.setSession(session);
        message.setRole(role);
        message.setContent(sanitizedContent);
        message.setMsgVersion(1);
        message.setCreatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        message.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        chatMessageRepository.save(message);
        session.setUpdatedAt(OffsetDateTime.now(ZoneOffset.UTC));
        chatSessionRepository.save(session);
    }

    private List<ChatMessageDto> buildPromptMessages(String systemPrompt, List<String> contextChunks) {
        List<ChatMessageDto> messages = new ArrayList<>();
        String prompt = systemPrompt == null || systemPrompt.isBlank()
            ? "You are DevDocs AI. Answer using provided context. Cite doc titles when possible."
            : systemPrompt;
        messages.add(ChatMessageDto.builder().role("system").content(prompt).build());
        for (String chunk : contextChunks) {
            messages.add(ChatMessageDto.builder().role("system").content("Context: " + chunk).build());
        }
        return messages;
    }

    private List<ChatMessageRevisionDto> loadRevisions(Long messageId) {
        return chatMessageRevisionRepository.findByMessageIdOrderByVersionDesc(messageId).stream()
            .map(rev -> ChatMessageRevisionDto.builder()
                .version(rev.getVersion())
                .content(rev.getContent())
                .editedAt(rev.getEditedAt())
                .editedBy(rev.getEditedBy())
                .build())
            .collect(Collectors.toList());
    }

    private String buildTitle(String question) {
        if (question == null || question.isBlank()) {
            return "New chat";
        }
        String trimmed = question.trim();
        return trimmed.length() <= 60 ? trimmed : trimmed.substring(0, 60) + "...";
    }

    private List<String> fetchNearestChunks(Long docId, List<Double> vector) {
        if (vector == null || vector.isEmpty()) {
            return List.of();
        }
        
        return vectorIndexService.searchSimilar(vector, docId, maxChunks)
            .stream()
            .map(VectorIndexService.VectorSearchResult::getContent)
            .collect(Collectors.toList());
    }

    private String sanitizeForWin1252(String value) {
        if (value == null) {
            return null;
        }
        CharsetEncoder encoder = Charset.forName("Windows-1252").newEncoder()
            .onMalformedInput(CodingErrorAction.REPLACE)
            .onUnmappableCharacter(CodingErrorAction.REPLACE)
            .replaceWith(new byte[] { (byte) '?' });
        try {
            ByteBuffer buffer = encoder.encode(CharBuffer.wrap(value));
            return Charset.forName("Windows-1252").decode(buffer).toString();
        } catch (Exception ex) {
            return value.getBytes(StandardCharsets.UTF_8).length > 0 ? value.replaceAll("[^\\x00-\\x7F]", "?") : value;
        }
    }
}
