package com.logicals;

import java.math.BigDecimal;

public class LogicalOne {

	public static void main(String[] args) {
		
		String s = "babad";
		
		String res = s.substring(0, 3);
		System.out.println(res);
		
		String a = "cbbd";
		System.out.println(a.codePointAt(0));
		
		String b = "prashanta";
		
		for(int i = 0; i<b.length(); i++ ) {
			
			System.out.println(i);
		}
		
		double d = 200.99;
		BigDecimal bigDecimal = BigDecimal.valueOf(d);
		BigDecimal bigDecimal2 = new BigDecimal(200.99);
		BigDecimal bigDecimal3 = new BigDecimal("200.99");
		
		System.out.println(bigDecimal);
		System.out.println(bigDecimal2);
		System.out.println(bigDecimal3);
	}
}