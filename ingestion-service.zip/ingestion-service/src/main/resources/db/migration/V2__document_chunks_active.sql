ALTER TABLE IF EXISTS document_chunks
    ADD COLUMN IF NOT EXISTS version_id BIGINT,
    ADD COLUMN IF NOT EXISTS active BOOLEAN NOT NULL DEFAULT TRUE,
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;

ALTER TABLE IF EXISTS ingestion_runs
    ADD COLUMN IF NOT EXISTS version_id BIGINT;

CREATE INDEX IF NOT EXISTS idx_document_chunks_active ON document_chunks(document_id, active);
