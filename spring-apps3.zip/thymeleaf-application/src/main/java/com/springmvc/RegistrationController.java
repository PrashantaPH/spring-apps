package com.springmvc;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.thymeleaf.context.Context;
//import org.thymeleaf.spring6.SpringTemplateEngine;

import com.springmvc.document.pdf.DocumentGenarator;
import com.springmvc.dto.Registration;
import com.springmvc.mapper.RegistrationDataMapper;

@Controller
public class RegistrationController {

	List<Registration> list = new ArrayList<>();

	@GetMapping("/home")
	public String homePage(Model model) {
		model.addAttribute("lisOfRegistration", list);
		return "registrationHomePage";
	}

	@GetMapping("/showRegistrationForm")
	public String showRegistrationForm(Model model) {
		Registration registration = new Registration();
		model.addAttribute("registration", registration);
		return "saveRegistration";
	}

	@PostMapping("/saveRegistration")
	public String saveRegistration(@ModelAttribute("registration") Registration registration) {
		list.add(registration);
		return "redirect:/home";
	}
	
	@GetMapping("/delete")
	public String deleteRegistration(@RequestParam(value = "email") String email) {
		
		for (Registration registration : list) {
			
			if (registration.getEmail().equals(email)) {
				registration.setFirstName(null);
				registration.setLastName(null);
				registration.setDate(null);
				registration.setEmail(null);
				registration.setPassword(null);
				registration.setPhone(0);
				registration.setAddress(null);
				registration.setCity(null);
				registration.setDomainName(null);
				registration.setProjectDescription(null);
				registration.setState(null);
				registration.setZip(null);
			}
		}
		return "redirect:/home";
	}

	@Autowired
	private DocumentGenarator documentGenarator;

	@Autowired
	private RegistrationDataMapper dataMapper;

	@Autowired
	//private SpringTemplateEngine engine;

	@GetMapping("/pdfgenarator")
	public String getPDF() {
		for (Registration registration : list) {

			String finalHtml = null;
			Context context = dataMapper.registrationSetData(registration);

			//finalHtml = engine.process("registrationPdfConvertor", context);
			
			documentGenarator.htmlToPDF(finalHtml);
		}
		return "redirect:/home";
	}
}
