# Photoshare Backend API

This is a Node.js backend using Express.js and MongoDB.

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```
2. Create a `.env` file in the root with the following variables (see .env.example):
   ```env
   MONGO_URI=your_mongodb_connection_string
   PORT=5000
   ```
3. Start the server:
   ```bash
   npm run dev
   ```

## Scripts
- `npm run dev` — Start server with nodemon
- `npm start` — Start server normally

## API Endpoints
- `GET /api/users` — List all users
- `POST /api/users` — Create a new user


npm install cors
