package com.basic;

import java.lang.reflect.Method;
import java.util.HashMap;

public class MethodClassBasic {

	public static void main(String[] args) {
		HashMap<String, String> hashMap = new HashMap<>();
		
		hashMap.put("Key", "Key");
		hashMap.put("NINUM", null);
		
		if(hashMap.get("NINUM") != null) {
			System.out.println(hashMap.get("NUNUM"));
		} else if(hashMap.get("NINUM") == null) {
			System.out.println("Null");
		}
	}
}
