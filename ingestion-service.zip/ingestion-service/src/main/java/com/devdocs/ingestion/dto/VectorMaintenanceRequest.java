package com.devdocs.ingestion.dto;

// Deprecated: use com.devdocs.common.dto.VectorMaintenanceRequest
