package com.devdocs.chat.repository;

import com.devdocs.chat.entity.ChatMessageRevision;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChatMessageRevisionRepository extends JpaRepository<ChatMessageRevision, Long> {
    List<ChatMessageRevision> findByMessageIdOrderByVersionDesc(Long messageId);
}
