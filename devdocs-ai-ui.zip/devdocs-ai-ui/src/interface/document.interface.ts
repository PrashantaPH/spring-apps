export interface Document {
  id: number;
  title: string;
  description?: string;
  sourceUri?: string;
  status: string;
  version: number;
  contentVersion: number;
  tags?: string[];
  acl?: Acl;
  deletedAt?: string | null;
  deletedBy?: number | null;
  createdAt: string;
  updatedAt?: string | null;
}

export interface Acl {
  isPublic: boolean;
  allowedUserIds: number[];
}

export interface CreateDocRequest {
  title: string;
  content: string;
  description?: string;
  sourceUri?: string;
}

export interface PatchDocRequest {
  title?: string;
  description?: string;
  sourceUri?: string;
  tags?: string[];
  acl?: Partial<Acl>;
}

export interface ChunkingOptions {
  strategy?: string;
  maxChars?: number;
  overlap?: number;
}

export interface ReindexRequest {
  chunking?: ChunkingOptions;
  embeddingModel?: string;
  refreshVectors?: boolean;
  upsert?: boolean;
}

export interface DocumentUpdateResponse {
  updated: boolean;
  document: Document;
}

export interface ReindexResponse {
  reindexRequested: boolean;
  document: Document;
}

export interface UploadDocumentResponse extends Document {
  etag?: string;
}

export interface BatchDeleteRequest {
  documentIds: number[];
  mode: 'soft' | 'hard';
  deleteVectors?: boolean;
  purgeBinary?: boolean;
}

export interface DeleteResult {
  documentId: number;
  status: string;
  message: string;
  deleted: boolean;
}

export interface BatchDeleteResponse {
  results: DeleteResult[];
}

export interface DocumentQueryParams {
  includeDeleted?: boolean;
  search?: string;
  tags?: string[];
  status?: string;
  limit?: number;
  offset?: number;
  sortBy?: 'createdAt' | 'updatedAt' | 'title';
  sortOrder?: 'asc' | 'desc';
}

export interface ApiError {
  message: string;
  statusCode: number;
  errorCode?: string;
  timestamp: string;
}