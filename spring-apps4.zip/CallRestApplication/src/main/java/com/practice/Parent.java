package com.practice;

public interface Parent {
	
	String parentMethod(String test);
	
	String m2(String s1, String s2);

}
