import React, { useState } from "react";
import {
    Box,
    Button,
    TextField,
    Typography,
    IconButton,
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faMoon, faSun } from "@fortawesome/free-solid-svg-icons";
import { signup } from "../api/authService.api"; // ✅ import API
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

interface Props {
    mode: "light" | "dark";
    setMode: (mode: "light" | "dark") => void;
}

const Register: React.FC<Props> = ({ mode, setMode }) => {
    const navigate = useNavigate();
    const isDark = mode === "dark";

    // ✅ state
    const [form, setForm] = useState({
        name: "",
        email: "",
        password: "",
    });

    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    // ✅ handle change
    const handleChange = (field: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
        setForm({ ...form, [field]: e.target.value });
    };

    // ✅ handle submit
    const handleSignup = async () => {
        try {
            setLoading(true);
            setError("");
            // ✅ basic validation
            if (!form.name || !form.email || !form.password) {
                toast.error("All fields are required");
                return;
            }

            await signup(form); // 🔥 API call

            toast.success("Account created successfully 🎉");

            // success → redirect to login
            navigate("/login");
        } catch (err: any) {
            setError(err?.message || "Signup failed");
            toast.error(err?.message || "Signup failed");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Box
            sx={{
                minHeight: "100vh",
                bgcolor: "background.default",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                position: "relative",
            }}
        >
            {/* Toggle */}
            <IconButton
            size="small"
                onClick={() => setMode(isDark ? "light" : "dark")}
                sx={{ position: "absolute", top: 20, right: 20, color: "primary.main" }}
            >
                <FontAwesomeIcon icon={isDark ? faSun : faMoon} />
            </IconButton>

            <Box sx={{ width: "100%", maxWidth: 405, px: 3, textAlign: "center" }}>
                
                <Typography sx={{ fontSize: "2.25rem", fontWeight: 900, mb: 1, color: "primary.main" }}>
                    Intelligence Console
                </Typography>

                <Typography variant="body2" sx={{ mb: 3, color: "text.secondary" }}>
                    Powered by <Box component="span" sx={{ color: "primary.main", fontWeight: "bold" }}>DEVDOCS</Box>
                </Typography>

                <Typography variant="h5" sx={{ mb: 2 }}>
                    Create your free account
                </Typography>

                <Typography variant="body2" sx={{ mb: 3 }}>
                    We suggest using the email address you use at work daily.
                </Typography>

                {/* Name */}
                <TextField
                    fullWidth
                    placeholder="Full Name"
                    size="small"
                    value={form.name}
                    onChange={handleChange("name")}
                    sx={{ mb: 2 }}
                />

                {/* Email */}
                <TextField
                    fullWidth
                    placeholder="name@work-email.com"
                    size="small"
                    value={form.email}
                    onChange={handleChange("email")}
                    sx={{ mb: 2 }}
                />

                {/* Password */}
                <TextField
                    fullWidth
                    type="password"
                    placeholder="Password"
                    size="small"
                    value={form.password}
                    onChange={handleChange("password")}
                    sx={{ mb: 2 }}
                />

                {/* Error */}
                {error && (
                    <Typography color="error" sx={{ mb: 2 }}>
                        {error}
                    </Typography>
                )}

                {/* Button */}
                <Button
                    fullWidth
                    onClick={handleSignup}
                    disabled={loading}
                    sx={{
                        textTransform: "none",
                        borderRadius: "8px",
                        backgroundColor: "primary.main",
                        color: "primary.contrastText",
                        py: 1,
                    }}
                >
                    {loading ? "Signing up..." : "Sign up with Email"}
                </Button>

                <Typography variant="body2" sx={{ mt: 4 }}>
                    Already have an account?{" "}
                    <Box
                        component="span"
                        onClick={() => navigate('/login')}
                        sx={{ cursor: "pointer", color: "primary.main" }}
                    >
                        Sign in →
                    </Box>
                </Typography>
            </Box>
        </Box>
    );
};

export default Register;