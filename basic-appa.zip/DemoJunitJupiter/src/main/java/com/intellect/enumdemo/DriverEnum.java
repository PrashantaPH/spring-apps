package com.intellect.enumdemo;

public class DriverEnum {

	public static void main(String[] args) {
		
		User user = new User();
		
		user.setName(EnumDemo.Prashnata);
		user.setLast(EnumDemo.Hanumantagoudra);
		System.out.println("Name : "+user.getName() +"\nLast : "+user.getLast());
	}
}
