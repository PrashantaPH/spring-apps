package com.devdocs.chat.dto;

import lombok.Data;

@Data
public class UpdateChatRequest {
    private String title;
    private String systemPrompt;
}
