package com.integration.Controller;

import org.apache.http.client.fluent.Request;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.StringEntity;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.integration.bean.User;

public class UserController {

	private static final String URL = "http://localhost:8085/api/v1/user/";

	private static String invokeRestApi(String endpoint, Object request) {
		String response = null;
		try {
			URIBuilder uriBuilder = new URIBuilder(URL+endpoint);
			JSONObject jsonObject = (JSONObject) JSONValue.parse(new ObjectMapper().writeValueAsString(request));
			response = Request.Post(uriBuilder.build()).setHeader("Content-Type", "application/json")
					.body(new StringEntity(jsonObject.toJSONString())).execute().returnContent().asString();
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return response;
	}

	public static void main(String[] args) {
		User user = new User(1, "Prashanta", "PH");
		
		String response = invokeRestApi("create", user);
		
		String response1 = invokeRestApi("message", user);
		
		System.out.println(response);
		
		System.out.println(response1);
		
	}
}
