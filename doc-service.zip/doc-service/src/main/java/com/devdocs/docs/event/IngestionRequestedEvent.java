package com.devdocs.docs.event;

import com.devdocs.docs.dto.ReindexRequest;

public record IngestionRequestedEvent(Long documentId, Long versionId, String content, ReindexRequest reindexRequest) {
}
