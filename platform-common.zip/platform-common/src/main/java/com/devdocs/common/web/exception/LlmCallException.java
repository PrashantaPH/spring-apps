package com.devdocs.common.web.exception;

public class LlmCallException extends RuntimeException {
    public LlmCallException() {
        super("LLM call failed");
    }

    public LlmCallException(String message) {
        super(message);
    }

    public LlmCallException(String message, Throwable cause) {
        super(message, cause);
    }
}
