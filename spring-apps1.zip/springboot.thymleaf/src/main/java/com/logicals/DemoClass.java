package com.logicals;

public class DemoClass {

	
	public static void main(String[] args) {
		String res = "";
		
		if(res.length() > 0) {
			System.out.println("res : "+res);
		}else
		System.out.println("res : "+res);
	}
}
