package com.devdocs.gateway.ratelimit;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilter;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

@Component
@RequiredArgsConstructor
public class BasicRateLimiterFilter implements GatewayFilter, Ordered {

    private final Map<String, Window> buckets = new ConcurrentHashMap<>();

    @Value("${rate-limit.requests-per-minute}")
    private int maxRequests;

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String key = exchange.getRequest().getRemoteAddress() == null ? "unknown"
            : exchange.getRequest().getRemoteAddress().getHostString();
        Window window = buckets.computeIfAbsent(key, k -> new Window());
        synchronized (window) {
            long now = Instant.now().getEpochSecond();
            if (now - window.windowStart >= 60) {
                window.windowStart = now;
                window.count = 0;
            }
            if (window.count >= maxRequests) {
                exchange.getResponse().setStatusCode(HttpStatus.TOO_MANY_REQUESTS);
                return exchange.getResponse().setComplete();
            }
            window.count++;
        }
        return chain.filter(exchange);
    }

    @Override
    public int getOrder() {
        return 0;
    }

    private static class Window {
        long windowStart = Instant.now().getEpochSecond();
        int count = 0;
    }
}
