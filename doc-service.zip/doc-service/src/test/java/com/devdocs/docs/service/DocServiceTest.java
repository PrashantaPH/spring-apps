package com.devdocs.docs.service;

import com.devdocs.docs.dto.CreateDocRequest;
import com.devdocs.docs.dto.DocumentDto;
import com.devdocs.docs.dto.DocumentReplaceRequest;
import com.devdocs.docs.dto.PatchDocRequest;
import com.devdocs.docs.dto.DeleteResult;
import com.devdocs.docs.repository.DocumentRepository;
import com.devdocs.common.exception.ConflictException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationEventPublisher;

@SpringBootTest
class DocServiceTest {

    @Autowired
    private DocService docService;

    @Autowired
    private DocumentRepository documentRepository;

    @MockBean
    private ApplicationEventPublisher eventPublisher;

    @MockBean
    private VectorMaintenanceClient vectorMaintenanceClient;

    @Test
    void patchDocument_conflictOnIfMatch() {
        Long ownerId = 100L;
        CreateDocRequest request = new CreateDocRequest();
        request.setTitle("Doc");
        request.setContent("Hello world");
        DocumentDto dto = docService.createDocument(ownerId, request);

        PatchDocRequest patch = new PatchDocRequest();
        patch.setTitle("Updated");

        String badIfMatch = "W/\"" + (dto.getVersion() + 1) + "\"";
        Assertions.assertThrows(ConflictException.class, () ->
            docService.patchDocument(ownerId, dto.getId(), patch, badIfMatch));
    }

    @Test
    void replaceDocument_noopWhenContentUnchanged() {
        Long ownerId = 101L;
        CreateDocRequest request = new CreateDocRequest();
        request.setTitle("Doc");
        request.setContent("Sample content");
        DocumentDto dto = docService.createDocument(ownerId, request);

        DocumentReplaceRequest replace = DocumentReplaceRequest.builder()
            .title("Doc")
            .description(null)
            .sourceUri(null)
            .content("Sample content")
            .checksum(checksum("Sample content"))
            .reindex(true)
            .build();

        var response = docService.replaceDocument(ownerId, dto.getId(), replace, null);
        Assertions.assertFalse(response.isUpdated());
    }

    @Test
    void deleteDocument_softMarksDeleted() {
        Long ownerId = 102L;
        CreateDocRequest request = new CreateDocRequest();
        request.setTitle("Doc");
        request.setContent("To be deleted");
        DocumentDto dto = docService.createDocument(ownerId, request);

        DeleteResult result = docService.deleteDocument(ownerId, dto.getId(), "soft", false, false, false);
        Assertions.assertTrue(result.isDeleted());
        Assertions.assertTrue(documentRepository.findById(dto.getId()).orElseThrow().getStatus().equals("DELETED"));
    }

    private String checksum(String content) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(content.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception ex) {
            throw new IllegalStateException(ex);
        }
    }
}
