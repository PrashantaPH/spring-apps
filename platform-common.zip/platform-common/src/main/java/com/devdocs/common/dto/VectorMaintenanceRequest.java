package com.devdocs.common.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class VectorMaintenanceRequest {
    @NotBlank
    private String mode; // soft or hard
}
