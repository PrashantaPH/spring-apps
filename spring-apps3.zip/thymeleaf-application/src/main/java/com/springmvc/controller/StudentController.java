package com.springmvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.springmvc.document.pdf.DocumentGenarator;
import com.springmvc.dto.ResponseStructure;
import com.springmvc.dto.Student;

//import jakarta.servlet.http.HttpServletResponse;

@RestController
public class StudentController {

	private static final org.apache.logging.log4j.Logger LOGGER = org.apache.logging.log4j.LogManager.getLogger(StudentController.class);
	

	@Autowired
	private DocumentGenarator documentGenarator;
	/*
	 * @Autowired private SpringTemplateEngine springTemplateEngine;
	 * 
	 * @Autowired private StudentDataMapper dataMapper;
	 * 
	 * @PostMapping(value = "/genarate/document") public String
	 * genarateDocument(@RequestBody List<Student> students) {
	 * 
	 * String finalHtml = null;
	 * 
	 * Context dataContext = dataMapper.setData(students);
	 * 
	 * finalHtml = springTemplateEngine.process("pdfConvertor", dataContext);
	 * 
	 * // documentGenarator.htmlToPDF(finalHtml);
	 * 
	 * return "Success"; }
	 */

	/*
	 * @GetMapping("/pdf") public void genaratePDF(HttpServletResponse
	 * servletResponse) throws DocumentException, IOException {
	 * 
	 * servletResponse.setContentType("application/pdf"); DateFormat dateFormat =
	 * new SimpleDateFormat("yyyy-MM-dd:hh:mm:ss"); String currentDateTime =
	 * dateFormat.format(new Date());
	 * 
	 * String headerKey = "Content-Disposition"; String headerValue =
	 * "attachment; filename=pdf_" + currentDateTime + ".pdf";
	 * servletResponse.setHeader(headerKey, headerValue);
	 * 
	 * documentGenarator.export(servletResponse);
	 * 
	 * }
	 */
	List<Student> listStudents = new ArrayList<>();

	@PostMapping("/create")
	public @ResponseBody ResponseEntity<ResponseStructure<Student>> createStudent(@RequestBody Student student) {
		ResponseStructure<Student> structure = new ResponseStructure<>();
		structure.setDate(new java.util.Date());
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Success");
		structure.setData(student);
		return new ResponseEntity<ResponseStructure<Student>>(structure, HttpStatus.OK);
	}

	@PostMapping("/student")
	public Student studentTest(@RequestBody Student student) {
		org.apache.logging.log4j.Logger logger = org.apache.logging.log4j.LogManager.getLogger("com.springmvc");
		logger.atLevel(org.apache.logging.log4j.Level.OFF);
		logger.info("Hleoo");
		logger.info("Hello");

		LOGGER.info(student.getFirstName());
		return student;
	}

}
