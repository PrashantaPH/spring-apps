package com.devdocs.docs.security;

import com.devdocs.common.security.SecurityErrorHandler;
import com.devdocs.common.security.ServiceTokenAuthenticationFilterBase;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ServiceTokenAuthenticationFilter extends ServiceTokenAuthenticationFilterBase {

    private static final String CALLBACK_PATH_PREFIX = "/api/v1/ingestions/callbacks";

    public ServiceTokenAuthenticationFilter(SecurityErrorHandler securityErrorHandler,
        @Value("${service.auth.token}") String serviceToken) {
        super(securityErrorHandler, serviceToken, CALLBACK_PATH_PREFIX, true);
    }
}
