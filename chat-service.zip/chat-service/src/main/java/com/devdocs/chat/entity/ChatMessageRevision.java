package com.devdocs.chat.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.OffsetDateTime;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "chat_message_revisions")
public class ChatMessageRevision {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "message_id")
    private ChatMessage message;

    @Column(name = "version", nullable = false)
    private Integer version;

    @Column(columnDefinition = "text", nullable = false)
    private String content;

    @Column(name = "edited_at", nullable = false)
    private OffsetDateTime editedAt;

    @Column(name = "edited_by", nullable = false)
    private Long editedBy;
}
